<?php
// Student 57050333
// create_appointment.php - THe page to initialise the appointment booking process, as this page requests a date for the consultation to be booked

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Assigns the $task variable to the validation that will occur
$task = 'search_slot';

// Initialisng the current date - used to restrict the datepicker not to accept a date before today's date
$current_date = date("Y-m-d");

?>
<!DOCTYPE html>
<html>
<!-- Student 57050333 -->
<head>
    <title>Choose Booking Date</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/booking_validation.php');?>
   
  <h1><u>Search for Availiable Booking Slots</u></h1>

  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  
  <!-- Form for choosing a date -->
  <form method="post" id="check_booking" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-20">
      <label for="date">Select Appointment Date</label>
    </div>
    <div class="col-80">
      <input type="date" id="date" name="date" min="<?php echo $current_date;?>" value="<?php echo $bookingDate;?>">
  <span class="error"><b>* <?php echo $bookingDateErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
  <br>
    <input type="submit" value="Search" style="float: left;">
	</div>
  </div>
  </form>

</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>