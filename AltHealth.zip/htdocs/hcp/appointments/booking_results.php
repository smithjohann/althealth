<?php
// Student 57050333
// booking_results.php - Displaying the booking(s) that was made for the patient. The option exists to cancel the booking

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Determining if the patient has any bookings 
if (htmlspecialchars($_GET['patient']) != '') {
	$patient_id = htmlspecialchars($_GET['patient']);
	$bookings = client_booking($patient_id);
	$result = "Bookings for Patient with ID Number $patient_id";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <div class="container">
        <table>
            <tr>
                <th>Booking Number</th>
				<th>Date of Appointment</th>
                <th>Time of Appointment</th>
                <th>Appointment End Time</th>
            </tr>

            <?php foreach ($bookings as $booking) : ?>
            <tr>
                <td><?php echo $booking['BOOKING_NUM']; ?></td>
                <td><?php echo $booking['APP_DATE']; ?></td>
				<td><?php echo $booking['APP_TIME_START']; ?></td>
				<td><?php echo $booking['APP_TIME_END']; ?></td>
			
			<td><form action="cancel_booking.php" method="post">
                    <input type="hidden" name="clientid"
                           value="<?php echo $booking['CLIENT_ID']; ?>">
					<input type="hidden" name="booking"
                           value="<?php echo $booking['BOOKING_NUM']; ?>">
                    <input type="hidden" name="date"
                           value="<?php echo $booking['APP_DATE']; ?>">
					<input type="submit" value="Cancel">
                </form></td>

            </tr>
            <?php endforeach; ?>
        </table>
		<br>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>