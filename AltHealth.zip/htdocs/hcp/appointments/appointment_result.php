<?php
// Student 57050333
// client_result.php - Displaying the bookings of the client

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Determining if the client's ID number is availiable and displaying the appointments made
if (htmlspecialchars($_GET['search']) != '') {
	$client = htmlspecialchars($_GET['search']);
	$queryAll = 'SELECT * FROM tblbookingsinfo
             WHERE client_id = :clientid';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':clientid', $client);
	$statementB->execute();
	$bookings = $statementB->fetchAll();
	$statementB->closeCursor();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Appointment Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="main3_4.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include 'navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <div class="container">
        <table>
            <tr>
                <th>Booking Number</th>
                <th>Appointment Date</th>
                <th>Appointment Time</th>
            </tr>

            <?php foreach ($bookings as $booking) : ?>
            <tr>
                <td><?php echo $booking['BOOKING_NUM']; ?></td>
                <td><?php echo $booking['APP_DATE']; ?></td>
				<td><?php echo $booking['APP_TIME_START'] . " - " . $booking['APP_TIME_END']; ?></td>

			<td><form action="create_appointment.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $booking['CLIENT_ID']; ?>">
                    <input type="hidden" name="booking_number" value="<?php echo $booking['BOOKING_NUM']; ?>">
					<input type="hidden" name="appointment_date" value="<?php echo $booking['APP_DATE']; ?>">
					<input type="submit" value="Change Date">
                </form></td>
			
			<td><form action="update_patient.php" method="get">
                    <input type="hidden" name="patient_update"
                           value="<?php echo $booking['CLIENT_ID']; ?>">
                    <input type="submit" value="Cancel">
                </form></td>

            </tr>
            <?php endforeach; ?>
        </table>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>