<?php
// Student 57050333
// consultation.php - Initialising the consultation where the HCP can add notes

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions, which includes a connection to the DB
include '../util/functions.php';

// Variable indicating the insert value - to be used in determining the validation to be performed
$task = 'insert';

// Determining the date for today and the patient
$current_date = date("Y-m-d");
$client = filter_input(INPUT_POST, 'client_id');

// Retrieving the patient's previous notes - note that the notes prior to the current_date is readonly		  
$appointment = retrieve_notes($client);

// Retrieving the client names for added personalisation to the form
$names = retrieve_client_names($client);
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Consultation</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php //include('client_validation.php');?>
   
  <h1><u>Patient Record of <?php foreach ($names as $name) :
	echo $name['c_name']." ";
	echo $name['c_surname'];
	endforeach;?></u></h1>
	
  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php //echo $validation_error;?></b></span>
  
  <!-- Form for adding a client -->
   <h1><u></u></h1>
    <section>
	<form method="post" id="add_notes" action="apply_charge.php">
        <table>
            <tr>
				<th>Appointment Date</th>
                <th style="width: 320px">Notes</th>

            </tr>

            <?php foreach ($appointment as $appointments) : ?>
            <tr>
                <td><b><?php echo $appointments['app_date']; ?></b></td>
                <td><textarea form="add_notes"<?php if ($appointments['app_date'] < $current_date || $appointments['app_date'] > $current_date) {echo 'readonly ';} elseif ($current_date == $appointments['app_date']) { echo ' name="notes"';}?>rows="2" cols="1" style="height: auto; resize:vertical-auto; width: 320px; font-family: calibri, arial; font-size: 15px;"><?php echo $appointments['notes']; ?></textarea></td>
            </tr>
            <?php endforeach; ?>
        </table>

  <div class="row">
  <br>
  <input type="hidden" name="client_id" value="<?php echo $client; ?>">
    <input type="submit" value="Save and Continue" style="float: left;">
	</div>
  </div>
  </form>

</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 5px 5px 5px 5px; float: right;"></a>
</footer>
</body>
</html>