<?php
// Student 57050333
// apply_charge.php - The HTML code of this page is viewed once the notes of the patient has been saved. This page enables the HCP to charge the patient accordingly

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions, which includes a connection to the database
include '../util/functions.php';

// Variable indicating the insert value - to be used in determining the validation to be performed
$task = 'insert';

// Retrieving the patient's notes, ID number and current date
$appointment_notes = htmlspecialchars(filter_input(INPUT_POST, 'notes'));
$client = htmlspecialchars(filter_input(INPUT_POST, 'client_id'));
$current_date = date("Y-m-d");

// Function to store the patient notes
save_notes($appointment_notes, $client, $current_date);

// Retrieving a list of fees previously applied, giving the HCP an option to enter a different fee or a previously used fee
$fees = fees();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Charge Patient</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
  <h1><u>Consultation Charge for this Appointment</u></h1>
<br>

	<h2>Enter a Charge</h2>
  <div class="container">
  
  
  <!-- Form for applying a fee for the consultation -->
  <form method="post" id="charge_client" action="consultation_finalised.php">
  <div class="row">
    <div class="col-25">
      <label for="new_charge">Enter a New Charge (in R):</label>
    </div>
    <div class="col-75">
      <input type="number" step="0.01" id="new_charge" name="new_charge" maxlength="10" placeholder="e.g. 500.00">
    </div>
  </div>
  
  <div class="row">
  <br>
	<input type="hidden" name="clientid" value="<?php echo $client;?>">
    <input type="submit" value="Apply New Charge" style="float: left;">
	</div>
  </div>
  </form>
  <br>
  <h2>Select a Charge</h2>
  <div class="container">
  <form method="post" id="charge_client" action="consultation_finalised.php">
  <div class="row">
    <div class="col-25">
      <label for="previous_charge">Select a Previous Charge:</label>
    </div>
    <div class="col-75">
      <select id="previous_charge" name="previous_charge">
        <option disabled value="">----Select Consultation Fee----</option>
            <?php foreach ($fees as $fee) : ?>
                <option value="<?php echo $fee['consultation_fee']; ?>">R<?php echo $fee['consultation_fee']; ?></option>
            <?php endforeach; ?>
            </select>
    </div>
  </div>
<div class="row">
  <br>
  <input type="hidden" name="clientid" value="<?php echo $client;?>">
    <input type="submit" value="Apply Selected Charge" style="float: left;">
	</div>
  </div>
  </form>
  
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>