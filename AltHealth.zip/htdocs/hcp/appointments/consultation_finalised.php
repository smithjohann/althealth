<?php
// Student 57050333
// consultation_finalised.php - This page completes the consultation in applying the selected charge to the patient and emailing the invoice for the patient 

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions, which includes a connection to the database
include '../util/functions.php';

// Determines if the HCP entered a new charge or selecred a previous charge from the list
if (htmlspecialchars(filter_input(INPUT_POST, 'new_charge')) != '') {
	$charge = htmlspecialchars(filter_input(INPUT_POST, 'new_charge'));
} else {
	$charge = htmlspecialchars(filter_input(INPUT_POST, 'previous_charge'));
}

// Retrieving the client's ID number
$client = filter_input(INPUT_POST, 'clientid');

// Determining today's date
$current_date = date("Y-m-d");

// Creating a new invoice
new_invoice($client, $current_date, $charge);

// Retrieving the auto generated INV_NUM from the db
$invoice = retrieve_inv_num($client, $current_date);		

// Retrieving the auto generated BOOKING_NUM from the db
$book = retrieve_booking_num($client, $current_date);		

// Adding the invoice information to the tblconsultationinvoice table
add_consultation_invoice($invoice, $book, $charge);		

// Retrieving the information of the client (such as name, email address) to compile the email
$client_information = client_info($client);
		
		foreach ($client_information as $client_info) {
			$name = $client_info['C_NAME'] . ' ' . $client_info['C_SURNAME'];
			$address = $client_info['C_ADDRESS'];
			$postal = $client_info['POSTAL_CODE'];
			$phone = $client_info['C_TEL_CELL'];
			$email = $client_info['C_EMAIL'];
		}
		
		// Using PHPMailer
		require_once '../util/message.php';

        // Set up email variables
        $to_address = '57050333.js@gmail.com';//$email;
        $to_name = $name;
        $from_address = 'althealth.57050333@gmail.com';
        $from_name = 'AltHealth';
        $subject = 'Invoice ' . $invoice;
        $body = '
		<html>
	<head>
		<meta charset="utf-8">
		<title>AltHealth Invoice</title>
		<style>
		/* heading */

h1 { 
font: bold 100% sans-serif; 
letter-spacing: 0.25em; 
text-align: left;  
}

/* table */

table { 
font-size: 75%; 
table-layout: fixed; 
width: 100%;
border-collapse: separate; 
border-spacing: 2px; 
}

th, td { 
border-width: 1px; 
padding: 0.5em; 
position: relative; 
text-align: left; 
border-radius: 0.25em; 
border-style: solid; 
}

th { 
background: #EEE; 
border-color: #BBB; 
}

td { 
border-color: #DDD; 
}

/* page */

html { 
font: 16px/1 "Open Sans", sans-serif; 
overflow: auto; 
padding: 1cm; 
background: #999; 
}


body { 
box-sizing: border-box; 
height: 29cm; 
margin: 0 auto; 
overflow: hidden; 
padding: 0.5in; 
width: 8.5in; 
}

body { 
background: #FFF; 
border-radius: 1px; 
}

/* header */

header { 
margin: 0 0 3em; 
float: right;
}

header:after { 
clear: both; 
content: ""; 
display: table; 
}

header h1 { color: rgb(59, 161, 185); border-radius: 0.25em;  margin: 0 0 1em; padding: .5em 0 .0em; }
header address { float: right; font-size: 75%; font-style: normal; line-height: 1.25; margin: 0 1em 1em 0; }
header address p { margin: 0 0 0.25em; }
header span, header img { display: block; float: right; }
header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 50%; position: relative; }

/* main */

main, main address, table.side, table.charge { margin: 0 0 3em; }
main:after { clear: both; content: ""; display: table; }
main h1 { clip: rect(0 0 0 0); position: absolute; }

main address { 
float: left; 
font-size: 100%; 
font-weight: bold; 
}

/* table side & balance */

table.side, table.balance { float: right; width: 36%; }
table.side:after, table.balance:after { clear: both; content: " "; display: table; }

/* table side */

table.side th { width: 50%; }
table.side td { width: 50%; }

/* table items */

table.charge { clear: both; width: 100%; }
table.charge th { font-weight: bold; text-align: center; }

/* table balance */
table.balance { float: left }
table.balance th, table.balance td { width: 50%; }
table.balance td { text-align: right; }

/* aside */

aside h1 { text-align: center; border: none; border-width: 0 0 1px; margin: 0 0 1em; border-color: #999; border-bottom-style: solid; }
aside div { font-family: calibri, ariel; }
aside { border-bottom-style: solid; border-color: #999; border-width: 0 0 1px;}

/* footer */

footer p { font-family: cambria, sans-serif; text-align: center;}


		</style>
	</head>
	<body>
		<header>
			<h1>AltHealth</h1>
			<address>
				<p>Mr Casey Millan<br>Cell: 082 471 2929</p>
			</address>
			<br>
		</header>
		<br>
		<main>
			<address>
					<p>'.$name.'<br>'.$address.'<br>'.$postal.'<br></p>
					<p>'.$phone.'<br>'.$email.'</p>
			</address>
			<table class="side">
				<tr>
					<th>Invoice Num</th>
					<td><span>INV0'.$invoice.'</span></td>
				</tr>
				<tr>
					<th>Date</th>
					<td><span>'.$current_date.'</span></td>
				</tr>
				<tr>
					<th>Amount Due</th>
					<td><span><b>R'.$charge.'</b></span></td>
				</tr>
			</table>
			<table class="chargables">
				<thead>
					<tr>
						<th><span>ID</span></th>
						<th><span>Description</span></th>
						<th><span>Fee</span></th>
						<th><span>Discount Allowed</span></th>
						<th><span>Sub Total (incl. VAT)</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><span>Booking Num. '.$book.'</span></td>
						<td><span>Consultation</span></td>
						<td><span>R'.$charge.'</span></td>
						<td><span>N/A</span></td>
						<td><span>R'.$charge.'</span></td>
					</tr>
				</tbody>
			</table>
			<br>
			<table class="balance">
				<tr>
					<th><span>Balance Due</span></th>
					<td><span><b>R'.$charge.'</b></span></td>
				</tr>
			</table>
			<br>
		</main>
		<br>
		<aside>
		<br>
			<h1><span><u>Payment Information</u></span></h1>
			<div>
				<p>All invoices are settled within 30 days.</p>
				<p>EFT Payments are made to:<br><br>
				<b>ABSA BANK</b><br>
				<b>Account Number: 45124561254</b><br>
				<b>Cheque Account</b><br>
				<b>Branch Code: 632005</b><br></p>
				<p>Please SMS Proof of Payment to 0824712929 and use your invoice number as reference (INV0'.$invoice.')</p>
				<br>
			</div>
		</aside>
		<footer>
		<p><span>Thank You for Visiting AltHealth. Please Call Again Soon!</span></p>
		</footer>
	</body>
</html>';
		
        $is_body_html = true;
        
        // Send email
        try {
            send_email($to_address, $to_name, 
                    $from_address, $from_name, 
                    $subject, $body, $is_body_html);		
        } catch (Exception $ex) {
            $error = $ex->getMessage();
        }        
?>
<html>
<head>
	<title>Consultation Completed</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<main>
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>
<body>
<br>
<?php if ($error != '') {?>
<h2>An error has occurred in sending the email to the client. Please take note of the following error:</h2><br>
<b><?php echo $error;?></b><br>
<br><p>The consultation has been finalised and the invoice was compiled (INV0<?php echo $invoice;?>).</p>
<?php } else { ?>
<h2>The consultation has been finalised and the invoice was compiled (INV0<?php echo $invoice;?>) and sent to the client.</h2>
<?php } ?>
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>