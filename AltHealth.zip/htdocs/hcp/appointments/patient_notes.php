<?php
// Student 57050333
// patient_notes.php - Page displaying patient notes, but does not launch the consultation process

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functons, which includes the connection to the db
include '../util/functions.php';

// Determining today's date and the patient who's notes are being viewed by the HCP
$current_date = date("Y-m-d");
$client = filter_input(INPUT_POST, 'patient');

// Retrieving the patient's notes		  
$appointment = retrieve_notes($client);

// Retrieving the name(s) of the patient for personalisation
$names = retrieve_client_names($client);
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Client</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
   
  <h1><u>Patient Record of <?php foreach ($names as $name) :
	echo $name['c_name']." ";
	echo $name['c_surname'];
	endforeach;?></u></h1>
	
  <div class="container">
  
   <h1><u></u></h1>
    <section>
	<form method="get" id="add_notes" action="../clients/patient_result.php">
        <table>
            <tr>
				<th>Appointment Date</th>
                <th style="width: 320px">Notes</th>

            </tr>

            <?php foreach ($appointment as $appointments) : ?>
            <tr>
                <td><b><?php echo $appointments['app_date']; ?></b></td>
                <td><textarea form="add_notes"<?php if ($appointments['app_date'] < $current_date || $appointments['app_date'] > $current_date) {echo 'readonly ';} elseif ($current_date == $appointments['app_date']) { echo ' name="notes"';}?>rows="2" cols="1" style="height: auto; resize:vertical-auto; width: 320px; font-family: calibri, arial; font-size: 15px;"><?php echo $appointments['notes']; ?></textarea></td>
            </tr>
            <?php endforeach; ?>
        </table>

  <div class="row">
  <br>
  <input type="hidden" name="search" value="<?php echo $client; ?>">
    <input type="submit" value="Back to Patient Details" style="float: left;">
	</div>
  </div>
  </form>

</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 5px 5px 5px 5px; float: right;"></a>
</footer>
</body>
</html>