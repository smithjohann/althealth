<?php
// Student 57050333
// availiable_slots.php - After providing a booking date, this page runs queries to retrieve the timeslots availiable to be booked

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Assigning the $task variable the action that will be performed
$task = 'booking_timeslot';

// Function to retrieve the timeslots from tbltimes
$timeslots = query_slots();

// Ensuring that a date search is performed, and retrieving the bookings already made for the day (this will be used to populate the droplist below in the HTML section)
if (htmlspecialchars($_GET['search']) != '') {
	$bookingDate = htmlspecialchars($_GET['search']);
	$result = "Appointment Booking for the $bookingDate";
	$bookings = appointments($bookingDate);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Availiability</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/booking_validation.php');?>	
	<br>
	<!--Displaying appropriete heading using $result-->
    <h1><?php echo $result;?></h1>
	<form method="post" id="add_booking" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <div class="container">
	
<div class="row">
    <div class="col-25">
      <label for="booking_slot">Availiable Timeslots</label>
    </div>
    <div class="col-75">
      <select id="booking_slot" name="booking_slot">  
				<option disabled value="">----Select Timeslot----</option>
				<?php
				foreach ($timeslots as $timeslot) {
					echo '<option ';
					if (!empty($bookings)) {
						foreach ($bookings as $booking) {
							if ($timeslot['APP_TIME_START'] == $booking['APP_TIME_START'] && $timeslot['APP_TIME_END'] == $booking['APP_TIME_END']) {
							echo 'disabled style="color: red;"'; //checking if there is a bookingslot already taken (occupied slots will be displayed in red and will not be selectable)
							} 
							if ($booking['APP_TIME_START'] < $timeslot['APP_TIME_START'] && $timeslot['APP_TIME_START'] < $booking['APP_TIME_END']) {
							echo 'disabled style="color: red;"'; //determining if a previous booking slot before the system was implemented so that the longer slots are handled accordingly
							}
						}
					}
					echo ' value="'.$timeslot['APP_TIME_START']. ' - ' . $timeslot['APP_TIME_END'].'">';
					echo $timeslot['APP_TIME_START'] . ' - ' . $timeslot['APP_TIME_END'].'</option>';	
				}?>
				</select>
				<br><br>
				</div>
				
				   
                <div class="row">
    <div class="col-25">
      <label for="clientid">Identity Number</label>
    </div>
    <div class="col-75">
      <input type="number" id="clientid" name="clientid" max="9999999999999" placeholder="13 Digit SA ID Number" value="<?php echo $id;?>">
  <span class="error"><b>* <?php echo $idErr;?></b></span>
    </div>
  </div>
						   
<div class="row">
  <br>
	 <input type="hidden" name="booking_date" value="<?php echo $bookingDate; ?>">
    <input type="submit" value="Book Appointment" style="float: left;">
	</div>
  </div>
  </form>
  
  <form action="create_appointment.php"
  <div class="row">
  <br>
    <input type="submit" value="Back to Date Selection" style="float: left;">
	</form>
	</div>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>