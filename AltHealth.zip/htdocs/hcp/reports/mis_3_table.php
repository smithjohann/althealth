<?php
// Student 57050333
// MIS Report 3: Frequency of Supplements - Keeping track of what supplements were popular over a certain timeframe (Data Table allowing the HCP to print out the report in tabular format)

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Initialising date variables
$date_start = filter_input(INPUT_POST, 'date_start');
$date_end = filter_input(INPUT_POST, 'date_end');

// Connecting to the database via mysqli
$connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

// Initialising the query being used for the chart
$query = "SELECT DISTINCT supplement_id, SUM(quantity) as calc_quantity FROM tblinvoicesupplements s JOIN tblinvoiceinfo i ON s.INV_NUM = i.INV_NUM WHERE i.INV_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY supplement_id";  

// Performing the query
$result3 = mysqli_query($connect, $query); 

// Determining the errors to be displayed should an error occur with a date that was provided by the user on the form
if ($date_end < $date_start) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics (start date was ' . $date_start . ' and end date was ' . $date_end . ')</span></b><br>';
	} elseif ($date_end > date('Y-m-d')) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (end date set was a date in the future)</span></b><br>';
	} elseif ($date_end == '' || $date_start == '') {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (start date or end date was ommitted)</span></b><br>';
	} else {
		$h1 = "<h1>Amount of Supplements Sold between $date_start and $date_end</h1>";
	}
?>
 <!DOCTYPE html>  
 <html> 
 <!--Student 57050333-->
 <head>  
    <title>MIS: Supplements Frequency</title> 
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="../view/main.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- Style for droparrows (for Navbar) -->
</head>  
<body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	<div>	
		<div style="width:900px;">  
		<?php echo $h1; ?>
<br>		
			<div>
		<table>
            <tr>
                <th>Supplement ID</th>
				<th>Units Sold</th>
            </tr>

            <?php foreach ($result3 as $result3) : ?>
            <tr>
				<td><?php echo $result3["supplement_id"]; ?></td>
                <td><?php echo $result3["calc_quantity"]; ?></td>
				<td><form action="view_supplement.php" method="post">
					<input type="hidden" name="supplement_selected" 
					value="<?php echo $result3['supplement_id']; ?>">
					<input type="submit" value="View Supplement Info" style="float: left;">
					</form></td>
			</tr>	
            	<?php endforeach; ?>
        </table>
		</div>

	</div>
	</br>

</main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>