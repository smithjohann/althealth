<?PHP
// Student 57050333
// MIS Query 2: Top 10 Postal Codes (Clients who reside in the postal code area)
// The HCP can keep track of where most of his clients comes from and perhaps focus more on other areas to generate additional revenue

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

//Connecting to the database
$connection2 = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

//Determining if the query can be executed 
if($stmt = $connection2->query("SELECT DISTINCT POSTAL_CODE, COUNT(*) AS count_of_postal FROM tblclientdata GROUP BY POSTAL_CODE ORDER BY `count_of_postal` DESC LIMIT 11")){
	$php_data_array1 = Array(); // create PHP array
	while ($row = $stmt->fetch_row()) {
		$php_data_array1[] = $row; 
	}
}

// Transform PHP array to JavaScript two dimensional array 
echo "<script>
        var my_2d = ".json_encode($php_data_array1)."
</script>";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Top 10 Areas Served</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />	
	<link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript"><!-- JavaScript used to draw the bar chart, using Google Visualisation -->
      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart', 'bar']});
      google.charts.setOnLoadCallback(drawChart2);
	  
      function drawChart2() {
        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Postal Code');
        data.addColumn('number', 'Amount of Clients');
        for(i = 0; i < my_2d.length; i++)
		data.addRow([my_2d[i][0], parseInt(my_2d[i][1])]);
       var options = {
          title: 'Top 10 Postal Codes',
          hAxis: {title: 'postal_code',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0, title:'Clients'}
        };

        var chart1 = new google.charts.Bar(document.getElementById('chart_div1'));
        chart1.draw(data, options);
       }
</script>
      </head>  
      <body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	  <br>
	  <section>
           <div style="width:1200px;">  
		        <h1>Representation of the 10 Areas Most Clients Reside In</h1><br> 
                <div id="chart_div1"></div>			
           </div>  
		   </section>
		   <br/>
			<form action="mis_2_table.php" method="post">
		   	<button type="submit">Show Data Table</button>
			</form>
		   </main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>