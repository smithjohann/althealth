<?php
// Student 57050333
// MIS Report 4: Frequency of Appointments - Data Table allowing the HCP to print out the report in tabular format

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

//Initialising the date variables
$date_start = filter_input(INPUT_POST, 'date_start');
$date_end = filter_input(INPUT_POST, 'date_end');

//Connecting to the database using mysqli
$connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

//Initialising the query to be used for this report
$query = "SELECT postal_code, COUNT(*) AS count_of_postal FROM tblclientdata c JOIN tblbookingsinfo b ON c.CLIENT_ID = b.CLIENT_ID WHERE APP_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY POSTAL_CODE";  

//Running the mysql_query
$result4 = mysqli_query($connect, $query); 

//Determining the error message if a user provides an erroneous date in the form
if ($date_end < $date_start) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics (start date was ' . $date_start . ' and end date was ' . $date_end . ')</span></b><br>';
	} elseif ($date_end > date('Y-m-d')) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (end date set was a date in the future)</span></b><br>';
	} elseif ($date_end == '' || $date_start == '') {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (start date or end date was ommitted)</span></b><br>';
	} else {
		$h1 = "<h1>Amount of Supplements Sold between $date_start and $date_end</h1>";
	}
?>
 <!DOCTYPE html>  
 <html> 
 <!--Student 57050333-->
 <head>  
    <title>MIS: Patient Visits From Areas</title> 
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="../view/main.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- Style for droparrows (for Navbar) -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> <!-- JS for Chart -->
</head>  
<body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	<div>	
		<div style="width:900px;">  
		<?php echo $h1; ?>
<br>		
			<div>
		<table>
            <tr>
                <th>Postal Code</th>
				<th>Patients Seen from Area</th>
            </tr>

            <?php foreach ($result4 as $result4) : ?>
            <tr>
				<td><?php echo $result4["postal_code"]; ?></td>
                <td><?php echo $result4["count_of_postal"]; ?></td>
			</tr>	
            	<?php endforeach; ?>
        </table>
		</div>

	</div>
	</br>

</main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>