<?php
// Student 57050333
// MIS Report 1: References of Clients - How clients were referred/got to know of the practice

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

//Connecting with database via mysqli
 $connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");
 
//Query used for the report (pie chart)
 $query = "SELECT c_reference, COUNT(*) AS count_of_reference FROM tblclientdata GROUP BY C_REFERENCE ORDER BY count_of_reference;";  
 
//Result of the query stored in $result1 
 $result1 = mysqli_query($connect, $query);  
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Client References</title> 
		   <link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
		   <link rel="stylesheet" type="text/css" href="../view/main.css" />  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
      </head>  
      <body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	  <section>
           <div>  
                <h1>Number of Client Referrals (Based on Type of Referral)</h1>  
                <div>
		<table>
            <tr>
                <th>Type of Reference</th>
				<th>Number of Clients</th>
            </tr>

            <?php foreach ($result1 as $result1) : ?>
            <tr>
				<td><?php echo $result1["c_reference"]; ?></td>
                <td><?php echo $result1["count_of_reference"]; ?></td>
			</tr>	
            	<?php endforeach; ?>
        </table>
		</div>
		<br>
				<form action="mis.php" method="post">
		   	<button type="submit">Back to MIS Dashboard</button>
			</form>
           </div>  
		   </section>
		   </main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>