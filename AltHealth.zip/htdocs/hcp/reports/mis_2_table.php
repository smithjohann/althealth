<?php
// Student 57050333
// MIS Report 2: Top 10 Postal Codes (Clients who reside in the postal code area)

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Connecting to the database via mysqli
 $connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");
 
// Executing Query 
 $query = "SELECT DISTINCT POSTAL_CODE, COUNT(*) AS count_of_postal FROM tblclientdata GROUP BY POSTAL_CODE ORDER BY `count_of_postal` DESC LIMIT 11";  
 
// Storing Result of Query 
 $result2 = mysqli_query($connect, $query);  
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Top 10 Areas Served</title> 
		   <link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
		   <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
		   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
      </head>  
      <body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	  <section>
           <div>  
                <h1>Representation of the 10 Areas Most Clients Reside In</h1>  
                <div>
		<table>
            <tr>
                <th>Postal Code (Area)</th>
				<th>Number of Clients Located in the Area</th>
            </tr>

            <?php foreach ($result2 as $result2) : ?>
            <tr>
				<td><?php echo $result2["POSTAL_CODE"]; ?></td>
                <td><?php echo $result2["count_of_postal"]; ?></td>
			</tr>	
            	<?php endforeach; ?>
        </table>
		</div>
		<br>
				<form action="mis.php" method="post">
		   	<button type="submit">Back to MIS Dashboard</button>
			</form>
           </div>  
		   </section>
		   </main>
<footer>
	<a class="logo"><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>