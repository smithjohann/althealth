<?php
// Student 57050333
// mis.php - The Management Information System Dashboard for the HCP of AltHealth

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<!--Student 57050333-->
<head>
    <title>Management Information System Reports</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
    <br>
	
	<section>
	<?php require_once ('althealth_m1.php'); ?>
	</section>
	
	<section>
	<?php include ('althealth_m2.php'); ?>
	</section>
	
	<section>
	<?php include ('althealth_m3.php'); ?>
	</section>
	
	<!-- MIS Report 4 has been omitted due to bug being resolved (07/06/2021)-->
	
	</main>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>