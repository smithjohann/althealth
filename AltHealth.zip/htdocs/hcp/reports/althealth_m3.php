<?php
// Student 57050333
// MIS Report 3: Frequency of Supplements - Keeping track of what supplements were popular over a certain timeframe

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Initialising date variables
$date_end = date('Y-m-d'); //in the format of YYYY-MM-DD
$date_start = date("Y-m-d", strtotime($date_end." -4 months")); //default display for the dashboard - showing supplements sold for the past 4 months

// Connecting to the database via mysqli
$connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

// Initialising the query being used for the chart
$query = "SELECT DISTINCT supplement_id, SUM(quantity) as calc_quantity FROM tblinvoicesupplements s JOIN tblinvoiceinfo i ON s.INV_NUM = i.INV_NUM WHERE i.INV_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY supplement_id";  

// Performing the query
$result3 = mysqli_query($connect, $query);  
?>

 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Supplements Frequency</title> 
		   <link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
		   <link rel="stylesheet" type="text/css" href="../view/main.css" />    
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript"><!-- JavaScript used to draw the piechart, using Google Visualisation -->  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['supplement_id', 'calc_quantity'],  
                          <?php  
                          while($row = mysqli_fetch_array($result3))  
                          {  
                               echo "['".$row["supplement_id"]."', ".$row["calc_quantity"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      //title: 'Frequency of Supplements', - commented out: using own <h1>  
                      is3D:true,  
                      pieHole: 0.0
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>  
      </head>  
      <body>
	  <br>
	  <section>
           <div>  
                <h1>Amount of Supplements Sold between <?php echo $date_start;?> and <?php echo $date_end;?></h1>  
                <div id="piechart" style="height: 500px;"></div>				
           </div>  
		   </section>
		   	<form action="mis_3.php" method="post">
		   	<button type="submit">More Information</button>
			</form>
		   </main>
<footer style="border-top: 2px dashed #DCDCDC;">
</footer>
</body>
</html>