<?php
// Student 57050333
// MIS Report 1: References of Clients - How clients were referred/got to know of the practice

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Connecting with database via mysqli
 $connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");
 
// Query used for the report (pie chart)
 $query = "SELECT c_reference, COUNT(*) AS count_of_reference FROM tblclientdata GROUP BY C_REFERENCE ORDER BY count_of_reference;";  
 
// Result of the query stored in $result1 
 $result1 = mysqli_query($connect, $query);  
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Client References</title> 
		   <link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
		   <link rel="stylesheet" type="text/css" href="../view/main.css" />  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript"><!-- JavaScript used to draw the piechart, using Google Visualisation -->  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['c_reference', 'count_of_reference'],  
                          <?php  
                          while($row = mysqli_fetch_array($result1))  
                          {  
                               echo "['".$row["c_reference"]."', ".$row["count_of_reference"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      //title: 'References of Clients', - commented out, using own <h1>  
                      is3D:true,  
                      pieHole: 0.0
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart1'));  
                chart.draw(data, options);  
           }  
           </script>  
      </head>  
      <body>
	  <section>
           <div>  
                <h1>Percentage of Client Referrals (Based on Type of Referral)</h1>  
                <div id="piechart1" style="height: 500px;"></div>
				<form action="mis_1.php" method="post">
		   	<button type="submit">More Information</button>
			</form>
           </div>  
		   </section>
		   </main>
		   <footer style="border-top: 2px dashed #DCDCDC;">
</footer>
</body>
</html>