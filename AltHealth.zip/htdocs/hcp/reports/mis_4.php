<?php
// Student 57050333
// MIS Query 4: Patients seen according to postal codes
// The HCP can keep track of possible diseases (illnesses) in the area based on the visits of patients from the specific area.

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

//Determining and initalising the date variables
if (filter_input(INPUT_POST, 'date_start') != '' && filter_input(INPUT_POST, 'date_end') != '') {
	$date_end = date("Y-m-d", strtotime($date_end." -1 days")); //YYYY-MM-DD
	$date_start = date("Y-m-d", strtotime($date_end." -4 months"));
} else {
	$date_end = date('Y-m-d'); //YYYY-MM-DD
	$date_start = date("Y-m-d", strtotime($date_end." -4 months"));
	//$date_end = strval($date_end);
	//$date_start = strval($date_start);
}

//Determining today's date in order to prevent a later date to be chosen for the end_date
$date_today = date('Y-m-d'); //YYYY-MM-DD

//Connecting to the database via mysqli
$connection4 = mysqli_connect("localhost", "root", "myPHP333", "althealth"); //CODE BEING DEBUGGED - 07/06/2021

//Determining the execution of the query 
if($stmt = $connection4->query("SELECT postal_code, COUNT(*) AS count_of_postal FROM tblclientdata c JOIN tblbookingsinfo b ON c.CLIENT_ID = b.CLIENT_ID WHERE APP_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY POSTAL_CODE")){
	$php_data_array = Array(); // create PHP array
	while ($row = $stmt->fetch_row()) {
		$php_data_array[] = $row;
   }

}
//Transform PHP array to JavaScript two dimensional array 
echo "<script>
        var my_4d = ".json_encode($php_data_array)."
</script>";

//Determining the error message to be displayed if the user provides an erroneous date
if ($date_end < $date_start) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics (start date was ' . $date_start . ' and end date was ' . $date_end . ')</span></b><br>';
	} elseif ($date_end > date('Y-m-d')) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (end date set was a date in the future)</span></b><br>';
	} elseif ($date_end == '' || $date_start == '') {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (start date or end date was ommitted)</span></b><br>';
	} else {
		$h1 = "<h1>Amount of Supplements Sold between $date_start and $date_end</h1>";
	}
?>
 <!DOCTYPE html>  
 <html> 
 <!--Student 57050333-->
 <head>  
    <title>Patients Seen According to Postal Code</title> 
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="../view/main.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- Style for droparrows (for Navbar) -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> <!-- JS for Charts -->
	<script type="text/javascript"><!-- JavaScript used to draw the bar chart, using Google Visualisation -->
      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart', 'bar']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {
        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Postal Code');
        data.addColumn('number', 'Amount of Patients');
        for(i = 0; i < my_4d.length; i++)
		data.addRow([my_4d[i][0], parseInt(my_4d[i][1])]);
       var options = {
          title: 'Patients Seen',
          hAxis: {title: 'postal_code',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0, title:'Clients'}
        };

        var chart = new google.charts.Bar(document.getElementById('chart_div'));
        chart.draw(data, options);
       }
</script>

</head>  
<body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>

	<div>	
		<div style="width:1200px;">    
		<?php echo $h1;?>
		<div id="chart_div"></div>			
           </div>  
		<form action="mis_4_table.php" method="post">
            <input type="hidden" name="date_start" value="<?php echo $date_start; ?>">
			<input type="hidden" name="date_end" value="<?php echo $date_end; ?>">
        <input type="submit" value="Show Data Table" style="float: left;border-radius: 5px; padding: 15px;">
		</form>
	</div>
			
	</br>
<br><br><br>
  <div class="container">
	<span><b>Please select a period to display statistics:<b></span><br><br>
	<form action="mis_4.php" method="post">
	<span class="error" name="error"></span>
	<div class="row">
    <div class="col-10">
      <label for="date_start">Start Date</label>
    </div>
    <div class="col-30">
      <input type="date" id="date_start" name="date_start">
      </div>
  </div>
  
  <div class="row">
    <div class="col-10">
      <label for="date_end">End Date</label>
    </div>
    <div class="col-30">
      <input type="date" id="date_end" max="<?php echo $date_today;?>" name="date_end">
      </div>
  </div>
  
  <div class="row">
	<br>
    <input type="submit" onclick="validation()" id="submit" value="Change Dates" style="float: left;">
	</div>
	</form>
</div>
</main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>