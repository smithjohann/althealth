<?PHP
// Student 57050333
// MIS Query 4: Patients seen according to postal codes
// The HCP can keep track of possible diseases (illnesses) in the area based on the visits of patients from the specific area.

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Initialising date variables
$date_end = date("Y-m-d", strtotime($date_end." -1 days")); //in the format of YYYY-MM-DD
$date_start = date("Y-m-d", strtotime($date_end." -4 months")); //default for the dashboard: displaying data for the past 4 months

// Connecting to the database via mysqli
$connection4 = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

// Determining the execution of the query 
if($stmt = $connection4->query("SELECT postal_code, COUNT(*) AS count_of_postal FROM tblclientdata c JOIN tblbookingsinfo b ON c.CLIENT_ID = b.CLIENT_ID WHERE APP_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY POSTAL_CODE")){
	$php_data_array = Array(); // create PHP array
	while ($row = $stmt->fetch_row()) {
		$php_data_array[] = $row;
   }

}
// Transform PHP array to JavaScript two dimensional array 
echo "<script>
        var my_4d = ".json_encode($php_data_array)."
</script>";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Patients Seen According to Postal Code</title> 
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="../view/main.css" />

	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript"><!-- JavaScript used to draw the bar chart, using Google Visualisation -->

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart', 'bar']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {
        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Postal Code');
        data.addColumn('number', 'Amount of Patients');
        for(i = 0; i < my_4d.length; i++)
		data.addRow([my_4d[i][0], parseInt(my_4d[i][1])]);
       var options = {
          title: 'Patients Seen',
          hAxis: {title: 'postal_code',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0, title:'Clients'}
        };

        var chart = new google.charts.Bar(document.getElementById('chart_div'));
        chart.draw(data, options);
       }
</script>
      </head>  
      <body>
	  <br>
	  <section>
           <div style="width:1200px;">  
		        <h1>Area Representation of Patients Seen During <?php echo $date_start;?> and <?php echo $date_end;?></h1><br> 
                <div id="chart_div"></div>			
           </div>  
		   </section>
		   <br/>
		   	<form action="mis_4.php" method="post">
		   	<button type="submit">More Information</button>
			</form>
		   </main>
</body>
</html>