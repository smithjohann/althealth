<?php
// Student 57050333
// MIS Report 3: Frequency of Supplements - Keeping track of what supplements were popular over a certain timeframe

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

if (filter_input(INPUT_POST, 'date_start') != '' && filter_input(INPUT_POST, 'date_end') != '') {
	$date_start = filter_input(INPUT_POST, 'date_start');
	$date_end = filter_input(INPUT_POST, 'date_end');
} else {
	$date_end = date('Y-m-d'); //YYYY-MM-DD
	$date_start = date("Y-m-d", strtotime($date_end." -4 months"));
	//$date_end = strval($date_end);
	//$date_start = strval($date_start);
}

//Determining today's date in order to prevent a later date to be chosen for the end_date
$date_today = date('Y-m-d'); //YYYY-MM-DD

//Connecting to the database via mysqli
$connect = mysqli_connect("localhost", "hcp", "althealth@hcp", "althealth");

//Initialising the query being used for the chart
$query = "SELECT DISTINCT supplement_id, SUM(quantity) as calc_quantity FROM tblinvoicesupplements s JOIN tblinvoiceinfo i ON s.INV_NUM = i.INV_NUM WHERE i.INV_DATE BETWEEN '$date_start' AND '$date_end' GROUP BY supplement_id";  

//Performing the query
$result3 = mysqli_query($connect, $query);  

//Determining the errors to be displayed should an error occur with a date that was provided by the user on the form
if ($date_end < $date_start) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics (start date was ' . $date_start . ' and end date was ' . $date_end . ')</span></b><br>';
	} elseif ($date_end > date('Y-m-d')) {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (end date set was a date in the future)</span></b><br>';
	} elseif ($date_end == '' || $date_start == '') {
		$h1 = '<h1>MIS: Amount of Supplements Sold</h1>
		<br><span class="error"><b>*Error: Date period set is incorrect to illustrate accurate statistics  (start date or end date was ommitted)</span></b><br>';
	} else {
		$h1 = "<h1>Amount of Supplements Sold between $date_start and $date_end</h1>";
	}
?>
 <!DOCTYPE html>  
 <html> 
 <!--Student 57050333-->
 <head>  
    <title>MIS: Supplements Frequency</title> 
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="../view/main.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- Style for droparrows (for Navbar) -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> <!-- JS for Piechart -->
	<script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['supplement_id', 'calc_quantity'],  
                          <?php  
                          while($row = mysqli_fetch_array($result3))  
                          {  
                               echo "['".$row["supplement_id"]."', ".$row["calc_quantity"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      //title: 'Frequency of Supplements',  
                      is3D:true,  
                      pieHole: 0.0
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           } 
    </script>

</head>  
<body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>

	<div>	
		<div style="width:900px;">  
		<?php echo $h1;?>
		<div id="piechart" style="height: 500px;"></div>				
		</div>
		<form action="mis_3_table.php" method="post">
            <input type="hidden" name="date_start" value="<?php echo $date_start; ?>">
			<input type="hidden" name="date_end" value="<?php echo $date_end; ?>">
        <input type="submit" value="Show Data Table" style="float: left;border-radius: 5px; padding: 15px;">
		</form>
	</div>
			
	</br>
<br><br><br>
  <div class="container">
	<span><b>Please select a period to display statistics:<b></span><br><br>
	<form action="mis_3.php" method="post">
	<span class="error" name="error"></span>
	<div class="row">
    <div class="col-10">
      <label for="date_start">Start Date</label>
    </div>
    <div class="col-30">
      <input type="date" id="date_start" name="date_start">
      </div>
  </div>
  
  <div class="row">
    <div class="col-10">
      <label for="date_end">End Date</label>
    </div>
    <div class="col-30">
      <input type="date" id="date_end" max="<?php echo $date_today;?>" name="date_end">
      </div>
  </div>
  
  <div class="row">
	<br>
    <input type="submit" onclick="validation()" id="submit" value="Change Dates" style="float: left;">
	</div>
	</form>
</div>
</main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>