<?php
// Student 57050333
// add_supplier.php - Displaying form to record a new supplier into the system

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

//variable indicating the add value - to be used in determining the validation to be performed
$task = 'insert';
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Supplier</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/supplier_validation.php');?>
   
  <h1><u>Add a New Supplier</u></h1>
	
  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php echo $validation_error;?></b></span>
  
  <!-- Form for adding a supplier -->
  <form method="post" id="add_supplier" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-25">
      <label for="supplier">Supplier ID</label>
    </div>
    <div class="col-75">
      <input type="text" id="supplier" name="supplier" placeholder="Enter Supplier ID (e.g. SUPPLIER X)" value="<?php echo $supplier;?>"></input>
      <span class="error"><b>* <?php echo $supplierErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="contact">Contact Person</label>
    </div>
    <div class="col-75">
      <input type="text" id="contact" name="contact" placeholder="Enter name of the contact person" value="<?php echo $contact;?>"></input>
      <span class="error"><b>* <?php echo $contactErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sTel">Telephone Number</label>
    </div>
    <div class="col-75">
      <input type="text" id="sTel" name="sTel" placeholder="e.g. 0112345678" maxlength="10" value="<?php echo $sTel;?>"></input>
	  <span class="error-blue"><b>* <?php echo $sTelErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sCell">Cellphone Number</label>
    </div>
    <div class="col-75">
      <input type="text" id="sCell" name="sCell" placeholder="e.g. 0821234567" maxlength="10" value="<?php echo $sCell;?>"></input>
      <span class="error-blue"><b>* <?php echo $sCellErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sFax">Fax</label>
    </div>
    <div class="col-75">
      <input type="text" id="sFax" name="sFax" placeholder="e.g. 0112345678" maxlength="10" value="<?php echo $sFax;?>"></input>
	  <span class="error-blue"><b>* <?php echo $sFaxErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sEmail">E-Mail Address</label>
    </div>
    <div class="col-75">
      <input type="text" id="sEmail" name="sEmail" placeholder="example@example.co.za" style="text-transform:lowercase" value="<?php echo $sEmail;?>"></input>
	  <span class="error-blue"><b>* <?php echo $sEmailErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sBank">Bank</label>
    </div>
    <div class="col-75">
      <input type="text" id="sBank" name="sBank" placeholder="e.g. ABSA" value="<?php echo $sBank;?>"></input>
	  <span class="error"><b><?php echo $sBankErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sBranch">Branch Code</label>
    </div>
    <div class="col-75">
      <input type="text" id="sBranch" name="sBranch" maxlength="6" placeholder="e.g. 632005" value="<?php echo $sBranch;?>"></input>
	  <span class="error"><b><?php echo $sBranchErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sAccNum">Account Number</label>
    </div>
    <div class="col-75">
      <input type="text" id="sAccNum" name="sAccNum" style="text-transform:lowercase" placeholder="e.g. 1234567890" value="<?php echo $sAccNum;?>"></input>
	  <span class="error"><b><?php echo $sAccNumErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="sAccType">Account Type</label>
    </div>
    <div class="col-75">
      <input type="text" id="sAccType" name="sAccType" placeholder="e.g. Cheque" value="<?php echo $sAccType;?>"></input>
	  <span class="error"><b><?php echo $sAccTypeErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="comments">Comments</label>
    </div>
    <div class="col-75">
      <input type="text" id="comments" name="comments" placeholder="e.g. This supplier has a COD policy" value="<?php echo $comments;?>"></input>
    </div>
  </div>

  <div class="row">
  <br>
    <input type="submit" value="Submit" style="float: left;">
	</div>
  </div>
  </form>

</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 5px 5px 5px 5px; float: right;"></a>
</footer>
</body>
</html>