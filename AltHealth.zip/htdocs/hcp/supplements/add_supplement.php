<?php
// Student 57050333
// add_supplement.php - Displaying form to record a new supplement into the system

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

//variable indicating the add value - to be used in determining the validation to be performed
$task = 'insert';
	
//Query to fill drop-down list with the suppliers availiable
$suppliers = suppliers();
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Supplement</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/supplement_validation.php');?>
   
  <h1><u>Add a New Supplement</u></h1>
	
  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php echo $validation_error;?></b></span>
  
  <!-- Form for adding a supplement -->
  <form method="post" id="add_supplement" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-20">
      <label for="supplement">Supplement ID</label>
    </div>
    <div class="col-80">
      <input type="text" id="supplement" name="supplement" placeholder="Example: Supplement-000 or Vitamin A" value="<?php echo $supplement;?>"></input>
	  <span class="error"><b>* <?php echo $supplementErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="description">Description</label>
    </div>
    <div class="col-80">
      <input type="text" id="description" name="description" placeholder="Enter a brief description of the supplement" value="<?php echo $desc;?>"></input>
	  <span class="error"><b><?php echo $descErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="cost_excl">Cost Excluding VAT (in R)</label>
    </div>
    <div class="col-80">
      <input type="number" step="0.01" id="cost_excl" name="cost_excl" maxlength="10" placeholder="Enter cost of the supplement excl. tax (e.g. 500.00)" value="<?php echo $costEx;?>"></input>
	  <span class="error-blue"><b>* <?php echo $costExErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="cost_incl">Cost Including VAT (in R)</label>
    </div>
    <div class="col-80">
      <input type="number" step="0.01" id="cost_incl" name="cost_incl" maxlength="10" placeholder="Enter the cost of the supplement incl. tax (e.g. 575.00)" value="<?php echo $costIn;?>"></input>
      <span class="error-blue"><b>* <?php echo $costInErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="markup">Client Markup (in R)</label>
    </div>
    <div class="col-80">
      <input type="number" step="0.01" id="markup" name="markup" maxlength="10" placeholder="Enter the profit amount (e.g. 20.00)" value="<?php echo $markup;?>"></input>
	  <span class="error"><b>* <?php echo $markupErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="cost_client">Cost to Client (in R)</label>
    </div>
    <div class="col-80">
      <input type="number" step="0.01" id="cost_client" name="cost_client" maxlength="10" placeholder="Enter the cost to the client (e.g. 595.00)" value="<?php echo $costCl;?>"></input>
      <span class="error-green"><b>* <?php echo $costClErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="supplier">Supplier</label>
    </div>
    <div class="col-80">
      <select id="supplier" name="supplier">
        <option disabled value="">----Select Supplier----</option>
            <?php foreach ($suppliers as $supplier) : ?>
                <option value="<?php echo $supplier['supplier_id']; ?>" <?php if ($supplier['supplier_id'] == $supp) {
				echo 'selected';
			}?>><?php echo $supplier['supplier_id']; ?></option>
            <?php endforeach; ?>
            </select>
			<span class="error"><b>*</b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="min_level">Minimum Level</label>
    </div>
    <div class="col-80">
      <input type="text" id="min_level" name="min_level" maxlength="4" placeholder="Enter minimum amount of units needed to be on hand" value="<?php echo $minL;?>"></input>
	  <span class="error"><b>* <?php echo $minLErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="current_level">Current Level</label>
    </div>
    <div class="col-80">
      <input type="text" id="current_level" name="current_level" maxlength="4" placeholder="Enter the current amount of units on hand" value="<?php echo $currentL;?>"></input>
	  <span class="error"><b>* <?php echo $currentLErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-20">
      <label for="nappi">NAPPI Code</label>
    </div>
    <div class="col-80">
      <input type="text" id="nappi" name="nappi" maxlength="6" placeholder="Enter the NAPPI code of the supplement (if applicable)" value="<?php echo $nappi;?>"></input>
    </div>
  </div>

  <div class="row">
  <br>
    <input type="submit" value="Submit" style="float: left;"></input>
	</div>
  </div>
  </form>
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 5px 5px 5px 5px; float: right;"></a>
</footer>
</body>
</html>