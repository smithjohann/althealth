<?php
// Student 57050333
// Invoice Management - Search Invoice Number to allow the update to occur (if the client has made payment, record on the db)

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// $task to perform validation on the invoice number provided
$task = 'search';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Invoice</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/invoice_validation.php');?>
   
  <h1><u>Search Booking with Patient ID</u></h1>

  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php //echo $validation_error;?></b></span>
  
  <!-- Form for searching an invoice -->
  <form method="post" id="search_id" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-30-1">
      <label for="inv_num">Invoice Number (starting with INV0)</label>
    </div>
    <div class="col-70">
      <input type="text" id="inv_num" name="inv_num" placeholder="e.g. 001" maxlength="6" value="<?php echo $inv;?>">
  <span class="error"><b>* <?php echo $invErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
  <br>
    <input type="submit" value="Search" style="float: left;">
	</div>
  </div>
  </form>
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>