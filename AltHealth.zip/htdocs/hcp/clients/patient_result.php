<?php
// Student 57050333
// client_result.php - Displaying the client who was successfully added, updated or searched for in a neat HTML table

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Determining the action that was performed and displaying the data accordingly
if ($_GET['new'] != '') {
	$clients = new_client();
	foreach ($clients as $client) {
		$clientname = $client['C_NAME'];
		$clientsurname = $client['C_SURNAME'];
	}
	$result = "New Patient ($clientname $clientsurname) Successfully Added";
} elseif ($_GET['updated'] != '') {
	$clients = update_client();
	foreach ($clients as $client) {
		$clientname = $client['C_NAME'];
		$clientsurname = $client['C_SURNAME'];
	}
	$result = "Patient ($clientname $clientsurname) Successfully Updated";
} elseif  ($_GET['search'] != '') {
	$clients = search_client();
	foreach ($clients as $client) {
		$clientname = $client['C_NAME'];
		$clientsurname = $client['C_SURNAME'];
	}
	$result = "Showing details of $clientname $clientsurname";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Client Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
	
	<!--Displaying the client in a HTML Table with two associated buttons to perform actions-->
    <div class="container">
        <table>
            <tr>
                <th>ID Number</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Address</th>
				<th>Postal Code</th>
                <th>Home</th>
                <th>Work</th>
                <th>Cell</th>
				<th>E-Mail</th>
                <th>Reference</th>
            </tr>

            <?php foreach ($clients as $client) : ?>
            <tr>
                <td><?php echo $client['CLIENT_ID']; ?></td>
                <td><?php echo $client['C_NAME']; ?></td>
                <td><?php echo $client['C_SURNAME']; ?></td>
				<td><?php echo $client['C_ADDRESS']; ?></td>
				<td><?php echo $client['POSTAL_CODE']; ?></td>
                <td><?php echo $client['C_TEL_H']; ?></td>
                <td><?php echo $client['C_TEL_W']; ?></td>
				<td><?php echo $client['C_TEL_CELL']; ?></td>
				<td><?php echo $client['C_EMAIL']; ?></td>
				<td><?php echo $client['C_REFERENCE']; ?></td>
				
			<td><form action="../appointments/patient_notes.php" method="post">
                    <input type="hidden" name="patient"
                           value="<?php echo $client['CLIENT_ID']; ?>"></input>
                    <input type="submit" value="Patient Notes"></input>
            </form></td>
			
			<td><form action="update_patient.php" method="get">
                    <input type="hidden" name="patient_update"
                           value="<?php echo $client['CLIENT_ID']; ?>"></input>
                    <input type="submit" value="Update Client"></input>
            </form></td>
            </tr>
            <?php endforeach; ?>
        </table>
	</div>	
</main>
</body>
<br/>
<footer>
 <a class="logo"><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>