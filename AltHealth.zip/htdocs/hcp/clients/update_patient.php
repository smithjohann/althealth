<?php
// Student 57050333
// update_patient.php - Displaying a form pre-loaded with the client's data to allow the end-user to update the data

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'hcp'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Variable indicating the task value - to be used in determining the validation to be performed in validation_client.php
$task = 'update';

// Retrieving the ID number of the client being updated
$patient_update = htmlspecialchars(filter_input(INPUT_GET, 'patient_update'));

// Calling the fetch_client() function
$client = fetch_client($patient_update);

// Assigning variables to the index as fetched from the table in the fetch_client() function
$id = $client['CLIENT_ID'];
$name = $client['C_NAME'];
$surname = $client['C_SURNAME'];
$address = $client['C_ADDRESS'];
$postal = $client['POSTAL_CODE'];
$telH = $client['C_TEL_H'];
$telW = $client['C_TEL_W'];
$telC = $client['C_TEL_CELL'];
$email = $client['C_EMAIL'];
$client_ref = $client['C_REFERENCE'];
		
// Calling function to populate the reference droplist in the form
$references = client_references();
?>
<!DOCTYPE html>
<html>
<!--Student 57050333-->
<head>
    <title>Update Client</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
</head>
<body>
<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
 <!-- Initialise the php include function for the validation php script -->   
<?php include('../util/client_validation.php');?>

    <h1>Updating Patient with ID Number <b><?php echo $id; ?></b> </h1>
    
    <div class="container">
	
	<!-- Message to show when an error has been detected in user's input -->
    <span class="error"><b><?php echo $validation_error;?></b></span>
	
    <!--Form to update data in the database table with current data filled-->
    <form method="post" id="update_client" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

  <div class="row">
    <div class="col-25">
      <label for="name">First Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="name" name="name" value="<?php echo $name;?>"></input>
	  <span class="error"><b>* <?php echo $nameErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="surname">Surname</label>
    </div>
    <div class="col-75">
      <input type="text" id="surname" name="surname" value="<?php echo $surname;?>"></input>
      <span class="error"><b>* <?php echo $surnameErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="address">Address</label>
    </div>
    <div class="col-75">
      <input type="text" id="address" name="address" value="<?php echo $address;?>"></input>
      <span class="error"><b>* <?php echo $addressErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="postal">Postal Code</label>
    </div>
    <div class="col-75">
      <input type="text" id="postal" name="postal" maxlength="4" value="<?php echo $postal;?>"></input>
      <span class="error"><b>* <?php echo $postalErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="tel_h">Home Telephone</label>
    </div>
    <div class="col-75">
      <input type="text" id="tel_h" name="tel_h" maxlength="10" placeholder="0123456789" value="<?php echo $telH;?>"></input>
      <span class="error"><b><?php echo $telHErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="tel_w">Work Telephone</label>
    </div>
    <div class="col-75">
      <input type="text" id="tel_w" name="tel_w" maxlength="10" placeholder="0123456789" value="<?php echo $telW;?>"></input>
      <span class="error"><b><?php echo $telWErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="tel_cell">Cellphone Number</label>
    </div>
    <div class="col-75">
      <input type="text" id="tel_cell" name="tel_cell" placeholder="0812345678" maxlength="10" value="<?php echo $telC;?>"></input>
      <span class="error"><b>* <?php echo $telCErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="email">E-Mail Address</label>
    </div>
    <div class="col-75">
      <input type="text" id="email" name="email" style="text-transform:lowercase"  placeholder="example@example.co.za" value="<?php echo $email;?>"></input>
      <span class="error"><b>* <?php echo $emailErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="reference">Reference</label>
    </div>
    <div class="col-75">
      <select id="reference" name="reference">  
				<option disabled value="">----Select Reference----</option>
				<?php foreach ($references as $reference) : ?>
                <option value="<?php echo $reference['c_reference']; ?>" <?php if ($client_ref == $reference['c_reference']) {echo 'selected';}?>>
				<?php echo $reference['c_reference']; ?></option>
				<?php endforeach; ?>
				</select>
				<br><br>
				   
                <input type="hidden" name="clientid" value="<?php echo $id; ?>"></input>
	</div>		
	
	<div class="row">
		<br>
		<input type="submit" value="Update" style="float: left;">
	</div>
	</form>
	
  </div>
</div>
<br>
</main>
<footer>
 <a class="logo"><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>