<?php
// Student 57050333
// Validation script for the client forms (adding, updating or searching a client)

// initialising the database connection
require('../model/connection.php');

// Function to ensure no whitespace or or is present in user's input
 function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

function verify_client_exists_upon_insert($id) {
	global $db;
	$queryAll = 'SELECT client_id FROM tblclientdata
						 WHERE client_id = :clientid';
			$statementB = $db->prepare($queryAll);
			$statementB->bindValue(':clientid', $id);
			$statementB->execute();
			$result = $statementB->fetch();
			$statementB->closeCursor();
			return $result;
}


// Declaring empty error variables 
$idErr = $nameErr = $surnameErr = $addressErr = $postalErr = $telHErr = $telWErr = $telCErr = $emailErr = $validation_error =  "";

// Declare empty variables if data is being inserted or search is performed
if ($task == 'insert') {
	$id = $name = $surname = $address = $postal = $telH = $telW = $telC = $email = $ref = "";
} elseif ($task == 'search') {
	$id = '';
}

// Performing validation on each entry and performs necessary action once the form is submitted to $_SERVER
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// Declare empty variables when an update occurs
	if ($task == 'update') {
	$id = $name = $surname = $address = $postal = $telH = $telW = $telC = $email = "";
	}
	
	// Validating the ID Number field
	if (empty($_POST["clientid"])) {
		$idErr = "SA ID Number required";
	} else {
		$id = test_input($_POST["clientid"]);
		// check if ID number only contains a number input and contains 13 digits
		if (!preg_match('/^[0-9]{13}$/', $id)) { 
			$idErr = "Invalid ID Number";
		} else {
			// validating if a valid birthdate (first 6 digits of ID) is present
			$date = substr($id, 0, 6);
			$year = substr($date, 0, 2);
			$month = substr($date, 2, 2);
			$day = substr($date, 4, 6);
			if (checkdate($month, $day, $year) === FALSE) {
				$idErr = "Invalid ID Number due to incorrect Date of Birth";
			}
			$result = verify_client_exists_upon_insert($id);
			if ($task == 'insert') {
				if (!empty($result)) {
					$idErr = "This client already exists on the system.";
				}
			}
		} 
	}
	
	// Validating if the patient is on the system when performing a search
	if ($task == 'search') {
		if (empty($_POST["clientid"])) {
			$idErr = "SA ID Number required";
		} else {
			$id = test_input($_POST["clientid"]);
			// check if ID number only contains a number input and contains 13 digits
			if (!preg_match('/^[0-9]{13}$/', $id)) { 
				$idErr = "Invalid ID Number";
			} else {
				// validating if a valid birthdate (first 6 digits of ID) is present
				$date = substr($id, 0, 6);
				$year = substr($date, 0, 2);
				$month = substr($date, 2, 2);
				$day = substr($date, 4, 6);
				if (checkdate($month, $day, $year) === FALSE) {
					$idErr = "Invalid ID Number due to incorrect Date of Birth";
				}
				// validating if the id number exists on the system
				$result = verify_client_exists_upon_insert($id);			
				if (!empty($result)) {
					header('Location:patient_result.php?search='.$_POST['clientid']);
				} else {
					$idErr = 'This client is not registered at AltHealth';
				}
			}
		}			
	} //end of search task

	// Validating the name field
	if (empty($_POST["name"])) {
		$nameErr = "Name is required";
	} else {
		$name = ucwords(test_input($_POST["name"]));
		// check if name does not contain foreign characters
		if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
			$nameErr = "Invalid name entered";
		}
	}
	
	// Validating the surname field
	if (empty($_POST["surname"])) {
		$surnameErr = "Surname is required";
	} else {
		$surname = ucwords(test_input($_POST["surname"]));
		// check if surname does not contain foreign characters
		if (!preg_match("/^[a-zA-Z ]*$/",$surname)) {
			$surnameErr = "Invalid surname entered";
		}
	}
	
	// Validating the address field
	if (empty($_POST["address"])) {
		$addressErr = "Address is required";
	} else {
		$address = ucwords(test_input($_POST["address"]));
	}
	
	// Validating the postal code field
	if (empty($_POST["postal"])) {
		$postalErr = "Please enter a postal code";
	} else {
		$postal = test_input($_POST["postal"]);
		// check if postal code only contains numbers
		if (!preg_match("/^[0-9]{4}$/",$postal)) {
			$postalErr = "Invalid postal code entered";
		}
	}
     
	// Validating the home telephone field
	if (!empty($_POST["tel_h"])) {
		$telH = test_input($_POST["tel_h"]);
		// check if tel_h only contains numbers
		if (!preg_match("/^[0-9 ]{7,}$/",$telH)) {
			$telHErr = "Invalid home phone number entered";
		}
	}
	
	// Validating the work telephone field
	if (!empty($_POST["tel_w"])) {
		$telW = test_input($_POST["tel_w"]);
		// check if tel_w only contains numbers
		if (!preg_match("/^[0-9 ]{7,}$/",$telW)) {
			$telWErr = "Invalid work phone number entered";
		}
	}
	
	// Validating the cellphone number field
	if (empty($_POST["tel_cell"])) {
		$telCErr = "Please enter a cellphone number";
	} else {
		$telC = test_input($_POST["tel_cell"]);
		// check if tel_cell only contains numbers
		if (!preg_match("/^[0-9 ]{7,}$/",$telC)) {
			$telCErr = "Invalid cellphone number entered";
		}
	}
	
	// Validating the email field
	if (empty($_POST["email"])) {
		$emailErr = "Please enter an email address";
	} else {
		// converting string to lower case
		$email = strtolower(test_input($_POST["email"])); 
		// performing email address validation by using FILTER_VALIDATE_EMAIL
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$emailErr = "Invalid email entered";
		}
	}
	
	// assigning $reference to the selected value in the drop-list (i.e. the selected reference)
		$ref = test_input($_POST["reference"]);
	
	// If an error is present, display a general error message to inform the user
	if ($idErr != "" || $nameErr != "" || $surnameErr != "" || $addressErr != "" || $postalErr != "" || $telHErr != "" || $telWErr != "" || $telCErr != "" || $emailErr != "") {
		$validation_error = "* Required field(s) needs attention<br><br>";
	}
	
	// Determining if no error is present and to execute the relevant task
	if($idErr == "" && $nameErr == "" && $surnameErr == "" && $addressErr == "" && $postalErr == "" &&  $telHErr == "" && $telWErr == "" && $telCErr == "" &&  $emailErr == "") {
	
		// assigning $reference to the selected value in the drop-list (i.e. the selected reference)
		$reference = $ref = test_input($_POST["reference"]);
	
		// determining the assigned $task variable, executing the correct sql statement and performing the correct header() execution
	
		if ($task === 'update') {
			//execute the update query
			$queryU = 'UPDATE tblclientdata
					   SET C_NAME = :name, C_SURNAME = :surname, C_ADDRESS = :address, POSTAL_CODE = :postal, C_TEL_H = :telH, C_TEL_W = :telW, C_TEL_CELL = :telC, C_EMAIL = :email, C_REFERENCE = :reference 
                       WHERE CLIENT_ID = :clientid';
			$statementU = $db->prepare($queryU);
			$statementU->bindValue(':name', $name);
			$statementU->bindValue(':surname', $surname);
			$statementU->bindValue(':address', $address);
			$statementU->bindValue(':postal', $postal);
			$statementU->bindValue(':telH', $telH);
			$statementU->bindValue(':telW', $telW);
			$statementU->bindValue(':telC', $telC);
			$statementU->bindValue(':email', $email);
			$statementU->bindValue(':reference', $reference);
			$statementU->bindValue(':clientid', $id);
			$statementU->execute();
			$statementU->closeCursor();
		
			header('Location:patient_result.php?updated='.$_POST['clientid']);
		} //end of the update task
	
		if ($task === 'insert') {
			
			//excecute the insert query
			$query = 'INSERT INTO tblclientdata
						(CLIENT_ID, C_NAME, C_SURNAME, C_ADDRESS, POSTAL_CODE, C_TEL_H, C_TEL_W, C_TEL_CELL, C_EMAIL, C_REFERENCE)
					  VALUES
						(:clientid, :name, :surname, :address, :postal, :tel_h, :tel_w, :tel_cell, :email, :reference)';
			$statementA = $db->prepare($query);
			$statementA->bindValue(':clientid', $id);
			$statementA->bindValue(':name', $name);
			$statementA->bindValue(':surname', $surname);
			$statementA->bindValue(':address', $address);
			$statementA->bindValue(':postal', $postal);
			$statementA->bindValue(':tel_h', $telH);
			$statementA->bindValue(':tel_w', $telW);
			$statementA->bindValue(':tel_cell', $telC);
			$statementA->bindValue(':email', $email);
			$statementA->bindValue(':reference', $reference);
			$statementA->execute();
			$statementA->closeCursor();
		
			header('Location:patient_result.php?new='.$_POST['clientid']);
			}
			
		} //end of the insert task
	
	} //end of executions
	
//end of $_POST
?>