<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//add_owner_form.php page
//Page showing all owners in the database. Data displayed in a neat HTML table.

//connecting to database via connection.php in the model folder
require('../task11_model/connection.php');
	
//retrieving latest data from the tblowners table using the fetchAll method to display in a neat HTML Table
$queryAll = 'SELECT * FROM tblowners
             ORDER BY OwnerSurname';
$statementA = $db->prepare($queryAll);
$statementA->execute();
$owners = $statementA->fetchAll();
$statementA->closeCursor();

//Determining if a Deletion is requested and then processing the delete (using DELETE statement)
if (filter_input(INPUT_POST, 'owner_delete') != '') {
	$owner_delete = filter_input(INPUT_POST, 'owner_delete');
    $query = 'DELETE FROM tblowners
              WHERE OwnerID = :ownerId';
    $statement = $db->prepare($query);
    $statement->bindValue(':ownerId', $owner_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the owner has been deleted
	header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <h2><u>All Owners</u></h2>
    <section>
        <table>
            <tr>
                <th>ID Number</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Phone</th>
				<th>E-Mail</th>
            </tr>

            <?php foreach ($owners as $owner) : ?>
            <tr>
                <td><?php echo $owner['OwnerID']; ?></td>
                <td><?php echo $owner['OwnerName']; ?></td>
                <td><?php echo $owner['OwnerSurname']; ?></td>
				<td><?php echo $owner['OwnerPhone']; ?></td>
                <td><?php echo $owner['OwnerEmail']; ?></td>
				
                <td><form action="update_owner_form.php" method="post">
                    <input type="hidden" name="owner_update"
                           value="<?php echo $owner['OwnerID']; ?>">
                    <input type="submit" value="Update">
                </form></td>
				

				<td><form action="all_owners.php" method="post">
                    <input type="hidden" name="owner_delete"
                           value="<?php echo $owner['OwnerID']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table><br>
    </section>
</main>

</body>
<section>
<p><a href="add_owner_form.php">Add New Owner</a></p>
<p><a href="index.php">Back to Owner Management</a></p>
</section>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
