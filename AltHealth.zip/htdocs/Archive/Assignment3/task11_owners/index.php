<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//index.php page for task11_owners
?>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
	<link rel="stylesheet" type="text/css" href="../main.css">
</head>
<body>
	<?php include '../task11_view/menu.inc';?>
    <main>
	 <h2><u>Owner Management Application</u></h2>
	 <br>
	<a href="add_owner_form.php">Add a New Owner</a>
	<br>
	<a href="search_owner.php">Search & Modify an Owner</a>
	<br>
	<a href="all_owners.php">View All Owners</a>
    </main>
    <br>
</body>

<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
