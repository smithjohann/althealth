<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//search_owner.php page
//Searching for an owner with ID number - Result displayed in owner_result.php
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>

<main>
    <h2>Search for an Owner</h2>
    <section>
        
		<label>Please enter the owner's ID number below and press Search to proceed.</label><br>
		<br>

		<!--Searching for an owner with ID number - Result displayed in owner_result.php-->
        <form action="owner_result.php" method="post" id="search_owner_form">
            
            <label>ID Number:</label>
            <input type="text" name="id_search" class="textbox" maxlength="13"><br>

            <input type="submit" value="Search"><br>
        </form>
        
    </section>
</main>

</body>
<br/>
<p><a href="index.php">Back to Owner Management Menu</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
