<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//add_owner_form.php page
//Adding a new owner to the database - Confirmation displayed in owner_result.php
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <section>
        
    <h2><b><u>Add New Owner</u></b></h2>
		<label>Please fill in the form below to add a new owner.</label><br>
        <br>  

		<!--Form to insert new owner into the DB-->
        <form action="owner_result.php" method="post" id="add_owner_form">
            
            <label>ID Number:</label>
            <input type="text" name="newId" class="textbox" maxlength="13"><br>

            <label>Name:</label>
            <input type="text" name="newName" class="textbox"><br>

            <label>Surname:</label>
            <input type="text" name="newSurname" class="textbox"><br>
			
			<label>Phone Number:</label>
            <input type="text" name="newPhone" class="textbox" maxlength="10"><br>

            <label>E-Mail Address:</label>
            <input type="text" name="newEmail" class="textbox"><br>

            <input type="submit" value="Save"><br>
        </form>
    </section>
</main>

</body>
<br/>
<p><a href="index.php">Back to Owner Management Menu</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
