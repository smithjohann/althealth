<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//update_owner_form.php page
//The page where the user updates the owner

//connecting to database via connection.php
require('../task11_model/connection.php');

//Retrieving the ID number of the owner being updated
$id_update = filter_input(INPUT_POST, 'owner_update');

//Preparing to fill the form with the current data stored in the database
$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
$statementA = $db->prepare($queryAll);
$statementA->bindValue(':ownerId', $id_update);
$statementA->execute();
$owners = $statementA->fetchAll();
$statementA->closeCursor();
?>
<!DOCTYPE html>
<html>
<!--task11 Student 57050333-->
<head>
    <title>Task 9</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <h2>Updating Owner with ID Number <b><?php echo htmlspecialchars($id_update) ?></b> </h2>
    
    <section>
		<!--Form to update data in the database table-->
        <form action="owner_result.php" method="post">

            <?php foreach ($owners as $owner) : ?>

                <label>Name:</label>
                <input type="text" name="nameU" class="textbox" maxlength="13"
                   value="<?php echo $owner['OwnerName']; ?>"><br>
				   
                <label>Surname:</label>
                <input type="text" name="surnameU" class="textbox"
                   value="<?php echo $owner['OwnerSurname']; ?>"><br>
				   
				<label>Phone:</label>
                <input type="text" name="phoneU" class="textbox" maxlength="10"
                   value="<?php echo $owner['OwnerPhone']; ?>"><br>
				   
                <label>E-Mail:</label>
                <input type="text" name="emailU" class="textbox"
                   value="<?php echo $owner['OwnerEmail']; ?>"><br>

                <input type="hidden" name="idU"
                           value="<?php echo $owner['OwnerID']; ?>">
						   
                <input type="submit" value="Update">
            </form>
            <?php endforeach; ?>
            <br>

</main>
<p><a href="index.php">Back to Owner Management</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
