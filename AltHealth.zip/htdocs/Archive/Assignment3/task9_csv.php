<?php
//Task 9 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task9_csv.php

include 'menu.inc';

echo '<br><b><u>Task 9.3 - Displaying Data from Database in CSV Fotmat</u></b><br><br>';

//connecting to database via task9_connection.php using PDO (Task 9.1)
require('task9_connection.php');
	
/////////////////////// Task 9.3 - Use of the fetchAll method ///////////////////////
//retrieving latest data from the inventory table using the fetchAll method to display in neat HTML Table
$queryAll = 'SELECT * FROM inventory
             ORDER BY Name';
$statementA = $db->prepare($queryAll);
$statementA->execute();
$items = $statementA->fetchAll();
$statementA->closeCursor();

/////////////////////// Task 9.3 - Item class and Iterating the Array $items ///////////////////////
class Item {
	
	//Defining properties
	public $name;
	public $number;
	public $cost;
	
	//The constructor method
	public function __construct($name, $number, $cost) {
		$this->name = $name;
		$this->number = $number;
		$this->cost = $cost;
	}
	
	//Getter method for name
	public function getName(){
		return $this->name;
	}
	
	//Setter method for name
	public function setName($value){
		return $this->name = $value;
	}
	
	//Getter method for number
	public function getNumber(){
		return $this->number;
	}
	
	//Setter method for number
	public function setNumber($value){
		return $this->number = $value;
	}
	
	//Getter method for cost
	public function getCost(){
		return $this->cost;
	}
	
	//Setter method for cost
	public function setCost($value){
		return $this->cost = $value;
	}
	
	//showOutput method for producing output in comma-separated format
	public function showOutput(){
		echo $this->getName().','.$this->getNumber().',R'.$this->getCost();
	}
}

//Creating Item object for each row of data stored in the array $items and calling showOutput to display in CSV format
foreach ($items as $item) {
	$task93 = new Item($item['Name'], $item['CurrentStock'], $item['Price']);
	$task93->showOutput();
	echo '<br>';
}
?>
<html>
    <!--task9 Student 57050333-->
<head>
    <title>Task 9</title>
</head>
<br>
<section>
<p><a href="task9.php">Back to Task 9 Page</a></p>
</section>
<footer>
<p><b>Task 9 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task9.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>