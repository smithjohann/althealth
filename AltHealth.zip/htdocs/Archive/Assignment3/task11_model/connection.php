<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//PHP Section for connection.php

//Database called body_corporate has created and contains two tables named tblowners and tblunits

//PHP Script that connects database using PDO
    $dsn = 'mysql:host=localhost;dbname=body_corporate';
    $username = 'root';
    $password = 'myPHP333';

//try catch exception for error handling
    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        require('../task11_error/connection_error.php');
        exit();
    }
?>