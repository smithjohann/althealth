<?php
function update_owner($name_update, $surname_update, $phone_update, $email_update, $id_update) {
    global $db;
	//Updating the owner
    $queryU = 'UPDATE tblowners
               SET OwnerName = :ownerName, OwnerSurname = :ownerSurname, OwnerPhone = :ownerPhone, OwnerEmail = :ownerEmail 
               WHERE OwnerID = :ownerId';
    $statementU = $db->prepare($queryU);
	$statementU->bindValue(':ownerId', $id_update);
    $statementU->bindValue(':ownerName', $name_update);
    $statementU->bindValue(':ownerSurname', $surname_update);
    $statementU->bindValue(':ownerPhone', $phone_update);
	$statementU->bindValue(':ownerEmail', $email_update);
    $statementU->execute();
    $statementU->closeCursor();
	
	//Display the updated owner
	$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerId', $id_update);
	$statementA->execute();
	$owners = $statementA->fetchAll();
	$statementA->closeCursor();
	
	$result = "$id_update $name_update $surname_update has been updated successfully";
	
	return $result;
    return $owners;    
}

function delete_owner($owner_delete) {
    global $db;
    $query = 'DELETE FROM tblowners
              WHERE OwnerID = :ownerId';
    $statement = $db->prepare($query);
    $statement->bindValue(':ownerId', $owner_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the owner has been deleted
	header("Location: index.php");
    //return $category_name;
}

function add_owner($id, $name, $surname, $phone, $email) {
    global $db;
    //adding new owner (row) into the database 
    $query = 'INSERT INTO tblowners
                 (OwnerID, OwnerName, OwnerSurname, OwnerPhone, OwnerEmail)
              VALUES
                 (:ownerId, :ownerName, :ownerSurname, :ownerPhone, :ownerEmail)';
    $statement = $db->prepare($query);
    $statement->bindValue(':ownerId', $id);
    $statement->bindValue(':ownerName', $name);
    $statement->bindValue(':ownerSurname', $surname);
	$statement->bindValue(':ownerPhone', $phone);
    $statement->bindValue(':ownerEmail', $email);
    $statement->execute();
    $statement->closeCursor();
	
	$result = "New Owner ($name $surname) Successfully Added";
	
	//Display the new owner
	$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerId', $id);
	$statementA->execute();
	$owners = $statementA->fetchAll();
	$statementA->closeCursor(); 
	
	return $result;
	return $owners;
}

function search_owner($id_search) {
    global $db;
    $queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerId', $id_search);
	$statementA->execute();
	$owners = $statementA->fetchAll();
	$statementA->closeCursor();

	$result = "Displaying information for ID Number $id_search";
	return $result;
	return $owners;
}
?>