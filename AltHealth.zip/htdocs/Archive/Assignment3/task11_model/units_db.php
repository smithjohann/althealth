<?php
function update_unit($unum_update, $building_update, $status_update, $owner_update) {
    global $db;
	//Updating the unit
    $queryU = 'UPDATE tblunits
               SET BuildingName = :buildingName, Status = :status, OwnerID = :ownerId 
               WHERE UnitNumber = :unitNumber';
    $statementU = $db->prepare($queryU);
	$statementU->bindValue(':unitNumber', $unum_update);
    $statementU->bindValue(':buildingName', $building_update);
    $statementU->bindValue(':status', $status_update);
    $statementU->bindValue(':ownerId', $owner_update);
    $statementU->execute();
    $statementU->closeCursor();
	
	//Display the updated unit
	$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNumber';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':unitNumber', $unum_update);
	$statementA->execute();
	$units = $statementA->fetchAll();
	$statementA->closeCursor();
	
	$result = "Unit $unum_update has been successfully updated";
	
	return $result;
    return $units;    
}

function delete_unit($owner_delete) {
    global $db;
    $query = 'DELETE FROM tblunits
              WHERE UnitNumber = :unitNumber';
    $statement = $db->prepare($query);
    $statement->bindValue(':unitNumber', $unit_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the unit has been deleted
	header("Location: index.php");
}

function add_unit($unit, $building, $status, $ownerId) {
    global $db;
    //adding new unit (row) into the database 
    $query = 'INSERT INTO tblunits
                 (UnitNumber, BuildingName, Status, OwnerID) 
              VALUES
                 (:unitNumber, :buildingName, :status, :ownerId)';
    $statement = $db->prepare($query);
    $statement->bindValue(':unitNumber', $unit);
    $statement->bindValue(':buildingName', $building);
    $statement->bindValue(':status', $status);
	$statement->bindValue(':ownerId', $ownerId);
    $statement->execute();
    $statement->closeCursor();
	
	$result = "New Unit (Unit $unit) Successfully Added";
	
	//Display the new unit
	$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNum';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':unitNum', $unit);
	$statementA->execute();
	$units = $statementA->fetchAll();
	$statementA->closeCursor(); 
	
	return $result;
	return $units;
}

function search_unit($unit_search) {
    global $db;
    $queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNum';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':unitNum', $unit_search);
	$statementA->execute();
	$units = $statementA->fetchAll();
	$statementA->closeCursor();

	$result = "Displaying information for Unit Number $unit_search";
	
	return $result;
	return $units;
}
?>