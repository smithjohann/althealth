<html>
    <!--task8 Student 57050333-->
<head>
    <title>Task 8</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
    
    
<body>
	<?php include 'menu.inc';?>
    <main>
	 <h2><u>Task 8</u></h2>
	 <br>
	<?php
	//Task 8 Assignment 2 ICT7612 - Student 57050333

	//PHP Section for task8.php
	
	//Describing all entities and how each entity is related to one another in terms of all primary keys and foreign keys.
	
	echo "The data model consists of the following entities:<br>";
	echo "<b>Customers, Orders, Order Details, Employees, Shippers, Suppliers, Categories and Products</b><br><br>";
	
	echo "The entities named above may have the following table names associated to them in a database:<br>";
	echo "<b>tblCustomers, tblOrders, tblOrderDetails, tblEmployees, tblShippers, tblSuppliers, tblCategories, tblProducts</b><br><br><br>";
	
	echo "<b><u>The explanation below describes the relationship between the entities in terms of their Primary and Foreign Keys:</u></b><br><br>";
	
	echo "A one-to-many relationship exists between Customers and Orders. This means that the Primary Key in Customers, known as <u>CustomerID</u>, is used as a Foreign Key in the Orders table. This suggests that multiple orders may be placed by a customer.<br><br>";
	
	echo "A one-to-many relationship exists between Orders and Order Details. This means that the Primary Key in Orders, known as <u>OrderID</u>, is used as a Foreign Key in the Order Details table. This suggests that an order may contain multiple order details (such as multiple products ordered by the customer that makes up the order).<br><br>";
	
	echo "A one-to-many relationship exists between Products and Order Details. This means that the Primary Key in Products, known as <u>ProductID</u>, is used as a Foreign Key in the Order Details table. This suggests that multiple order details may be present in Order Details for a product. <br><br>";
	
	echo "A one-to-many relationship exists between Suppliers and Products. This means that the Primary Key in Suppliers, known as <u>SupplierID</u>, is used as a Foreign Key in the Products table. This suggests that one or many products can be sourced from a supplier.<br><br>";
	
	echo "A one-to-many relationship exists between Categories and Products. This means that the Primary Key in Categories, known as <u>CategoryID</u>, is used as a Foreign Key in the Products table. This suggests that many products may fall under one category.<br><br>";
	
	echo "A one-to-many relationship exists between Employees and Orders. This means that the Primary Key in Employees, known as <u>EmployeeID</u>, is used as a Foreign Key in the Products table. This suggests that a number of orders are assigned to one employee (a picker for example) who is responsible the order.<br><br>";
	
	echo "A one-to-many relationship exists between Shippers and Orders. This means that the Primary Key in Shippers, known as <u>ShipperID</u>, is used as a Foreign Key in the Products table. This suggests that a number of orders can be shipped with a specific/different shipper. <br><br>";
	?>
    </main>
    <br>
</body>

<footer>
<p><b>Task 8 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task8.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
