<html>
    <!--task10 Student 57050333-->
<head>
    <title>Task 10</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
    
    
<body>
	<?php include 'menu.inc';?>
    <main>
	 <h2><u>Task 10: Using and Demonstrating the File System</u></h2>
	 <br>
	<?php
	//Task 10 Assignment 2 ICT3612 - Student 57050333

	//PHP Section for task10.php
	
	/////////////////////// Task 10(a) - Open current directory and print results ///////////////////////
	echo '<b>Task 10(a) - Open current directory and print results</b><br>';
	
	$path = getcwd();
	$items = scandir($path);
	$files = array();
	foreach ($items as $item) {
		$item_path = $path . DIRECTORY_SEPARATOR . $item;
		if (is_file($item_path)) {
			$files[] = $item;
		}
	}
	echo "<p>Files in $path</p>";
	echo '<ul>';
	foreach ($files as $file) {
		echo "<li>" . $file . "</li><br>";
	}
	echo "</ul>"."<br>";
	
	echo "<i>Please Take Note: I have instructed my code to display in a bulleted list (using 'ul' and 'li'), but the page is not interpreting/printing my bullets for the list.</i><br><br>";

	echo '<br>';
	
	/////////////////////// Task 10(b) - Create New Empty File newfile.txt ///////////////////////
	echo '<b>Task 10(b) - Create New Empty File newfile.txt</b><br>';
	
	$filename = 'newfile.txt';
	fopen($filename, 'xb');
	if (file_exists($filename)) {
		echo "The $filename file has been sucessfully created.";
	}
	echo '<br><br>';
	
	/////////////////////// Task 10(c) - Add Data to newfile.txt ///////////////////////
	echo '<b>Task 10(c) - Add Data to newfile.txt</b><br>';
	
	$path = getcwd();
	$items = scandir($path);
	$file = fopen('newfile.txt', 'wb');
	foreach ($items as $item) {
		$item_path = $path . DIRECTORY_SEPARATOR . $item;
		if (is_dir($item_path)) {
			fwrite($file, $item . "\n");
		}
	}
	echo 'Data has been added to the file newfile.txt';
	fclose($file);
	
	echo '<br><br>';
	
	/////////////////////// Task 10(d) - Read Data from newfile.txt ///////////////////////
	echo '<b>Task 10(d) - Read Data from newfile.txt</b><br>';
	
	$file = fopen('newfile.txt', 'rb');
	$names = '';
	while (!feof($file)) {
		$name = fgets($file);
		if ($name === false) continue;
		$name = trim($name);
		if (strlen($name) == 0 || substr($name, 0, 1) == '#') continue;
		$names .= "<div>" . $name . "</div>\n";
	}
	fclose($file);
	echo $names;
	

	echo '<br><br>';
	
	/////////////////////// Task 10(e) - Renaming newfile.txt to oldfile.txt ///////////////////////
	echo '<b>Task 10(e) - Renaming newfile.txt to oldfile.txt</b><br>';
	
	$old_name = 'newfile.txt';
	$new_name = 'oldfile.txt';
	if(file_exists($old_name)){
		$success = rename($old_name,$new_name);
		if($success){
			echo "The file ($old_name) has been renamed to $new_name";
		}
	}
	echo '<br><br>';
	?>
    </main>
    <br>
</body>

<footer>
<p><b>Task 10 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task10.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
