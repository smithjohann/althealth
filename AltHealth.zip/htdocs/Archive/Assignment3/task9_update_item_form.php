<?php
//Task 9.2(b) Assignment 2 ICT3612 - Student 57050333

//PHP Section for task9_update_item_form.php

//connecting to database via connection.php using PDO (Task 9.1)
require('task9_connection.php');

//getting the Name of the item to be updated to prepare the update form
$item_update = filter_input(INPUT_POST, 'item_update');

//selecting data to be updated - NOTE: Name will not be edited as the textinput is diabled
    $query = 'SELECT * FROM inventory
              WHERE Name = :name';
    $statementA = $db->prepare($query);
    $statementA->bindValue(':name', $item_update);
    $statementA->execute();
    $items = $statementA->fetchAll();
    $statementA->closeCursor();    

?>
<!DOCTYPE html>
<html>
<!--task9 Student 57050333-->
<head>
    <title>Task 9</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>
<body>
    <?php include 'menu.inc';?>
<header><h1>Task 9.2(b) (Update Form)</h1></header>
<main>
    <h2>Updating the Item: <?php echo htmlspecialchars($item_update) ?> </h2>
    
    <section>
		<!--Task 9.2(b) Form to update data in the database table-->
        <form action="task9.php" method="post">

            <?php foreach ($items as $item) : ?>

                <label>Current Stock:</label>
                <input type="text" name="currentStockU" class="textbox"
                   value="<?php echo $item['CurrentStock']; ?>"><br>
                <label>Price (in R):</label>
                <input type="text" name="priceU" class="textbox"
                   value="<?php echo $item['Price']; ?>"><br>

                <input type="hidden" name="nameU"
                           value="<?php echo $item['Name']; ?>">
                    <input type="submit" value="Update">
            </form>
            <?php endforeach; ?>
            <br>

</main>
<footer>
<p><b>Task 9 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task9.txt" height="400" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
