<html>
    <!--task2 Student 57050333-->
<head>
    <title>Task 2</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
    <?php include 'menu.inc';?>
	<h2><u>Task 2: Creating and Demonstrating the Welcome function</u></h2>
	<br>
<?php
//Task 2 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task2.php

//Creating the function welcome
function welcome() {
	$names = func_get_args();
	$count = func_num_args();
	echo 'Welcome to the following '.$count.' members:<br>';
	foreach($names as $name) {
		echo $name.'<br>';
	}
}
echo '<b>welcome(Peter, Susan)</b><br>';
welcome('Peter', 'Susan');
echo '<br><br>';
echo '<b>welcome(Ephraim, Annie, Portia, Lesego)</b><br>';
welcome('Ephraim', 'Annie', 'Portia', 'Lesego');
echo '<br>';
?>
<footer>
<p><b>Task 2 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task2.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
