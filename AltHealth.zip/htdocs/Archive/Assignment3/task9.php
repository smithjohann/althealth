<?php
//Task 9 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task9.php

/////////////////////// Task 9.1 - Connection to the created database ///////////////////////
//connecting to database via task9_connection.php using PDO (Task 9.1)
require('task9_connection.php');

/////////////////////// Task 9.2(b) - UPDATE statement in updating the data (as entered in task9_update_item_form) ///////////////////////
//gettting variables from update_doctor_form
$item_update = filter_input(INPUT_POST, 'nameU');
$stock_update = filter_input(INPUT_POST, 'currentStockU');
$price_update = filter_input(INPUT_POST, 'priceU');
   
//Updating selected item
    $queryU = 'UPDATE inventory
               SET CurrentStock = :currentStock, Price = :price
               WHERE Name = :name';
    $statementU = $db->prepare($queryU);
    $statementU->bindValue(':name', $item_update);
    $statementU->bindValue(':currentStock', $stock_update);
    $statementU->bindValue(':price', $price_update);
    $statementU->execute();
    $statementU->closeCursor();

	
/////////////////////// Task 9.2(c) - prepared DELETE statement when user deletes item from database ///////////////////////	
//for deleting an item (get $item_delete)
$item_delete = filter_input(INPUT_POST, 'item_delete');

//deleting the item from the database
if ($item_delete != false) {
    $query = 'DELETE FROM inventory
              WHERE Name = :name';
    $statement = $db->prepare($query);
    $statement->bindValue(':name', $item_delete);
    $success = $statement->execute();
    $statement->closeCursor();    
}

/////////////////////// Task 9.2(a) - prepared INSERT statement ///////////////////////
//retrieving variable inputs from form - preparing to add data
$name = filter_input(INPUT_POST, 'name');
$current_stock = filter_input(INPUT_POST, 'currentStock');
$price = filter_input(INPUT_POST, 'price');

//adding new row into the database 
    $query = 'INSERT INTO inventory
                 (Name, CurrentStock, Price)
              VALUES
                 (:name, :currentStock, :price)';
    $statement = $db->prepare($query);
    $statement->bindValue(':name', $name);
    $statement->bindValue(':currentStock', $current_stock);
    $statement->bindValue(':price', $price);
    $statement->execute();
    $statement->closeCursor();

	
/////////////////////// Task 9.2(a) - use of the fetchAll method ///////////////////////
//retrieving latest data from the inventory table using the fetchAll method to display in neat HTML Table
$queryAll = 'SELECT * FROM inventory
             ORDER BY Name';
$statementA = $db->prepare($queryAll);
$statementA->execute();
$items = $statementA->fetchAll();
$statementA->closeCursor();
?>
<!DOCTYPE html>
<html>
    <!--task9 Student 57050333-->
<head>
    <title>Task 9</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>
<body>
    <?php include 'menu.inc';?>
<h2><u>Task 9: The Store Database</u></h2>
<main>
    <h2>Inventory Table</h2>
    <!--Task 9.1 fetchAll method used to display list all items in a neat HTML table-->
    <section>
        <table>
            <tr>
                <th>Item Name</th>
                <th>Current Stock</th>
                <th class="right">Price (R)</th>
            </tr>

            <?php foreach ($items as $item) : ?>
            <tr>
                <td><?php echo $item['Name']; ?></td>
                <td><?php echo $item['CurrentStock']; ?></td>
				
				<!--Task 9.2(b) Preparing the task9_update_item_form where user will update the data-->
                <td class="right"><?php echo $item['Price']; ?></td>
                <td><form action="task9_update_item_form.php" method="post">
                    <input type="hidden" name="item_update"
                           value="<?php echo $item['Name']; ?>">
                    <input type="submit" value="Update">
                </form></td>
				
				<!--Task 9.2(c) Delete link to delete item from the database-->
				<td><form action="task9.php" method="post">
                    <input type="hidden" name="item_delete"
                           value="<?php echo $item['Name']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table><br>
        
        <label><b><u>Information:</u></b></label><br>
        <label>To Update an item, Press the Update Button and Complete the Form Displayed</label><br>
        <label>To Delete an item, Press the Delete Button</label><br>
        <label>To Add a Row, Please Complete the form Below and Press "Add Item"</label><br
		<label>To View the Inventory table in CSV format, click on the "CSV Format" link below</label><br>
        <br>  

		<!--Task 9.2(a) Form to insert new data (i.e. new items) into the database-->
        <form action="task9.php" method="post" id="add_item_form">
            
            <h2><b><u>Add an Item</u></b></h2>
            
            <label>Name of Item:</label>
            <input type="text" name="name" class="textbox"><br>

            <label>Stock Level:</label>
            <input type="text" name="currentStock" class="textbox"><br>

            <label>Price:</label>
            <input type="text" name="price" class="textbox"><br>

            <input type="submit" value="Add Item"><br>
        </form>
        
    </section>
</main>

</body>
<br/>
<section>
<!--Task 9.3-->
<p><a href="task9_csv.php">CSV Format</a></p>
</section>
<footer>
<p><b>Task 9 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task9.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
