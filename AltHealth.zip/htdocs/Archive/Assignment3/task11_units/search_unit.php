<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//search_unit.php page
//Searching for a unit with the UnitNumber - Result displayed in unit_result.php
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>

<main>
    <h2><u>Search for a Unit</u></h2>
    <section>
        
		<label>Please enter the unit's number to display results</label><br>
		<br>

		<!--Searching for a unit with UnitNumber - Result displayed in unit_result.php-->
        <form action="unit_result.php" method="post" id="search_unit_form">
            
            <label>Unit Number:</label>
            <input type="text" name="unit_search" class="textbox" maxlength="3"><br>

            <input type="submit" value="Search"><br>
        </form>
        
    </section>
</main>

</body>
<br/>
<p><a href="index.php">Back to Units Management Menu</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
