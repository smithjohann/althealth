<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//add_unit_form.php page
//Adding a new unit to the database - Confirmation displayed in unit_result.php
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <section>
        
    <h2><b><u>Add New Unit</u></b></h2>
		<label>Please fill in the form below to add a new unit.</label><br>
        <br>  

		<!--Form to insert new unit into the DB-->
        <form action="unit_result.php" method="post" id="add_unit_form">
            
            <label>Unit Number:</label>
            <input type="text" name="newUnit" class="textbox" maxlength="3"><br>

            <label>Building:</label>
            <input type="text" name="newBuilding" class="textbox"><br>

            <label>Status:</label>
            <input type="text" name="newStatus" class="textbox"><br>
			
			<label>Owner ID Number:</label>
            <input type="text" name="newId" class="textbox" maxlength="13"><br>

            <input type="submit" value="Save"><br>
        </form>
    </section>
</main>

</body>
<br/>
<p><a href="index.php">Back to Units Management Menu</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
