<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//update_unit_form.php page
//The page where the user updates the unit

//connecting to database via connection.php
require('../task11_model/connection.php');

//Retrieving the ID number of the owner being updated
$unit_update = filter_input(INPUT_POST, 'unit_update');

//Preparing to fill the form with the current data stored in the database
$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNumber';
$statementA = $db->prepare($queryAll);
$statementA->bindValue(':unitNumber', $unit_update);
$statementA->execute();
$units = $statementA->fetchAll();
$statementA->closeCursor();
?>
<!DOCTYPE html>
<html>
<!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <h2>Updating Unit Number <b><?php echo htmlspecialchars($unit_update) ?></b> </h2>
    
    <section>
		<!--Form to update data in the database table-->
        <form action="unit_result.php" method="post">

            <?php foreach ($units as $unit) : ?>
				   
                <label>Building Name:</label>
                <input type="text" name="buildingU" class="textbox"
                   value="<?php echo $unit['BuildingName']; ?>"><br>
				   
				<label>Status of Unit:</label>
                <input type="text" name="statusU" class="textbox"
                   value="<?php echo $unit['Status']; ?>"><br>
				   
                <label>Owner ID Number:</label>
                <input type="text" name="ownerU" class="textbox" maxlength="13"
                   value="<?php echo $unit['OwnerID']; ?>"><br>

                <input type="hidden" name="unitU"
                           value="<?php echo $unit['UnitNumber']; ?>">
						   
                <input type="submit" value="Update">
            </form>
            <?php endforeach; ?>
            <br>

</main>
<p><a href="index.php">Back to Units Management</a></p>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
