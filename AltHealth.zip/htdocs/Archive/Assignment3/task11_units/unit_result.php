<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//unit_result.php page
//The page displaying the result(s) whether a unit is being searched, updated or deleted

//connecting to database via connection.php in the model folder
require('../task11_model/connection.php');
//require('../task11_model/unit_db.php');


//Determining if an Update is being processed and then processing the update (using UPDATE statement)
if (filter_input(INPUT_POST, 'unitU') != '') { 
	$unum_update = filter_input(INPUT_POST, 'unitU');
	$building_update = filter_input(INPUT_POST, 'buildingU');
	$status_update = filter_input(INPUT_POST, 'statusU');
	$owner_update = filter_input(INPUT_POST, 'ownerU');
  
	//Updating the unit
    $queryU = 'UPDATE tblunits
               SET BuildingName = :buildingName, Status = :status, OwnerID = :ownerId 
               WHERE UnitNumber = :unitNumber';
    $statementU = $db->prepare($queryU);
	$statementU->bindValue(':unitNumber', $unum_update);
    $statementU->bindValue(':buildingName', $building_update);
    $statementU->bindValue(':status', $status_update);
    $statementU->bindValue(':ownerId', $owner_update);
    $statementU->execute();
    $statementU->closeCursor();
	
	//Display the updated unit
	$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNumber';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':unitNumber', $unum_update);
	$statementA->execute();
	$units = $statementA->fetchAll();
	$statementA->closeCursor();
	
	$result = "Unit $unum_update has been successfully updated";
}


//Determining if a Deletion is requested and then processing the deletion (using DELETE statement)
if (filter_input(INPUT_POST, 'unit_delete') != '') {
	$unit_delete = filter_input(INPUT_POST, 'unit_delete');
    $query = 'DELETE FROM tblunits
              WHERE UnitNumber = :unitNumber';
    $statement = $db->prepare($query);
    $statement->bindValue(':unitNumber', $unit_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the unit has been deleted
	header("Location: index.php");
}


//Determining if a new unit is being inserted and then inserting the new unit (using INSERT statement)
if (filter_input(INPUT_POST, 'newUnit') != '') {
	$unit = filter_input(INPUT_POST, 'newUnit');
	$building = filter_input(INPUT_POST, 'newBuilding');
	$status = filter_input(INPUT_POST, 'newStatus');
	$ownerId = filter_input(INPUT_POST, 'newId');

	//adding new unit (row) into the database 
    $query = 'INSERT INTO tblunits
                 (UnitNumber, BuildingName, Status, OwnerID) 
              VALUES
                 (:unitNumber, :buildingName, :status, :ownerId)';
    $statement = $db->prepare($query);
    $statement->bindValue(':unitNumber', $unit);
    $statement->bindValue(':buildingName', $building);
    $statement->bindValue(':status', $status);
	$statement->bindValue(':ownerId', $ownerId);
    $statement->execute();
    $statement->closeCursor();
	
	$result = "New Unit (Unit $unit) Successfully Added";
	
	//Display the new unit
	$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNum';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':unitNum', $unit);
	$statementA->execute();
	$units = $statementA->fetchAll();
	$statementA->closeCursor();
}	

//Determining if a search is being performed and then processing the search (using SELECT statement)
if (filter_input(INPUT_POST, 'unit_search') != '') {
$unit_search = filter_input(INPUT_POST, 'unit_search');

$queryAll = 'SELECT * FROM tblunits
             WHERE UnitNumber = :unitNum';
$statementA = $db->prepare($queryAll);
$statementA->bindValue(':unitNum', $unit_search);
$statementA->execute();
$units = $statementA->fetchAll();
$statementA->closeCursor();

$result = "Displaying information for Unit Number $unit_search";
}
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <section>
        <table>
            <tr>
                <th>Unit Number</th>
                <th>Building</th>
                <th>Status</th>
                <th>Owner ID Number</th>
            </tr>

            <?php foreach ($units as $unit) : ?>
            <tr>
                <td><?php echo $unit['UnitNumber']; ?></td>
                <td><?php echo $unit['BuildingName']; ?></td>
                <td><?php echo $unit['Status']; ?></td>
				<td><?php echo $unit['OwnerID']; ?></td>
				
			<td><form action="../task11_owners/owner_result.php" method="post">
                    <input type="hidden" name="unit_owner"
                           value="<?php echo $unit['OwnerID']; ?>">
                    <input type="submit" value="Owner Details">
                </form></td>
			
			<td><form action="update_unit_form.php" method="post">
                    <input type="hidden" name="unit_update"
                           value="<?php echo $unit['UnitNumber']; ?>">
                    <input type="submit" value="Update">
                </form></td>

				<td><form action="unit_result.php" method="post">
                    <input type="hidden" name="unit_delete"
                           value="<?php echo $unit['UnitNumber']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table>
</main>

</body>
<br/>
<section>
<p><a href="add_unit_form.php">Add New Unit</a></p>
<p><a href="index.php">Back to Unit Management Menu</a></p>
</section>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>