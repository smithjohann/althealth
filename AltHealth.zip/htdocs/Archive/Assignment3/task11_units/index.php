<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//index.php page for task11_units
?>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
	<link rel="stylesheet" type="text/css" href="../main.css">
</head>
<body>
	<?php include '../task11_view/menu.inc';?>
    <main>
	 <h2><u>Unit Management Application</u></h2>
	 <br>
	<a href="add_unit_form.php">Add a Unit</a>
	<br>
	<a href="search_unit.php">Search & Modify a Unit</a>
	<br>
	<a href="all_units.php">View All Units</a>
    </main>
    <br>
</body>

<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
