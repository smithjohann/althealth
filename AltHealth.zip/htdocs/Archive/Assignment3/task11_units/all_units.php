<?php
//Task 11 Assignment 2 ICT3612 - Student 57050333

//all_units.php page
//Displaying all units in a HTML table

//connecting to database via connection.php in the model folder
require('../task11_model/connection.php');
	
//retrieving latest data from the tblunits table using the fetchAll method to display in a neat HTML Table
$queryAll = 'SELECT * FROM tblunits
             ORDER BY UnitNumber';
$statementA = $db->prepare($queryAll);
$statementA->execute();
$units = $statementA->fetchAll();
$statementA->closeCursor();

//Determining if a Deletion is requested and then processing the delete (using DELETE statement)
if (filter_input(INPUT_POST, 'unit_delete') != '') {
	$unit_delete = filter_input(INPUT_POST, 'unit_delete');
    $query = 'DELETE FROM tblunits
              WHERE UnitNumber = :unitNumber';
    $statement = $db->prepare($query);
    $statement->bindValue(':unitNumber', $unit_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the unit has been deleted
	header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <h2><u>All Units</u></h2>
    <section>
        <table>
            <tr>
                <th>Unit Number</th>
                <th>Building Name</th>
                <th>Status of Unit</th>
                <th>Owner ID Number</th>
            </tr>

            <?php foreach ($units as $unit) : ?>
            <tr>
                <td><?php echo $unit['UnitNumber']; ?></td>
                <td><?php echo $unit['BuildingName']; ?></td>
                <td><?php echo $unit['Status']; ?></td>
				<td><?php echo $unit['OwnerID']; ?></td>
				
				<td><form action="../task11_owners/owner_result.php" method="post">
                    <input type="hidden" name="unit_owner"
                           value="<?php echo $unit['OwnerID']; ?>">
                    <input type="submit" value="Owner Details">
                </form></td>
				
                <td><form action="update_unit_form.php" method="post">
                    <input type="hidden" name="unit_update"
                           value="<?php echo $unit['UnitNumber']; ?>">
                    <input type="submit" value="Update">
                </form></td>
				
				<td><form action="all_units.php" method="post">
                    <input type="hidden" name="unit_delete"
                           value="<?php echo $unit['UnitNumber']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table><br>
    </section>
</main>

</body>
<section>
<p><a href="add_unit_form.php">Add a New Unit</a></p>
<p><a href="index.php">Back to Units Management</a></p>
</section>
<footer>
<p><b>Task 11 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
