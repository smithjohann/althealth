<html>
    <!--task1 Student 57050333-->
<head>
    <title>Task 1</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
    <?php include 'menu.inc';?>
	<h2><u>Task 1: Creating and Demonstrating the calculateTax function</u></h2>
	<br>
<?php
//Task 1 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task1.php

//Creating the function calculateTax
function calculateTax($price, $taxInput = NULL)
{
	if (!isset($taxInput)) {
		$taxRate = '7';
	} else {
		$taxRate = $taxInput;
	}
	$taxAmount = $price * ($taxRate/100);
	$total = $price + $taxAmount;
	echo "The total amount payable for the item is R".$total.".";
}
echo '<b>Demonstration of the calculateTax function:</b><br><br>';
echo 'calculateTax(200)<br>';
calculateTax(200);
echo '<br><br>';
echo 'calculateTax(100,18)<br>';
calculateTax(100,18);
echo '<br>';
?>
<footer>
<p><b>Task 1 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task1.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
