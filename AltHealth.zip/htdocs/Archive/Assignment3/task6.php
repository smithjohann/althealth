<html>
    <!--task6 Student 57050333-->
<head>
    <title>Task 6</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
    <?php include 'menu.inc';?>
	<h2><u>Task 6: Creating and Demonstrating the Ship superclass & CruiseShip and CargoShip subclasses</u></h2>
	<br>
<?php
//Task 6 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task6.php

//Creating the superclass Ship
class Ship {
	
	//Defining properties
	public $name;
	public $year;
	
	//The constructor method
	public function __construct($name, $year) {
		$this->name = $name;
		$this->year = $year;
	}
	
	//Method returning the name of the name
	public function getName(){
		return $this->name;
	}
	
	//Method setting the name of the ship
	public function setName($value){
		return $this->name = $value;
	}
	
	//Method for getting the year the ship was built
	public function getYear() {
		return $this->year;
	}
	
	//Method for displaying the ship's name and the year it was built
	public function showOutput(){
		echo 'Name of Ship: '. $this->getName(). '<br />';
		echo 'Manufactured Year: '. $this->getYear(). '<br />';
	}
}

//creating the subclass CruiseShip
class CruiseShip extends Ship {
	
	//Defining the property
	public $numberOfPassangers;

	//The constructor method
	public function __construct($name, $numberOfPassangers) {
		$this->numberOfPassangers = $numberOfPassangers;
		parent::__construct($name, $year='');
	}
	
	//Method for getting the number of passengers
	public function getNumberOfPassangers() {
		return $this->numberOfPassangers;
	}
	
	//Method overriding showOutput in superclass and displaying only shipname and number of passangers
	public function showOutput(){
		echo 'Name of Ship: '.parent::getName().'<br>';
		echo 'Number of Passengers: '.$this->getNumberOfPassangers().' passangers<br>';
	}
}

//creating the subclass CargoShip
class CargoShip extends Ship {
	
	//Defining the property
	public $tonnage;
	
	//The constructor method
	public function __construct($name, $tonnage) {
		$this->tonnage = $tonnage;
		parent::__construct($name, $year='');
	}
	
	//Method for getting the tonnage of the cargo (i.e. cargo capacity)
	public function getTonnage() {
		return $this->tonnage;
	}
	
	//Method overriding showOutput in superclass and displaying only shipname and cargo capacity
	public function showOutput(){
		echo 'Name of Ship: '.parent::getName().'<br>';
		echo 'Tonnage: '.$this->getTonnage().' tons<br>';
	}
} 

//Defining the 3 ship objects
$ship = new Ship('Gardenia Seaways', 2017);
$ship1 = new CruiseShip ('MSC Musica', 2550);
$ship2 = new CargoShip('Glovis Century', 58288);

//Creating an array of ships
$ships = array($ship, $ship1, $ship2);

//Display each ship
foreach ($ships as $key => $value) {
	$value->showOutput();
	echo '<br>';
}
?>
<footer>
<p><b>Task 6 &copy; <?php echo date('Y'); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src='task6.txt' height='400' scrolling="yes" width='1200'>
    Your browser does not support iframes.
</iframe>
</html>