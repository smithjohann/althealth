<?php
?>
<!DOCTYPE html>
<html>
    <!--Assignment 2 index.php Student 57050333-->
<head>
    <title>Assignment 2 - ICT3612</title>
</head>
<style>
    body {font-family: Arial, Helvetica, sans-serif;}
    h1 {margin-top: .5ex; color: navy; text-align: center;}
    div {margin: 0 auto; padding: .5em; line-height: -.5em; border: dotted navy;}
    section {color: brown;}
    h2 {color: seagreen;}
    footer {clear: both; margin-top: 1em; border-top: 2px solid black;}
    footer p {text-align: right; font-size: 80%; margin: 1em 0;}
</style>
<body>
    <?php include 'menu.inc';?>
    <main>
        <h1><u>Welcome to My Webpage!</u></h1>
    <div>
        <p><b><u>Owner:</u> Student 57050333 - Johann Smith</b></p>
        <p><b><u>Assignment Unique Number:</u> 798626</b></p>
                <p><b><u>Webpage:</u> https://57050333-phpwin.000webhost.com</b></p>
        <p><b>ICT3612 - Advanced Internet Programming</b></p>
        <p><b>University of South Africa (UNISA)</b></p>
    </div>
    <br>
    <section>
    <p><b>This website is built for Tasks 1 to 11 completed for Assignment 2 of ICT3612.</b></p>
    <p><b>Please select any Task in the Horizontal Menu above to display completed
            Task and accompanied iframe.</b></p>
    </section>
    <br>
    
    <h2>Thank You :)<h2>
    
    </main>
</body>
<footer>
    <p><b>Index Page &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
</html>