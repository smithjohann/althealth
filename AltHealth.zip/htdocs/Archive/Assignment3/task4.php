<html>
    <!--task4 Student 57050333-->
<head>
    <title>Task 4</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
    <?php include 'menu.inc';?>
	<h2><u>Task 4: Creating and Demonstrating the Dwelling class</u></h2>
	<br>
<?php
//Task 4 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task4.php

//Creating the class Dwelling
class Dwelling{
	//Setting the properties
    private $rooms = 2;
    private $size = 100;
	
	//The constructor
    public function _construct($rooms, $size){
        $this->rooms = $rooms;
		$this->size = $size;
    }
    
    //Set the rooms
    public function setRooms($rooms){
        $this->rooms = $rooms;
    }
    
    //Set the size
    public function setSize($size){
        $this->size = $size;
    }
    
    //Get the rooms
    public function getRooms(){
        return $this->rooms;
    }
    
    //Get the size
    public function getSize(){
        return $this->size;
    }
    
}

//The object of Dwelling created is named $example
$example = new Dwelling();
echo '<b>Getter methods used to display the room number and size:</b><br><br>';
echo '$rooms = $example->getRooms();<br>';
$rooms = $example->getRooms();
echo $rooms.'<br><br>';
echo '$size = $example->getSize();<br>';
$size = $example->getSize();
echo $size.'<br><br>';

echo '<b>Setter method used to set the rooms to 3:</b><br><br>';
echo '$example->setRooms(3);<br>';
$example->setRooms(3);
$rooms = $example->getRooms();
echo $rooms.'<br><br>';
?>
<footer>
<p><b>Task 4 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task4.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
