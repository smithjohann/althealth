<?php
//Task 9 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task9_connection.php

/////////////////////// Task 9.1 ///////////////////////
//Database called store has created and contains a tabled named inventory

//PHP Script that connects database using PDO
    $dsn = 'mysql:host=localhost;dbname=id10888579_store';
    $username = 'id10888579_storekeeper';
    $password = '570PhP@333';

//try catch exception for error handling
    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('task9_connection_error.php');
        exit();
    }
?>