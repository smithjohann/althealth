<!DOCTYPE html>
<html>

<head>
    <title>Task 9</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>

<body>
	<?php include 'menu.inc';?>
    <header><h1>Information</h1></header>

    <main>
        <h1>Database Error</h1>
        <p>There was an error connecting to the database.</p>
        <p>MySQL must be running. Please try again</p>
        <p>Error message: <?php echo $error_message; ?></p>
        <p>&nbsp;</p>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Task 9 / Student 57050333</p>
    </footer>
</body>
</html>