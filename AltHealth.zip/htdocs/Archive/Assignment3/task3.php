<?php
//Task 3 Assignment 2 ICT3612 - Student 57050333

//PHP Section for task3.php

/////////////////////// Task 3(a) ///////////////////////
//Creating the function calcCost
function calcCost($groupsize) {
	if ($groupsize < 2) {
		echo 'Error: Size of group is less than 2. Please insert different size of the group (2 or more per group).';
	} else if ($groupsize >= 2 && $groupsize <= 6) {
		$totalcost = 150 * $groupsize;
		echo 'The total cost for the group of '.$groupsize.' is R'.$totalcost.'.00';
	} else if ($groupsize >= 7 && $groupsize <= 15) {
		$totalcost = 100 * $groupsize;
		echo 'The total cost for the group of '.$groupsize.' is R'.$totalcost.'.00';
	} else if ($groupsize >= 16) {
		$totalcost = 80 * $groupsize;
		echo 'The total cost for the group of '.$groupsize.' is R'.$totalcost.'.00';
	}
}

/////////////////////// Task 3(b) ///////////////////////
//Creating the function useCheckBoxes
function useCheckBoxes() {
	$colours = filter_input(INPUT_POST, 'colour', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_REQUIRE_ARRAY);
	if ($colours !== NULL) {
		foreach($colours as $key => $value) {
			echo $value.'<br>';
		} 
		
	} else {
			echo 'No colour has been selected.<br>';
		}
}

//Creating the function useRadioButtons
function useRadioButtons() {
	$boo = filter_input(INPUT_POST, 'boo');
    if ($boo === 'true') {
        echo 'TRUE<br>';
    }   else if ($boo === 'false') {
        echo 'FALSE<br>';
    } else {
		echo 'No value has been selected.';
	}
}
?>
<html>
    <!--task3 Student 57050333-->
<head>
    <title>Task 3</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
    
    
<body>
	<?php include 'menu.inc';?>

    <main>
    <h2><u>Task 3a</u></h2>
	<br>
	<?php
	echo '<b>Demonstration of the calcCost function:</b><br><br>';
	echo '<b>calcCost(6)</b><br>';
	calcCost(6);
	echo '<br><br>';
	
	echo '<b>calcCost(10)</b><br>';
	calcCost(10);
	echo '<br><br>';
	
	echo '<b>calcCost(19)</b><br>';
	calcCost(19);
	echo '<br><br>';
	
	echo '<b>calcCost(0)</b><br>';
	calcCost(0);
	echo '<br><br>';
	?>
    </main>
    <br>
</body>

<body>
    <main>
    <h2><u>Task 3b</u></h2>

    <form action="task3.php" method="post">
        
    <p><u>Form for Task 3(b)</u></p>
	    <p>Colour:</p>
        <input type="checkbox" name="colour[]" value="Red"> Red<br>

        <input type="checkbox" name="colour[]" value="Blue"> Blue<br>

        <input type="checkbox" name="colour[]" value="Yellow"> Yellow<br>
		
		<input type="checkbox" name="colour[]" value="Green"> Green<br>
		
        <p>True or False:</p>
        <input type="radio" name="boo" value="true"> TRUE<br>
        <input type="radio" name="boo" value="false"> FALSE<br>
		
		<br>
		<input type="submit" value="Submit">
		<br>
        
    </form> 
    <br>
    <h2>Results of Input Recieved</h2>

        <label>Result of useCheckBoxes Function:</label><br>
        <span><?php useCheckBoxes(); ?></span><br>

        <label>Result of useRadioButtons:</label><br>
        <span><?php useRadioButtons(); ?></span><br>

    </main>
    <br>
</body>

<footer>
<p><b>Task 3 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task3.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
