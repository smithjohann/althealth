<html>
    <!--task7 Student 57050333-->
<head>
    <title>Task 7</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
    
    
<body>
	<?php include 'menu.inc';?>

    <main>
    <h2><u>Task 7a</u></h2>
	<?php
	//Task 7 Assignment 2 ICT3612 - Student 57050333

	//PHP Section for task7.php
	
/////////////////////// Task 7(a) ///////////////////////	
	//Demonstration 1: Assigning a valid URL to run the code (format is correct)
	$url = 'https://57050333-phpwin.000webhostapp.com/';
	echo '<b>The valid value that I used to run the code is: $url = '.$url.'</b><br>';
	$pattern = '/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i';
	if (preg_match($pattern, $url)) {
		echo "The URL is OK.";
	} else {
		echo "Wrong URL.";
	}
	echo '<br><br>';
	
	//Demonstration 2: Assigning an invalid URL to run the code (format is incorrect)
	$url = 'htt:/57050333-phpwin.000webhostapp.com/';
	echo '<b>The invalid value that I used to run the code is: $url = '.$url.'</b><br>';
	$pattern = '/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i';
	if (preg_match($pattern, $url)) {
		echo "The URL is OK.";
	} else {
		echo "Wrong URL.";
	}
	echo '<br/>';
	?>
    </main>
    <br>
</body>

<body>
    <main>
    <h2><u>Task 7b</u></h2>
	<?php
/////////////////////// Task 7(b) ///////////////////////
	//Checking string "A1357"
	$testString1 = 'A1357';
	echo "<b>testString1 = ".$testString1."</b><br>";
	$pattern = '/^[A-Za-z0-9]{5}/';
	if (preg_match($pattern, $testString1)) {
		echo 'The first 5 characters are alpha numeric characters.<br>';
	} else {
		echo 'The first 5 characters are NOT alpha numeric characters.<br>';
	}
	
	echo '<br>';
	
	//Checking string "#5678"
	$testString2 = '#5678';
	echo "<b>testString2 = ".$testString2."</b><br>";
	$pattern = '/^[A-Za-z0-9]{5}/';
	if (preg_match($pattern, $testString2)) {
		echo 'The first 5 characters are alpha numeric characters.<br>';
	} else {
		echo 'The first 5 characters are NOT alpha numeric characters.<br>';
	}
	
	echo '<br>';
	
	//Checking string "123456"
	$testString3 = 'A1357';
	echo "<b>testString3 = ".$testString3."</b><br>";
	$pattern = '/^[A-Za-z0-9]{5}/';
	if (preg_match($pattern, $testString3)) {
		echo 'The first 5 characters are alpha numeric characters.<br>';
	} else {
		echo 'The first 5 characters are NOT alpha numeric characters.<br>';
	}
	?>
    </main>
    <br>
</body>

<footer>
<p><b>Task 7 &copy; <?php echo date("Y"); ?> Student 57050333_ICT3612_Assignment 2</b></p>
</footer>
<iframe src="task7.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
