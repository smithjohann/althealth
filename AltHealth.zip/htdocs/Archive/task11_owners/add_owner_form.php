<?php
//Johann AppStage Assessment

//add_owner_form.php page
//Adding a new owner to the database - Confirmation displayed in owner_result.php
?>
<!DOCTYPE html>
<html>

<head>
    <title>Add Owner</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
    <section>
        
    <h2><b><u>Add New Owner</u></b></h2>
		<label>Please fill in the form below to add a new owner.</label><br>
        <br>  

		<!--Form to insert new owner into the DB-->
        <form action="owner_result.php" method="post" id="add_owner_form">
            
            <label>ID Number:</label>
            <input type="text" name="newId" class="textbox" maxlength="13"><br> <!--ID Number verification-->

            <label>Name:</label>
            <input type="text" name="newName" class="textbox"><br>

            <label>Surname:</label>
            <input type="text" name="newSurname" class="textbox"><br>
			
			<label>Phone Number:</label>
            <input type="text" name="newPhone" class="textbox" maxlength="10"><br>

            <label>E-Mail Address:</label>
            <input type="text" name="newEmail" class="textbox"><br> <!--confirm email validation-->
			
			<label>Postal Address:</label>
            <input type="text" name="newEmail" class="textbox"><br> <!--textfield???-->

            <input type="submit" value="Save"><br>
        </form>
    </section>
</main>

</body>
<br/>
<p><a href="index.php">Back to Owner Management Menu</a></p>
<footer>
<p><b>Johann Smith &copy; <?php echo date("Y"); ?></b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
