<?php
//Johann AppStage Assessment //DONE, JUST NEED STYLE

//index.php page for task11_owners
?>
<html>

<head>
    <title>Owner Management</title>
	<link rel="stylesheet" type="text/css" href="../main.css">
</head>
<body>
	<?php include '../task11_view/menu.inc';?> <!-- CSS IS BEING USED FROM THE MENU.INC FILE-->
    <main>
	 <h2><u>Owner Management</u></h2>
	 <br>
	<a href="add_owner_form.php">Add a New Owner</a>
	<br>
	<a href="search_owner.php">Search & Modify an Owner</a>
	<br>
	<a href="all_owners.php">View All Owners</a>
	<br>
	<a href="../task11.php">Back to Main Menu</a> <!-- BLUE BUTTON -->
    </main>
    <br>
</body>

<footer>
<p><b>Johann Smith &copy; <?php echo date("Y"); ?></b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>
