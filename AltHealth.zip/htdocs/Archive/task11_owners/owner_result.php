<?php
//Johann AppStage Assessment

//owner_result.php page
//The page displaying the result(s) whether an owner is being searched, updated or deleted

//connecting to database via connection.php in the model folder
require('../task11_model/connection.php');


//Determining if an Update is being processed and then processing the update (using UPDATE statement)
if (filter_input(INPUT_POST, 'idU') != '') {
	$name_update = filter_input(INPUT_POST, 'nameU');
	$surname_update = filter_input(INPUT_POST, 'surnameU'); 
	$phone_update = filter_input(INPUT_POST, 'phoneU');
	$email_update = filter_input(INPUT_POST, 'emailU');
	$id_update = filter_input(INPUT_POST, 'idU');
	$add_update = filter_input(INPUT_POST, 'addU');
  
	//Updating the owner
    $queryU = 'UPDATE tblowners
               SET OwnerName = :ownerName, OwnerSurname = :ownerSurname, OwnerPhone = :ownerPhone, OwnerEmail = :ownerEmail 
               WHERE OwnerID = :ownerId';
    $statementU = $db->prepare($queryU);
	$statementU->bindValue(':ownerId', $id_update);
    $statementU->bindValue(':ownerName', $name_update);
    $statementU->bindValue(':ownerSurname', $surname_update);
    $statementU->bindValue(':ownerPhone', $phone_update);
	$statementU->bindValue(':ownerEmail', $email_update);
	$statementU->bindValue(':ownerAddress', $add_update);
    $statementU->execute();
    $statementU->closeCursor();
	
	//Display the updated owner
	$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerId', $id_update);
	$statementA->execute();
	$owners = $statementA->fetchAll();
	$statementA->closeCursor();
	
	$result = "$id_update $name_update $surname_update has been updated successfully";
}


//Determining if a Deletion is requested and then processing the deletion (using DELETE statement)
if (filter_input(INPUT_POST, 'owner_delete') != '') {
	$owner_delete = filter_input(INPUT_POST, 'owner_delete');
    $query = 'DELETE FROM tblowners
              WHERE OwnerID = :ownerId';
    $statement = $db->prepare($query);
    $statement->bindValue(':ownerId', $owner_delete);
    $success = $statement->execute();
    $statement->closeCursor();

	//redirecting to the index page after the owner has been deleted
	header("Location: index.php");
}


//Determining if a new owner is being inserted and then inserting the new owner (using INSERT statement)
if (filter_input(INPUT_POST, 'newId') != '') {
	$id = filter_input(INPUT_POST, 'newId');
	$name = filter_input(INPUT_POST, 'newName');
	$surname = filter_input(INPUT_POST, 'newSurname');
	$phone = filter_input(INPUT_POST, 'newPhone');
	$email = filter_input(INPUT_POST, 'newEmail');
	$address = filter_input(INPUT_POST, 'newAddress');

	//adding new owner (row) into the database 
    $query = 'INSERT INTO tblowners
                 (OwnerID, OwnerName, OwnerSurname, OwnerPhone, OwnerEmail)
              VALUES
                 (:ownerId, :ownerName, :ownerSurname, :ownerPhone, :ownerEmail)';
    $statement = $db->prepare($query);
    $statement->bindValue(':ownerId', $id);
    $statement->bindValue(':ownerName', $name);
    $statement->bindValue(':ownerSurname', $surname);
	$statement->bindValue(':ownerPhone', $phone);
    $statement->bindValue(':ownerEmail', $email);
	$statement->bindValue(':ownerAddress', $address);
    $statement->execute();
    $statement->closeCursor();
	
	$result = "New Owner ($name $surname) Successfully Added";
	
	//Display the new owner
	$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerId', $id);
	$statementA->execute();
	$owners = $statementA->fetchAll();
	$statementA->closeCursor();
}	

//Determining if a search is being performed and then processing the search (using SELECT statement)
if (filter_input(INPUT_POST, 'id_search') != '') {
$id_search = filter_input(INPUT_POST, 'id_search');

$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
$statementA = $db->prepare($queryAll);
$statementA->bindValue(':ownerId', $id_search);
$statementA->execute();
$owners = $statementA->fetchAll();
$statementA->closeCursor();

$result = "Displaying information for ID Number $id_search";
}

//Determining if a search is being performed from the units management app and then processing the search (using SELECT statement)
if (filter_input(INPUT_POST, 'unit_owner') != '') {
$owner = filter_input(INPUT_POST, 'unit_owner');

$queryAll = 'SELECT * FROM tblowners
             WHERE OwnerID = :ownerId';
$statementA = $db->prepare($queryAll);
$statementA->bindValue(':ownerId', $owner);
$statementA->execute();
$owners = $statementA->fetchAll();
$statementA->closeCursor();

$result = "Displaying information for the owner with ID Number $owner";
}
?>
<!DOCTYPE html>
<html>
    <!--task11 Student 57050333-->
<head>
    <title>Task 11</title>
    <link rel="stylesheet" type="text/css" href="../main.css" />
</head>
<body>
    <?php include '../task11_view/menu.inc';?>
<main>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <section>
        <table>
            <tr>
                <th>ID Number</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Phone</th>
				<th>E-Mail</th>
				<th>Address</th>
            </tr>

            <?php foreach ($owners as $owner) : ?>
            <tr>
                <td><?php echo $owner['OwnerID']; ?></td>
                <td><?php echo $owner['OwnerName']; ?></td>
                <td><?php echo $owner['OwnerSurname']; ?></td>
				<td><?php echo $owner['OwnerPhone']; ?></td>
                <td><?php echo $owner['OwnerEmail']; ?></td>
				<td><?php echo $owner['OwnerAddress']; ?></td>
				
			<td><form action="update_owner.php" method="post">
                    <input type="hidden" name="owner_update"
                           value="<?php echo $owner['OwnerID']; ?>">
                    <input type="submit" value="Update">
                </form></td>
				

				<td><form action="owner_result.php" method="post">
                    <input type="hidden" name="owner_delete"
                           value="<?php echo $owner['OwnerID']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table>
</main>

</body>
<br/>
<section>

<p><a href="add_owner_form.php">Add New Owner</a></p>
<p><a href="index.php">Back to Owner Management Menu</a></p>
<p><a href="../task11_units/index.php">Unit Management Menu</a></p>
</section>
<footer>
<p><b>Johann Smith &copy; <?php echo date("Y"); ?></b></p>
</footer>
<iframe src="../task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>