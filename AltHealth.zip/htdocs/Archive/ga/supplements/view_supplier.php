<?php
// Student 57050333
// view_supplier.php - Small form with droplist enabling to view a certain supplier

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Query to fill drop-down list with the suppliers availiable
$suppliers = suppliers();
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Supplier</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>

   
    <h1><u>View a Supplier</u></h1>

  <div class="container">
  
  <!-- Form for displaying the drop-list -->
  <form method="get" id="search" action="supplier_result.php">
  <div class="row">
    <div class="col-20">
      <label for="supplier">Supplier</label>
    </div>
    <div class="col-80">
      <select id="supplier" name="search">
        <option disabled value="">----Select Supplier----</option>
            <?php foreach ($suppliers as $supplier) : ?>
                <option value="<?php echo $supplier['supplier_id']; ?>"><?php echo $supplier['supplier_id']; ?></option>
            <?php endforeach; ?>
            </select>
			<span class="error"><b>*</b></span>
    </div>
  </div>
  
  <div class="row">
  <br>
    <input type="submit" value="Search Supplement" style="float: left;">
	</div>
  </div>
  </form>

</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>