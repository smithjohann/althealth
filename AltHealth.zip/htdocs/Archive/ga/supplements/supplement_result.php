<?php
// Student 57050333
// client_result.php - Displaying the supplement which was successfully added, updated or searched for

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Determining if a supplement was added and displaying the supplement's data
if (htmlspecialchars($_GET['new']) != '') {
	$sup = htmlspecialchars($_GET['new']);
	$supplements = new_supplement();
	$result = "New Supplement ($sup) Successfully Added";
} elseif (htmlspecialchars($_GET['updated']) != '') {
	$sup = htmlspecialchars($_GET['updated']);
	$supplements = update_supplement();
	$result = "Supplement ($sup) Successfully Updated";
} elseif (htmlspecialchars($_GET['search']) != '') {
	$sup = htmlspecialchars($_GET['search']);
	$supplements = search_supplement();
	$result = "Showing details of $sup";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Supplement Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo"><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <div class="container">
        <table>
            <tr>
                <th>Supplement</th>
                <th>Description</th>
                <th>Cost Excl.</th>
                <th>Cost Incl.</th>
				<th>Markup</th>
                <th>Client Cost</th>
                <th>Supplier</th>
                <th>Minimum Level</th>
				<th>Current Level</th>
				<th>NAPPI Code</th>
            </tr>

            <?php foreach ($supplements as $supplement) : ?>
            <tr>
                <td><?php echo $supplement['SUPPLEMENT_ID']; ?></td>
                <td><?php echo $supplement['SUP_DESCRIPTION']; ?></td>
				<td><?php echo 'R' . $supplement['COST_EXCL']; ?></td>
				<td><?php echo 'R' . $supplement['COST_INCL']; ?></td>
                <td><?php echo 'R' . $supplement['PROFIT_MARKUP']; ?></td>
                <td><?php echo 'R' . $supplement['COST_CLIENT']; ?></td>
				<td><?php echo $supplement['SUPPLIER_ID']; ?></td>
				<td><?php echo $supplement['MIN_LEVELS']; ?></td>
				<td><?php echo $supplement['CURRENT_LEVEL']; ?></td>
				<td><?php if (empty($supplement['NAPPI'])) { echo "No NAPPI Provided";} else {echo $supplement['NAPPI'];} ?></td>
			
			<td><form action="update_supplement.php" method="get">
                    <input type="hidden" name="supplement_update"
                           value="<?php echo $supplement['SUPPLEMENT_ID']; ?>"></input>
                    <input type="submit" value="Update"></input>
                </form></td>
				
			<td><form action="supplier_result.php" method="get">
                    <input type="hidden" name="search"
                           value="<?php echo $supplement['SUPPLIER_ID'];; ?>"></input>
                    <input type="submit" value="Show Supplier"></input>
                </form></td>

            </tr>
            <?php endforeach; ?>
        </table>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>