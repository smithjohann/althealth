<?php
// Student 57050333
// supplier_supplements.php - A list to view the supplements the specific supplier sells. This list can be printable.

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Retrieving the supplier_id and assigning to a variable
$supplier_id = htmlspecialchars(filter_input(INPUT_GET, 'supplier_id'));

// Performing the query by using the supplier_supplements() function
$supplements = supplier_supplements($supplier_id);
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Supplier Supplements</title>
			<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
		   <link rel="stylesheet" type="text/css" href="../view/main.css" />  
		   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
      </head>  
      <body>
	<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
	<?php include '../view/navbar.html';?>
<main>
	  <section>
           <div>  
                <h1><u>Supplements of <?php echo $supplier_id;?></u></h1>  
                <div>
		<br>
		<table>
            <tr>
                <th>Supplement</th>
				<th>Description</th>
            </tr>

            <?php foreach ($supplements as $supplement) : ?>
            <tr>
				<td><?php echo $supplement['SUPPLEMENT_ID']; ?></td>
                <td><?php echo $supplement['SUP_DESCRIPTION']; ?></td>
			</tr>	
            	<?php endforeach; ?>
        </table>
		</div>
		<br>
           </div>  
		   </section>
		   </main>
<footer>
	<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>