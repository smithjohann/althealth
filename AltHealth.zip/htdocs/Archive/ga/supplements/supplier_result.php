<?php
// Student 57050333
// supplier_result.php - Displaying the supplier who was successfully added, updated or searched for

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

//determining if a supplement was added and displaying the supplement's data
if (htmlspecialchars($_GET['new']) != '') {
	$sup = htmlspecialchars($_GET['new']);
	$suppliers = new_supplier();
	$result = "New Supplier ($sup) Successfully Added";
} elseif (htmlspecialchars($_GET['updated']) != '') {
	$sup = htmlspecialchars($_GET['updated']);
	$suppliers = update_supplier();
	$result = "Supplier ($sup) Successfully Updated";
} elseif (htmlspecialchars($_GET['search']) != '') {
	$sup = htmlspecialchars($_GET['search']);
	$suppliers = search_supplier();
	$result = "Showing details of $sup";
} else {
	$sup = filter_input(INPUT_POST, 'supplier_id');
	$suppliers = searching_supplier($sup);
	$result = "Showing details of $sup";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Supplier Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h2><?php echo $result;?></h2>
    <div class="container">
	<h2>Supplier Contact Information</h2>
        <table>
            <tr>
                <th>Supplier ID</th>
				<th>Contact Person</th>
                <th>Telephone</th>
				<th>Fax</th>
                <th>Cellphone</th>
                <th>Email</th>
            </tr>

            <?php foreach ($suppliers as $supplier) : ?>
            <tr>
				<td><?php echo $supplier['SUPPLIER_ID']; ?></td>
                <td><?php echo $supplier['CONTACT_NAME']; ?></td>
                <td><?php echo $supplier['S_TEL']; ?></td>
                <td><?php echo $supplier['S_FAX']; ?></td>
				<td><?php echo $supplier['S_CELL']; ?></td>
				<td><?php echo $supplier['S_EMAIL']; ?></td>
			</tr>	
            
        </table>
		<br>
		<?php if (!empty($supplier['BANK'])) { ?>
		<h2>Supplier Banking Details</h2>
		<table>
			<tr>
				<th>Bank</th>
                <th>Branch Code</th>
                <th>Account Number</th>
				<th>Account Type</th>
			</tr>
			
			<tr>
				<td><?php echo $supplier['BANK']; ?></td>
                <td><?php echo $supplier['BRANCH_CODE']; ?></td>
                <td><?php echo $supplier['ACC_NUM']; ?></td>
				<td><?php echo $supplier['ACC_TYPE']; ?></td>
            </tr>
		<?php } else {echo "<b>No banking details is on file for this supplier.</b><br>";} ?>	
		</table>
		<br>
		<h2>Comments:</h2> 
		<a><?php if (empty($supplier['COMMENTS'])) { echo "<b>No comments are on file.</b>"; } else { echo $supplier['COMMENTS']; }?></a>
		<br>

		<div class="row">
		<br>
		<div class="col-but-01">
		<form action="update_supplier.php" method="get">
            <input type="hidden" name="supplier_update" 
            value="<?php echo $supplier['SUPPLIER_ID']; ?>">
            <input type="submit" value="Update" style="float: left;">
        </form>
		</div>
		<a>    </a>
		<div class="col-but-02">
		<form action="supplier_supplements.php" method="get">
            <input type="hidden" name="supplier_id"
            value="<?php echo $supplier['SUPPLIER_ID']; ?>">
            <input type="submit" value="View Supplements" style="float: left;">
        </form>
		</div>
				
<?php endforeach; ?>
</div>
</main>

</body>
<br/>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>