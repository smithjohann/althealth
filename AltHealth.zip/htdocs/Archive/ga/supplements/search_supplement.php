<?php
// Student 57050333
// search_supplement.php - End-user searching for a supplement to view its information

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// assigning the $task variable
$task = 'search';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Supplement</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/supplement_validation.php');?>
   
  <h1><u>Search for a Supplement</u></h1>

  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->

  
  <!-- Form for searching a supplement -->
  <form method="post" id="search_supplement" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-25">
      <label for="supplement">Supplement ID</label>
    </div>
    <div class="col-75">
      <input type="text" id="supplement" name="supplement" placeholder="Enter Supplement ID" value="<?php echo $supplement;?>">
  <span class="error"><b>* <?php echo $supplementErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
  <br>
    <input type="submit" value="Search Supplement" style="float: left;">
	</div>
  </div>
  </form>
  
  <br>
  
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>