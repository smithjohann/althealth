<?php
// Student 57050333
// booking_successful.php - This page displays when the booking is successful and wheteher an email has been sent or not

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions, which also includes a connection to the database
include '../util/functions.php';

// Determining if the booking is successful and retrieving the booking number generated in the db
if (htmlspecialchars($_GET['booking']) != '') {
	$booking_number = htmlspecialchars($_GET['booking']);
	$booking = booking_information($booking_number);
	$booking_date = $booking['APP_DATE'];
	$booking_timeslot = $booking['APP_TIME_START'] . " - " . $booking['APP_TIME_END'];
	$result = "Booking Confirmed for $booking_date";
}

// Determining whether the email was successful in sending to the patient and displaying a message in the page
if (htmlspecialchars($_GET['email']) == 'unsuccessful') {
	$email_feedback = "A confirmation email could not be sent to the client due to an error that has occured.<br><br>Please check if the patient has a valid email address, or contact the system administrator.";
} else {
	$email_feedback = "A confirmation email has been sent to the patient.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h1><?php echo $result;?></h1>
    <div class="container">
        <table>
            <tr>
                <th>Booking Number</th>
                <th>Patient ID</th>
				<th>Date of Appontment</th>
                <th>Time of Appointment</th>
                <th>Appointment End Time</th>
            </tr>

            <tr>
                <td><?php echo $booking['BOOKING_NUM']; ?></td>
                <td><?php echo $booking['CLIENT_ID']; ?></td>
                <td><?php echo $booking['APP_DATE']; ?></td>
				<td><?php echo $booking['APP_TIME_START']; ?></td>
				<td><?php echo $booking['APP_TIME_END']; ?></td>
			
			<td><form action="cancel_booking.php" method="post">
                    <input type="hidden" name="clientid" value="<?php echo $booking['CLIENT_ID']; ?>">
					<input type="hidden" name="booking" value="<?php echo $booking['BOOKING_NUM']; ?>">
					<input type="hidden" name="date" value="<?php echo $booking['APP_DATE']; ?>">
                    <input type="submit" value="Cancel Booking">
                </form></td>

            </tr>
        </table>
		<br>
		<!--Displaying appropriete feedback regarding the email-->
		<span class="error-blue"><b><?php echo $email_feedback;?></b></span>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>