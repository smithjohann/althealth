<?php
// Student 57050333
// search_appointment.php - Searching for a client's appointment by entering the client's ID number

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// $task variable used in the validation script
$task = 'search';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Appointment</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/booking_validation.php');?>
   
  <h1><u>Search Booking with Patient ID</u></h1>

  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php //echo $validation_error;?></b></span>
  
  <!-- Form for searching for the client's appointments -->
  <form method="post" id="search_id" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-25">
      <label for="clientid">Patient ID Number</label>
    </div>
    <div class="col-75">
      <input type="text" id="clientid" name="clientid" placeholder="Please enter 13 Digit RSA ID Number" maxlength="13" value="<?php echo $id;?>">
  <span class="error"><b>* <?php echo $idErr;?></b></span>
    </div>
  </div>
  
  <div class="row">
  <br>
    <input type="submit" value="Search" style="float: left;">
	</div>
  </div>
  </form>
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>