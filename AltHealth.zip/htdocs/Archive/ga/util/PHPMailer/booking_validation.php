<?php
// Student 57050333
// Validation php script for add_client and update_client forms

// Function to ensure no whitespace or or is present in user's input
 function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
    return $d && $d->format($format) === $date;
}

// Declaring empty variables 
$bookingDateErr = "";
$id = $idErr = "";
$bookingNum = $bookingNumErr = "";

//$validation_error = "";
/*
if ($task == 'search_slot') {
	$bookingDate = '';
}
*/

// Performing validation on each entry and performs necessary action once the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if (empty($_POST["clientid"])) {
			$idErr = "SA ID Number required";
		} else {
			$id = test_input($_POST["clientid"]);
			// check if ID number only contains a number input and contains 13 digits
			if (!preg_match('/^[0-9]{13}$/', $id)) { 
				$idErr = "Invalid ID Number";
			} else {
				// validating if a valid birthdate (first 6 digits of ID) has been entered 
				$date = substr($id, 0, 6);
				$year = substr($date, 0, 2);
				$month = substr($date, 2, 2);
				$day = substr($date, 4, 6);
				if (checkdate($month, $day, $year) === FALSE) {
					$idErr = "Invalid ID Number due to incorrect Date of Birth";
				}
				$result = verify_client_exists_upon_insert($id);
				if ($task == 'insert') {
					if (empty($result)) {
						$idErr = "This client does not exist on the system. Please add the client first before making a booking.";
					}
				} 
			} 
		}
		
	if (empty($_POST["booking_num"])) {
		$bookingNumErr = "Please enter a booking number";
		} else {
			$bookingNum = test_input($_POST["booking_num"]);
			// check if postal code only contains numbers
			if (!preg_match("/^[0-9]$/",$bookingNum)) {
				$bookingNumErr = "Invalid booking number entered";
			}
		}
  
	if ($idErr == "" && $task = 'search_appt') {
	  header('Location:appointment_result.php?search='.$id);
	}
  
	if ($bookingNumErr == "" && $task = 'search_appt') {
	  header('Location:appointment_result.php?booking='.$bookingNum);
	}

	if ($task == 'search_slot') {
		$bookingDate = '';
		if (empty($_POST["date"])) {
			$bookingDateErr = "Valid date required";
		} elseif (validateDate($_POST["date"]) === TRUE) {
			$date = htmlspecialchars($_POST["date"]);
			
		}
	}
	/*
	if ($task == 'search') {
	  if (empty($_POST["clientid"])) {
			$idErr = "SA ID Number required";
		} else {
			$id = test_input($_POST["clientid"]);
			// check if ID number only contains a number input and contains 13 digits
			if (!preg_match('/^[0-9]{13}$/', $id)) { 
				$idErr = "Invalid ID Number";
			} else {
				// validating if a valid birthdate (first 6 digits of ID) has been entered 
				$date = substr($id, 0, 6);
				$year = substr($date, 0, 2);
				$month = substr($date, 2, 2);
				$day = substr($date, 4, 6);
				if (checkdate($month, $day, $year) === FALSE) {
					$idErr = "Invalid ID Number due to incorrect Date of Birth";
				} else {
					//DO A QUERY TO SEE IF THE PATIENT IS ON THE DB
					$valid_client = "";
				}
			} 
		}
		
	if (empty($_POST["booking_num"])) {
    $bookingNumErr = "Please enter a booking number";
	} else {
    $bookingNum = test_input($_POST["booking_num"]);
	// check if postal code only contains numbers
    if (!preg_match("/^[0-9]$/",$bookingNum)) {
        $bookingNumErr = "Invalid booking number entered";
    }
  }
 
  
  if ($id != '' && $idErr == '') {
	  header('Location:appointment_result.php?search='.$id);
  }
  
  if ($bookingNum != '' && $bookingNumErr == '') {
	  header('Location:appointment_result.php?booking='.$id);
  }
  
  }//end of $task = search 
  */
  
 /*
  if($bookingDateErr == "" ){
	// initialising the database connection
	require('connection.php');
	
	if ($task = 'search_avl') {
		header('Location:availiable_slots.php?search='.$date);
	}
	
   }
*/	
	
	if ($task == 'booking_timeslot') {
		if (empty($_POST["clientid"])) {
			$idErr = "SA ID Number required";
		} else {
			$id = test_input($_POST["clientid"]);
			// check if ID number only contains a number input and contains 13 digits
			if (!preg_match('/^[0-9]{13}$/', $id)) { 
				$idErr = "Invalid ID Number";
			} else {
				// validating if a valid birthdate (first 6 digits of ID) has been entered 
				$date = substr($id, 0, 6);
				$year = substr($date, 0, 2);
				$month = substr($date, 2, 2);
				$day = substr($date, 4, 6);
				if (checkdate($month, $day, $year) === FALSE) {
					$idErr = "Invalid ID Number due to incorrect Date of Birth";
				} /*else {
					//DO A QUERY TO SEE IF THE PATIENT IS ON THE DB
					$valid_client = "";
				}*/
			} 
		}
	
	
	//if ($valid_client == 'Yes' && $idErr == '') {}
	$slot = $_POST["booking_slot"];
	$time_start = substr($slot,0,5);
	$time_end = substr($slot,8,5);
	$bookingDate = $_POST["booking_date"];
	
	require('connection.php');
	
		//Adding the booking to the system
		$query = 'INSERT INTO tblbookingsinfo
				(CLIENT_ID, APP_DATE, APP_TIME_START, APP_TIME_END)
				VALUES
				(:clientid, :date, :time_start, :time_end)';
		$statementA = $db->prepare($query);
		$statementA->bindValue(':clientid', $id);
		$statementA->bindValue(':date', $bookingDate);
		$statementA->bindValue(':time_start', $time_start);
		$statementA->bindValue(':time_end', $time_end);
		$statementA->execute();
		$statementA->closeCursor();
		
		//Preparing the patient's notes section
		$query = 'INSERT INTO tblpatientnotes
				(CLIENT_ID, APP_DATE)
				VALUES
				(:clientid, :date)';
		$statementB = $db->prepare($query);
		$statementB->bindValue(':clientid', $id);
		$statementB->bindValue(':date', $bookingDate);
		$statementB->execute();
		$statementB->closeCursor();
		
		$query = 'SELECT * FROM tblclientdata
				  WHERE CLIENT_ID = :clientid';
		$statementC = $db->prepare($query);
		$statementC->bindValue(':clientid', $id);
		$statementC->execute();
		$clients = $statementC->fetchAll();
		$statementC->closeCursor();
		
		$query = 'SELECT * FROM tblbookingsinfo
				  WHERE CLIENT_ID = :clientid AND APP_DATE = :date';
		$statementD = $db->prepare($query);
		$statementD->bindValue(':clientid', $id);
		$statementD->bindValue(':date', $bookingDate);
		$statementD->execute();
		$booked = $statementD->fetchAll();
		$statementD->closeCursor();
		
		foreach ($booked as $booked) {
			$booking_number = $booked['BOOKING_NUM'];
		}
	
		foreach ($clients as $client) {
			$first_name = $client['C_NAME'];
			$surname = $client['C_SURNAME'];
			$email = $client['C_EMAIL'];
		}
		require_once 'message.php';

        // Set up email variables
        $to_address = $email;
        $to_name = $first_name . ' ' . $surname;
        $from_address = 'althealth.57050333@gmail.com';
        $from_name = 'AltHealth';
        $subject = 'Appointment Confirmation';
        $body = '
		<html>
	<head>
		<meta charset="utf-8">
		<title>AltHealth Invoice</title>
		<style>
		/* heading */

h1 { 
font: bold 100% sans-serif; 
letter-spacing: 0.25em; 
text-align: left;  
}

/* table */

table { 
font-size: 75%; 
table-layout: fixed; 
width: 100%;
border-collapse: separate; 
border-spacing: 2px; 
}

th, td { 
border-width: 1px; 
padding: 0.5em; 
position: relative; 
text-align: left; 
border-radius: 0.25em; 
border-style: solid; 
}

th { 
background: #EEE; 
border-color: #BBB; 
}

td { 
border-color: #DDD; 
}

/* page */

html { 
font: 16px/1 "Open Sans", sans-serif; 
overflow: auto; 
padding: 1cm; 
background: #999; 
}


body { 
box-sizing: border-box; 
height: 29cm; 
margin: 0 auto; 
overflow: hidden; 
padding: 0.5in; 
width: 8.5in; 
}

body { 
background: #FFF; 
border-radius: 1px; 
}

/* header */

header { 
margin: 0 0 3em; 
float: right;
}

header:after { 
clear: both; 
content: ""; 
display: table; 
}

header h1 { color: rgb(59, 161, 185); border-radius: 0.25em;  margin: 0 0 1em; padding: .5em 0 .0em; }
header address { float: right; font-size: 75%; font-style: normal; line-height: 1.25; margin: 0 1em 1em 0; }
header address p { margin: 0 0 0.25em; }
header span, header img { display: block; float: right; }
header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 50%; position: relative; }

/* main */

main, main address, table.side, table.charge { margin: 0 0 3em; }
main:after { clear: both; content: ""; display: table; }
main h1 { clip: rect(0 0 0 0); position: absolute; }

main address { 
float: left; 
font-size: 100%; 
font-weight: bold; 
}

/* table side & balance */

table.side, table.balance { float: right; width: 36%; }
table.side:after, table.balance:after { clear: both; content: " "; display: table; }

/* table side */

table.side th { width: 50%; }
table.side td { width: 50%; }

/* table items */

table.charge { clear: both; width: 100%; }
table.charge th { font-weight: bold; text-align: center; }

/* table balance */
table.balance { float: left }
table.balance th, table.balance td { width: 50%; }
table.balance td { text-align: right; }

/* aside */

aside h1 { text-align: center; border: none; border-width: 0 0 1px; margin: 0 0 1em; border-color: #999; border-bottom-style: solid; }
aside div { font-family: calibri, ariel; }
aside { border-bottom-style: solid; border-color: #999; border-width: 0 0 1px;}

/* footer */

footer p { font-family: cambria, sans-serif; text-align: center;}


		</style>
	</head>
	<body>
		<header>
			<h1>AltHealth</h1>
			<address>
				<p>Mr Casey Millan<br>Cell: 082 471 2929</p>
			</address>
			<br>
		</header>
		<br>
		<main>
			<p>Good Day ' . $to_name . '</p>
                <p>This email is to confirm your appontment on the ' . $bookingDate . ' for ' . $time_start . ' until ' . $time_end . '.</p>
                <p>Thank you for your support. We look forward to see you soon!</p>' .
				'</p>
		</main>
		<br>

		<footer>
		<p><span><p>Kind Regards,<br>
				AltHealth</span></p>
		</footer>
	</body>
</html>';
        $is_body_html = true;
        
        // Send email
        try {
            send_email($to_address, $to_name, 
                    $from_address, $from_name, 
                    $subject, $body, $is_body_html);
			header('Location:booking_successful.php?booking='.$booking_number);		
        } catch (Exception $ex) {
            $error = $ex->getMessage();
            include 'availiable_slots.php';
        }        
	}
}
////////////////////////////////////////////////////////////  
?>