<?php
// Student 57050333
// Functionality to send a birthday email to all client's who celebrates a birthday today
// This functionality is executed once the HCP presses the "Email Birthday Message to All" button on the main page or on the day-to-day reports page

//connection  to connection.php for database
include '../util/functions.php';
// Initilalising today's date
$date_today = date('Y-m-d'); //YYYY-MM-DD

// Retrieving all birthdays today
$birthdays = dtd_2();

foreach ($birthdays as $birthday) {
	$name = $birthday['c_name'] . " " . $birthday['c_name'];
	$email = $birthday['c_email'];
	
	require_once 'message.php';

        // Set up email variables
        $to_address = '5705333.js@gmail.com';//$email;
        $to_name = $name;
        $from_address = 'althealth.57050333@gmail.com';
        $from_name = 'AltHealth';
        $subject = 'Happy Birthday ' . $birthday['c_name'];
        $body = '
		<html>
	<head>
		<meta charset="utf-8">
		<title>A Happy Birthday to You!</title>
		<style>
		/* heading */

h1 { 
font: bold 100% sans-serif; 
letter-spacing: 0.25em; 
text-align: left;  
}

/* table */

table { 
font-size: 75%; 
table-layout: fixed; 
width: 100%;
border-collapse: separate; 
border-spacing: 2px; 
}

th, td { 
border-width: 1px; 
padding: 0.5em; 
position: relative; 
text-align: left; 
border-radius: 0.25em; 
border-style: solid; 
}

th { 
background: #EEE; 
border-color: #BBB; 
}

td { 
border-color: #DDD; 
}

/* page */

html { 
font: 16px/1 "Open Sans", sans-serif; 
overflow: auto; 
padding: 1cm; 
background: #999; 
}


body { 
box-sizing: border-box; 
height: 29cm; 
margin: 0 auto; 
overflow: hidden; 
padding: 0.5in; 
width: 8.5in; 
}

body { 
background: #FFF; 
border-radius: 1px; 
}

/* header */

header { 
margin: 0 0 3em; 
float: right;
}

header:after { 
clear: both; 
content: ""; 
display: table; 
}

header h1 { color: rgb(59, 161, 185); border-radius: 0.25em;  margin: 0 0 1em; padding: .5em 0 .0em; }
header address { float: right; font-size: 75%; font-style: normal; line-height: 1.25; margin: 0 1em 1em 0; }
header address p { margin: 0 0 0.25em; }
header span, header img { display: block; float: right; }
header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 50%; position: relative; }

/* main */

main, main address, table.side, table.charge { margin: 0 0 3em; }
main:after { clear: both; content: ""; display: table; }
main h1 { clip: rect(0 0 0 0); position: absolute; }

main address { 
float: left; 
font-size: 100%; 
font-weight: bold; 
}

/* table side & balance */

table.side, table.balance { float: right; width: 36%; }
table.side:after, table.balance:after { clear: both; content: " "; display: table; }

/* table side */

table.side th { width: 50%; }
table.side td { width: 50%; }

/* table items */

table.charge { clear: both; width: 100%; }
table.charge th { font-weight: bold; text-align: center; }

/* table balance */
table.balance { float: left }
table.balance th, table.balance td { width: 50%; }
table.balance td { text-align: right; }

/* aside */

aside h1 { text-align: center; border: none; border-width: 0 0 1px; margin: 0 0 1em; border-color: #999; border-bottom-style: solid; }
aside div { font-family: calibri, ariel; }
aside { border-bottom-style: solid; border-color: #999; border-width: 0 0 1px;}

/* footer */

footer p { font-family: cambria, sans-serif; text-align: center;}


		</style>
	</head>
	<body>
		<header>
			<h1>AltHealth</h1>
			<address>
				<p>Mr Casey Millan<br>Cell: 082 471 2929</p>
			</address>
			<br>
		</header>
		<br>
		<main>
			<p>Hello ' . $birthday['c_name'] . '</p>
                <p>From all of us at AltHealth, we would like to wish you a Happy and Healthy Birthday!</p>
                <p>Thank you for your continous support. Do not forget to have a look at our website for the latest deals we have on offer!</p>' .
				'</p>
		</main>
		<br>

		<footer>
		<p><span><p>Warmest Regards,<br>
				AltHealth</span></p>
		</footer>
	</body>
</html>';
        $is_body_html = true;
        
        // Send email
        try {
            send_email($to_address, $to_name, 
                    $from_address, $from_name, 
                    $subject, $body, $is_body_html);
			header('Location:../index.php?email=success');		
        } catch (Exception $ex) {
            $error = $ex->getMessage();
            header('Location:../index.php?email=unsuccessful');
        }        
	}

?>