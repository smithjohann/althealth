<?php
// Student 57050333
// Validation php script for the supplier section (inserting or updating)

// Function to ensure no whitespace or or is present in user's input
 function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

// Function to determine if the supplier exists
function verify_supplier_exists_upon_insert($supplier) {
	global $db;
	$queryAll = 'SELECT supplier_id FROM tblsuppliers
						 WHERE supplier_id = :supplier';
			$statementB = $db->prepare($queryAll);
			$statementB->bindValue(':supplier', $supplier);
			$statementB->execute();
			$result = $statementB->fetch();
			$statementB->closeCursor();
			return $result;
}

// Declaring empty variables upon load
$supplierErr = $contactErr = $sTelErr = $sCellErr = $sFaxErr = $sEmailErr = $sBankErr = $sBranchErr = $sAccNumErr = $sAccTypeErr = $comments = "";
$validation_error = "";

// Declaring empty variables based on the $task value (the task to be performed)
if ($task == 'insert') {
	$supplier = $contact = $sTel = $sCell = $sFax = $sEmail = $sBank = $sBranch = $sAccNum = $sAccType = $comments = "";
} elseif ($task == 'search') {
	$supplier = '';
}

// Performing validation on each form submission and performs necessary action once the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// Assigning empty variables when an update form is loaded initially
	if ($task == 'update') {
		$supplier = $contact = $sTel = $sCell = $sFax = $sEmail = $sBank = $sBranch = $sAccNum = $sAccType = $comments = "";
	}
	
	// Validating the supplier_id input
	if (empty($_POST["supplier"])) {
		$supplierErr = "Supplier ID Required";
	} else {
		$supplier = htmlspecialchars(test_input($_POST["supplier"]));
		$result = verify_supplier_exists_upon_insert($supplier);
			if ($task == 'insert') {
				if (!empty($result)) {
					$supplierErr = "This supplier already exists on the system.";
				}
			}
    }
	
	// Validating the contact person field
	if (empty($_POST["contact"])) {
		$contactErr = "Contact person is required";
	} else {
		$contact = ucwords(test_input($_POST["contact"]));
		if (!preg_match("/^[a-zA-Z ]*$/",$contact)) {
			$contactErr = "Invalid contact person entered";
		}
	}
  
	// Verify the sTel field
	if (!empty($_POST["sTel"])) {
		$sTel = test_input($_POST["sTel"]);
		// check if sTel only contains numbers
		if (!preg_match("/^[0-9 ]{10,}$/",$sTel)) {
        $sTelErr = "Invalid phone number entered";
		}
	}
  
	// Verify the sCell field
	if (!empty($_POST["sCell"])) {
		$sCell = test_input($_POST["sCell"]);
		// check if sCell only contains numbers
		if (!preg_match("/^[0-9 ]{10,}$/",$sCell)) {
			$sCellErr = "Invalid cellphone number entered";
		}	
	} 
	
	// Verify the sFax field
	if (!empty($_POST["sFax"])) {
		$sFax = test_input($_POST["sFax"]);
		// check if sFax only contains numbers
		if (!preg_match("/^[0-9 ]{10,}$/",$sFax)) {
			$sFaxErr = "Invalid fax number number entered";
		}
	}
	
	// Verify the sEmail field
	if (!empty($_POST["sEmail"])) {
		// converting string to lower case
		$sEmail = strtolower(test_input($_POST["sEmail"])); 
		// performing email address validation by using FILTER_VALIDATE_EMAIL
		if (!filter_var($sEmail, FILTER_VALIDATE_EMAIL)) {
			$sEmailErr = "Invalid email entered";
		}
	}
	
	// Ensuring that at least one contact field needs to be entered, otherwise display an error
	if (empty($_POST["sTel"]) && empty($_POST["sCell"]) && empty($_POST["sFax"]) && empty($_POST["sEmail"])) {
		$sEmailErr = "Please enter at least one contact field";
	}
  
	// Verifying banking details, should banking details be entered
	if (!empty($_POST["sBank"])) {
		$sBank = test_input($_POST["sBank"]);
		if (empty($_POST["sBranch"])) {
			$sBranchErr = "* Please enter the bank's branch code";
		} else {
			//check if all banking details are entered
			$sBranch = test_input($_POST["sBranch"]);
			// check if branch code only contains numbers
			if (!preg_match("/^[0-9 ]{6,}$/",$sBranch)) {
				$sBranchErr = "* Invalid branch code entered";
			}
		}
		if (empty($_POST["sAccNum"])) {
			$sAccNumErr = "* Please enter the account number";
		} else {
			$sAccNum = test_input($_POST["sAccNum"]);
			// check if tel_cell only contains numbers
			if (!preg_match("/^[1-9][0-9]*$/",$sAccNum)) {
			$sAccNumErr = "* Invalid account number entered";
			}
		}
		if (empty($_POST["sAccType"])) {
			$sAccTypeErr = "* Please enter an account type";
		} else {
			$sAccType = ucwords(test_input($_POST["sAccType"]));
			// check if surname does not contain foreign characters
			if (!preg_match("/^[a-zA-Z ]*$/",$sAccType)) {
				$sAccTypeErr = "* Invalid account type entered";
			}
		}
	}	
	
	// Assigning comments to the variable (comments to be stored in the db)
	$comments = test_input($_POST["comments"]);
  
	
	if ($supplierErr != "" || $contactErr != "" || $sTelErr != "" || $sCellErr != "" || $sFaxErr != "" || $sEmailErr != "" || $sBankErr != "" || $sBranchErr != "" || $sAccNumErr != "" || $sAccTypeErr != "") { //NAPPI ERROR || $emailErr != ""
		// display general error message to inform user to check input if any one error occurs
		$validation_error = "* Required field(s) needs attention<br><br>";
	}
 
	// If no errors exist, continue to execute the intended task
	if($supplierErr == "" && $contactErr == "" && $sTelErr == "" && $sCellErr == "" && $sFaxErr == "" && $sEmailErr == "" && $sBankErr == "" && $sBranchErr == "" && $sAccNumErr == "" && $sAccTypeErr == "") { //&&  $emailErr == "" NAPPI
		
		//ensuring the $comments variable is assigned
		$comments = test_input($_POST["comments"]);

		if ($task === 'update') {
			//execute the update query
		$queryU = 'UPDATE tblsuppliers
               SET contact_name = :contact, s_tel = :tel, s_cell = :cell, s_fax = :fax, s_email = :email, bank = :bank, branch_code = :branch, acc_num = :accnum,  acc_type = :acctype, comments = :comments
               WHERE supplier_id = :supplier';
		$statementU = $db->prepare($queryU);
		$statementU->bindValue(':contact', $contact);
		$statementU->bindValue(':tel', $sTel);
		$statementU->bindValue(':cell', $sCell);
		$statementU->bindValue(':fax', $sFax);
		$statementU->bindValue(':email', $sEmail);
		$statementU->bindValue(':bank', $sBank);
		$statementU->bindValue(':branch', $sBranch);
		$statementU->bindValue(':accnum', $sAccNum);
		$statementU->bindValue(':acctype', $sAccType);
		$statementU->bindValue(':comments', $comments);
		$statementU->bindValue(':supplier', $supplier);
		$statementU->execute();
		$statementU->closeCursor(); 
		
		header('Location:supplier_result.php?updated='.$_POST['supplier']);
	}
	
	if ($task === 'insert') {
		//excecute the insert query
		$query = 'INSERT INTO tblsuppliers
				(supplier_id, contact_name, s_tel, s_cell, s_fax, s_email, bank, branch_code, acc_num, acc_type, comments)
				VALUES
				(:supplier, :contact, :tel, :cell, :fax, :email, :bank, :branch, :accnum, :acctype, :comments)';
		$statementA = $db->prepare($query);
		$statementA->bindValue(':supplier', $supplier);
		$statementA->bindValue(':contact', $contact);
		$statementA->bindValue(':tel', $sTel);
		$statementA->bindValue(':cell', $sCell);
		$statementA->bindValue(':fax', $sFax);
		$statementA->bindValue(':email', $sEmail);
		$statementA->bindValue(':bank', $sBank);
		$statementA->bindValue(':branch', $sBranch);
		$statementA->bindValue(':accnum', $sAccNum);
		$statementA->bindValue(':acctype', $sAccType);
		$statementA->bindValue(':comments', $comments);
		$statementA->execute();
		$statementA->closeCursor(); 
		
		//IF THE ID NUMBER IS ALREADY IN THE DB, THEN DISPLAY ERROR MESSAGE
		
		header('Location:supplier_result.php?new='.$_POST['supplier']);
	}
	
	//determining that the supplier exists or does not exist
	if (empty($_POST["supplier"])) {
		$supplierErr = "Supplier ID Required";
	} else {
		$supplier = htmlspecialchars(test_input($_POST["supplier"]));
		$result = verify_supplier_exists_upon_insert($supplier);
		if (empty($result)) {
				$supplierErr = "This supplier is not on the system.";
			}
		} 
			if ($supplierErr == "") {
			header('Location:supplier_result.php?search='.$_POST['supplier']);
		}	
	}
	
	}
?>