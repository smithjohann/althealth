<?php
// Student 57050333
// functions.php - Containing functions for the system

// Connecting to the database
require('../model/connection.php');

/*
// Function to retrieve the references from tblreference
function client_references() {
	global $db;
	$queryS = 'SELECT DISTINCT c_reference FROM tblreference;';
	$statementB = $db->prepare($queryS);
	$statementB->execute();
	$references = $statementB->fetchAll();
	$statementB->closeCursor();
	
	return $references;
}
*/

function new_client() {
	if (htmlspecialchars($_GET['new']) != '') {
	$clientid = htmlspecialchars($_GET['new']);
	global $db;
	$queryAll = 'SELECT * FROM tblowners
             WHERE ownerID = :ownerID';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':ownerID', $clientid);
	$statementB->execute();
	$clients = $statementB->fetchAll();
	$statementB->closeCursor();
	
	return $clients;
	}
}

function search_client() {
	if (htmlspecialchars($_GET['search']) != '') {
		global $db;
		$clientid = htmlspecialchars($_GET['search']);
		$queryAll = 'SELECT * FROM tblowners
					 WHERE ownerID = :ownerID';
		$statementB = $db->prepare($queryAll);
		$statementB->bindValue(':ownerID', $clientid);
		$statementB->execute();
		$clients = $statementB->fetchAll();
		$statementB->closeCursor();
		return $clients;
	}
}

function update_client() {
	if (htmlspecialchars($_GET['updated']) != '') {
		$clientid = htmlspecialchars($_GET['updated']);
		global $db;
		$queryAll = 'SELECT * FROM tblowners
					 WHERE ownerID = :ownerID';
		$statementB = $db->prepare($queryAll);
		$statementB->bindValue(':ownerID', $clientid);
		$statementB->execute();
		$clients = $statementB->fetchAll();
		$statementB->closeCursor();
		return $clients;
	}
}

function fetch_client($patient_update) { 
	global $db;
	$queryAll = 'SELECT * FROM tblowners
                 WHERE ownerID = :ownerID';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':ownerID', $patient_update);
	$statementA->execute();
	$client = $statementA->fetch();
	$statementA->closeCursor();
	return $client;
}

function suppliers() {
	global $db;
	$queryS = 'SELECT DISTINCT supplier_id FROM tblsuppliers;';
	$statementB = $db->prepare($queryS);
	$statementB->execute();
	$suppliers = $statementB->fetchAll();
	$statementB->closeCursor();
	return $suppliers;
}

function verify_client_exists($id) { //USED
	global $db;
	$queryAll = 'SELECT * FROM tblowners
				 WHERE ownerID = :ownerID';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':ownerID', $id);
	$statementB->execute();
	$clients = $statementB->fetchAll();
	$statementB->closeCursor();
	return $clients;
}

function verify_supplement_exists($supplement) {
	global $db;
	$queryAll = 'SELECT * FROM tblsupplements
				 WHERE supplement_id = :supplement';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':supplement', $supplement);
	$statementB->execute();
	$clients = $statementB->fetchAll();
	$statementB->closeCursor();
	return $clients;
}

function new_supplement() {
	if (htmlspecialchars($_GET['new']) != '') {
		$sup = htmlspecialchars($_GET['new']);
		global $db;
		$queryAll = 'SELECT * FROM tblsupplements
					 WHERE supplement_id = :supplement';
		$statementB = $db->prepare($queryAll);
		$statementB->bindValue(':supplement', $sup);
		$statementB->execute();
		$supplements = $statementB->fetchAll();
		$statementB->closeCursor();
		return $supplements;
	}
}

function update_supplement() {
	if (htmlspecialchars($_GET['updated']) != '') {
		$sup = htmlspecialchars($_GET['updated']);
		global $db;
		$queryAll = 'SELECT * FROM tblsupplements
					 WHERE supplement_id = :supplement';
		$statementB = $db->prepare($queryAll);
		$statementB->bindValue(':supplement', $sup);
		$statementB->execute();
		$supplements = $statementB->fetchAll();
		$statementB->closeCursor();
		return $supplements;
	}
}

function search_supplement() {
	if (htmlspecialchars($_GET['search']) != '') { 
		$sup = htmlspecialchars($_GET['search']);
		global $db;
		$queryAll = 'SELECT * FROM tblsupplements
					 WHERE supplement_id = :supplement';
		$statementB = $db->prepare($queryAll);
		$statementB->bindValue(':supplement', $sup);
		$statementB->execute();
		$supplements = $statementB->fetchAll();
		$statementB->closeCursor();
		return $supplements;
	}
}

function fetch_supplement($supplement_update) {
	global $db;
	$queryAll = 'SELECT * FROM tblsupplements
				 WHERE supplement_id = :supplement';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':supplement', $supplement_update);
	$statementA->execute();
	$result = $statementA->fetch();
	$statementA->closeCursor();
	return $result;
}

function new_supplier() {
	$suppl = htmlspecialchars($_GET['new']);
	global $db;
	$queryAll = 'SELECT * FROM tblsuppliers
             WHERE supplier_id = :supplier';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':supplier', $suppl);
	$statementB->execute();
	$suppliers = $statementB->fetchAll();
	$statementB->closeCursor();
	return $suppliers;
}

function update_supplier() {
	$suppl = htmlspecialchars($_GET['updated']);
	global $db;
	$queryAll = 'SELECT * FROM tblsuppliers
             WHERE supplier_id = :supplier';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':supplier', $suppl);
	$statementB->execute();
	$suppliers = $statementB->fetchAll();
	$statementB->closeCursor();
	return $suppliers;
}

function search_supplier() {
	$suppl = htmlspecialchars($_GET['search']);
	global $db;
	$queryAll = 'SELECT * FROM tblsuppliers
             WHERE supplier_id = :supplier';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':supplier', $suppl);
	$statementB->execute();
	$suppliers = $statementB->fetchAll();
	$statementB->closeCursor();
	return $suppliers;
}

function fetch_supplier($supplier_update) {
	global $db;
	$queryAll = 'SELECT * FROM tblsuppliers
				 WHERE supplier_id = :supplier';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':supplier', $supplier_update);
	$statementA->execute();
	$content = $statementA->fetch();
	$statementA->closeCursor();
	return $content;
}

function supplier_supplements($supplier_id) {
	global $db;
	$queryAll = 'SELECT * FROM tblsupplements
				 WHERE SUPPLIER_ID = :supplier';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':supplier', $supplier_id);
	$statementA->execute();
	$supplements = $statementA->fetchAll();
	$statementA->closeCursor();
	return $supplements;
}

function dtd_1($dateInput) {
	global $db;
	$queryA = 'SELECT c.client_id, c.c_name, c.c_surname, b.app_time_start, b.app_time_end
              FROM tblclientdata c JOIN tblbookingsinfo b
			  ON b.CLIENT_ID = c.CLIENT_ID
			  WHERE app_date = :app_date';
    $statement = $db->prepare($queryA);
    $statement->bindValue(':app_date', $dateInput);
    $statement->execute();
    $appointments = $statement->fetchAll();
    $statement->closeCursor(); 
	return $appointments;
}

function dtd_2() {
	global $db;
	$query7 = "SELECT client_id, c_name, c_surname, c_email FROM tblclientdata WHERE client_id LIKE CONCAT('%', (SELECT DATE_FORMAT(SYSDATE(), '%m%d') LIMIT 1), '%')";
    $statement = $db->prepare($query7);
    $statement->execute();
    $birthdays = $statement->fetchAll();
    $statement->closeCursor(); 
	return $birthdays;
}

function dtd_3() {
	global $db;
	$query5 = 'SELECT supplement_id, min_levels, current_level, supplier_id FROM tblsupplements WHERE min_levels > current_level';
    $statement = $db->prepare($query5);
    $statement->execute();
    $supplements = $statement->fetchAll();
    $statement->closeCursor();
	return $supplements;
}

function retrieve_notes($client) {
	global $db;
		$queryA = 'SELECT app_date, notes
              FROM tblpatientnotes
			  WHERE client_id = :client';
    $statement = $db->prepare($queryA);
    $statement->bindValue(':client', $client);
    $statement->execute();
    $appointment = $statement->fetchAll();
    $statement->closeCursor(); 
	return $appointment;
}

function retrieve_client_names($client) {
	global $db;
		$queryB = 'SELECT c_name,c_surname
              FROM tblclientdata
			  WHERE client_id = :client';
    $statementB = $db->prepare($queryB);
    $statementB->bindValue(':client', $client);
    $statementB->execute();
    $names = $statementB->fetchAll();
    $statementB->closeCursor();
	return $names;
}

function save_notes ($appointment_notes, $client, $current_date) {
	global $db;
	$queryU = 'UPDATE tblpatientnotes
               SET NOTES = :notes 
               WHERE CLIENT_ID = :clientid AND APP_DATE = :date';
		$statementU = $db->prepare($queryU);
		$statementU->bindValue(':notes', $appointment_notes);
		$statementU->bindValue(':clientid', $client);
		$statementU->bindValue(':date', $current_date);
		$statementU->execute();
		$statementU->closeCursor();
}

function fees() {
	global $db;
	$queryS = 'SELECT DISTINCT consultation_fee FROM tblinvoiceconsultations ORDER BY consultation_fee ASC;';
	$statementB = $db->prepare($queryS);
	$statementB->execute();
	$fees = $statementB->fetchAll();
	$statementB->closeCursor();
	return $fees;
}

function new_invoice($client, $current_date, $charge) {
	global $db;
	$query = 'INSERT INTO tblinvoiceinfo
				(CLIENT_ID, INV_DATE, TOTAL_COST)
				VALUES
				(:clientid, :date, :total_cost)';
		$statementA = $db->prepare($query);
		$statementA->bindValue(':clientid', $client);
		$statementA->bindValue(':date', $current_date);
		$statementA->bindValue(':total_cost', $charge);
		$statementA->execute();
		$statementA->closeCursor();
}

function retrieve_inv_num($client, $current_date) {
	global $db;
			$query = 'SELECT INV_NUM FROM tblinvoiceinfo
				  WHERE CLIENT_ID = :clientid
				  AND inv_date = :date';
		$statementB = $db->prepare($query);
		$statementB->bindValue(':clientid', $client);
		$statementB->bindValue(':date', $current_date);
		$statementB->execute();
		$invoicenum = $statementB->fetchAll();
		$statementB->closeCursor();
		
		foreach ($invoicenum as $invoicenum) {
			$invoice = $invoicenum['INV_NUM'];
		}
		return $invoice;
}

function retrieve_booking_num($client, $current_date) {
	global $db;
	$query = 'SELECT BOOKING_NUM FROM tblbookingsinfo
				  WHERE CLIENT_ID = :clientid
				  AND APP_DATE = :date';
		$statementC = $db->prepare($query);
		$statementC->bindValue(':clientid', $client);
		$statementC->bindValue(':date', $current_date);
		$statementC->execute();
		$bookingnum = $statementC->fetchAll();
		$statementC->closeCursor();
		
		foreach ($bookingnum as $bookingnum) {
			$book = $bookingnum['BOOKING_NUM'];
		}
		return $book;
}

function add_consultation_invoice($invoice, $book, $charge) {
	global $db;
	$query = 'INSERT INTO tblinvoiceconsultations
				   (INV_NUM, BOOKING_NUM, CONSULTATION_FEE)
				  VALUES
				   (:invoice, :booking, :fee)';
		$statementD = $db->prepare($query);
		$statementD->bindValue(':invoice', $invoice);
		$statementD->bindValue(':booking', $book);
		$statementD->bindValue(':fee', $charge);
		$statementD->execute();
		$statementD->closeCursor();
}

function client_info ($client) {
	global $db;
	$query = 'SELECT C_NAME, C_SURNAME, C_ADDRESS, C_TEL_CELL, C_EMAIL, POSTAL_CODE FROM tblclientdata
				  WHERE CLIENT_ID = :clientid';
		$statementE = $db->prepare($query);
		$statementE->bindValue(':clientid', $client);
		$statementE->execute();
		$client_information = $statementE->fetchAll();
		$statementE->closeCursor();
		return $client_information;
}

function timeslots() {
	global $db;
	$querySlots = 'SELECT * FROM tbltimes';
	$statementA = $db->prepare($querySlots);
	$statementA->execute();
	$timeslots = $statementA->fetchAll();
	$statementA->closeCursor();
	return $timeslots;
}

function booked_slots($bookingDate) {
	global $db;
	$queryAll = 'SELECT APP_TIME_START, APP_TIME_END FROM tblbookingsinfo
				 WHERE APP_DATE = :date';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':date', $bookingDate);
	$statementB->execute();
	$bookings = $statementB->fetchAll();
	$statementB->closeCursor();
	return $bookings;
}

function client_booking($client) {
	global $db;
	$queryAll = 'SELECT * FROM tblbookingsinfo
             WHERE client_id = :clientid';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':clientid', $client);
	$statementB->execute();
	$bookings = $statementB->fetchAll();
	$statementB->closeCursor();
	return $bookings;
}

function searching_supplier($sup) {
	global $db;
	$queryAll = 'SELECT * FROM tblsuppliers
             WHERE supplier_id = :supplier';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':supplier', $sup);
	$statementB->execute();
	$suppliers = $statementB->fetchAll();
	$statementB->closeCursor();
	return $suppliers;
}

function remove_booking($patient_id, $booking) {
	global $db;
	$queryAll = 'DELETE FROM tblbookingsinfo
				 WHERE booking_num = :booking';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':booking', $booking);
	$statementB->execute();
	$statementB->closeCursor();
}

function fetch_invoice($invoice_update) {
	global $db;
	$queryAll = 'SELECT * FROM tblinvoiceinfo
                 WHERE INV_NUM = :inv';
	$statementA = $db->prepare($queryAll);
	$statementA->bindValue(':inv', $invoice_update);
	$statementA->execute();
	$invoice = $statementA->fetch();
	$statementA->closeCursor();
	return $invoice;
}

function query_slots() {
	global $db;
	$querySlots = 'SELECT * FROM tbltimes';
	$statementA = $db->prepare($querySlots);
	$statementA->execute();
	$timeslots = $statementA->fetchAll();
	$statementA->closeCursor();
	return $timeslots;
}

function appointments($bookingDate) {
	global $db;
	$queryAll = 'SELECT APP_TIME_START, APP_TIME_END FROM tblbookingsinfo
				 WHERE APP_DATE = :date';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':date', $bookingDate);
	$statementB->execute();
	$bookings = $statementB->fetchAll();
	$statementB->closeCursor();
	return $bookings;
}

function booking_information ($booking_number) {
	global $db;
	$queryAll = 'SELECT * FROM tblbookingsinfo
             WHERE BOOKING_NUM = :bookingnum';
	$statementB = $db->prepare($queryAll);
	$statementB->bindValue(':bookingnum', $booking_number);
	$statementB->execute();
	$booking = $statementB->fetch();
	$statementB->closeCursor();
	return $booking;
}


?>