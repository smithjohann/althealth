<?php
// Student 57050333
// Validation php script for the supplements section (adding, updating or searching a client)

// Initialising the database connection
require('../model/connection.php');

// Function to ensure no whitespace or or is present in user's input
function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

// Function to verify if a supplement aready exists in the db
function verify_supplement_exists_upon_insert($supplement) {
	global $db;
	$queryAll = 'SELECT supplement_id FROM tblsupplements
						 WHERE supplement_id = :supplement';
			$statementB = $db->prepare($queryAll);
			$statementB->bindValue(':supplement', $supplement);
			$statementB->execute();
			$result = $statementB->fetch();
			$statementB->closeCursor();
			return $result;
}

// Declaring empty error variables 
$supplementErr = $descErr = $costExErr = $costInErr = $markupErr = $costClErr = $minLErr = $currentLErr = $validation_error = "";

// Declare empty variables if data is being inserted or search is performed
if ($task == 'insert') {
	$supplement = $desc = $costEx = $costIn = $markup = $costCl = $minL = $currentL = $supp = $nappi = "";
} elseif ($task == 'search') {
	$supplement = '';
}

// Performing validation on each entry and performs necessary action once the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if ($task == 'search') {
			$supplement = test_input($_POST["supplement"]);
			$verify = verify_supplement_exists_upon_insert($supplement);
			//verify to check if the supplement already exists on the system
			if (empty($verify)) {
				$supplementErr = "Supplement entered is not on the system";
			}
			//if no error exists, redirect to the supplement_result page to display the supplement
			if ($supplementErr == "") {
				header('Location:supplement_result.php?search='.$_POST['supplement']);

			}
		}
	
	// Declare empty variables when an update occurs
	if ($task == 'update') {
		$supplement = $desc = $costEx = $costIn = $markup = $costCl = $minL = $currentL = $supp = $nappi = "";
	}
	
	// Determining if the entered supplement_id is valid
	if (empty($_POST["supplement"])) {
		$supplementErr = "Supplement ID Required";
	} else {
		$supplement = htmlspecialchars(test_input($_POST["supplement"]));
		if ($task == 'insert') {
			$verify = verify_supplement_exists_upon_insert($supplement);
			//verify to check if the supplement already exists on the system
			if (!empty($verify)) {
				$supplementErr = "Supplement entered is already on the system";
			}
		}
	}
	
	// Determining if both costs are omitted
	if (empty($_POST["cost_incl"]) && empty($_POST["cost_excl"])) {
			$costExErr = "Cost Incl. and/or Cost Excl. required";
			$costInErr = "Cost Incl. and/or Cost Excl. required";
		}
	
	// Validating the cost_excl field
	if (empty($_POST["cost_excl"])) {
		if (!empty($_POST["cost_incl"])) {
			$costIn = test_input($_POST["cost_incl"]);
			if (!preg_match('#^\d+(?:\.\d{1,2})?$#', $costIn)) {
				$costInErr = "* Invalid amount entered";
			}	
			$costEx = round(($costIn / 1.15), 2); //ROUND USED
			//$costIn = $costEx * 1.14;
		}	
	} 
	
	// Validating the cost_incl field
	if (empty($_POST["cost_incl"])) {
		if (!empty($_POST["cost_excl"])) {
			if (empty($_POST["cost_incl"])) {
			$costEx = round(test_input($_POST["cost_excl"]), 2);
			if (!preg_match('#^\d+(?:\.\d{1,2})?$#', $costEx)) {
				$costExErr = "* Invalid amount entered";
			} else {
				$costIn = round(($costEx * 1.15), 2); //ROUND USED
				}	
			}
		}
	}  
	
	// Determining if both cost fields are present and performing a calculation for both values (ensuring they are correct when stored into the db)
	if (!empty($_POST["cost_excl"]) && !empty($_POST["cost_incl"])) {
		$costIn = round(test_input($_POST["cost_incl"]), 2);
		if (!preg_match('#^\d+(?:\.\d{1,2})?$#', $costIn)) {
			  $costInErr = "* Invalid amount entered";
		}
		$costEx = round(test_input($_POST["cost_excl"]), 2);
		if (!preg_match('#^\d+(?:\.\d{1,2})?$#', $costEx)) {
			$costExErr = "* Invalid amount entered";
		}
		if ($costEx > $costIn) {
			$costInErr = "* Incorrect amount entered - Inclusive should be larger than exclusive amount";
		} 
	}	

	// Validating the markup field
	if (empty($_POST["markup"]) && $_POST["markup"] != '0') {
		$markupErr = "Please enter a markup amount";
	} else {
		$markup = round(test_input($_POST["markup"]), 2);
		//check if the markup value is valid (numeric or decimal)
		if (!preg_match('#^\d+(?:\.\d{1,2})?$#',$markup)) {
			$markupErr = "Invalid amount entered";
		}
	}

	// Validating the cost_client field and attempt to calculate the cost to the client
	if (!empty($_POST["cost_client"])) {
		$costCl = test_input($_POST["cost_client"]);
		// check if the markup value is valid
		if (!preg_match('#^\d+(?:\.\d{1,2})?$#',$costCl)) {
			$costClErr = "Invalid amount entered";
		}
	} elseif (empty($_POST["cost_client"])) {
		if ($costIn != '' && $markup != '') {
			$costCl = $costIn + $markup;
		} else {
			$costClErr = "Client cost could not be calculated automatically";
		}
	}
	
	// Validating the min_level field
	if (empty($_POST["min_level"]) && $_POST["min_level"] != '0') {
		$minLErr = "Please enter a minimal level for the supplement";
	} else {
		$minL = test_input($_POST["min_level"]);
		// check if min_level only contains numbers
		if (!preg_match("/^[0-9][0-9]*$/",$minL)) {
			$minLErr = "Invalid number entered";
		}
	}
  
	// Validating the current_level field 
	if (empty($_POST["current_level"]) && $_POST["current_level"] != '0') {
		$currentLErr = "Please enter a current level of stock for the supplement";
	} else {
		$currentL = test_input($_POST["current_level"]);
		// check if current_level only contains numbers
		if (!preg_match("/^[0-9][0-9]*$/",$currentL)) {
			$currentLErr = "Invalid number entered";
		}
	}
	
	// Assigning the NAPPI field to the variable - No validation required on this field, and HTML maxlength has been set to 7
	$nappi = htmlspecialchars(test_input($_POST["nappi"]));
	
	// assigning $desc to the inputted description
	$desc = htmlspecialchars(test_input($_POST["description"]));
	
	// assigning $reference to the selected value in the drop-list
	$supp = test_input($_POST["supplier"]);

	if ($supplementErr != "" || $descErr != "" || $costExErr != "" || $costInErr != "" || $markupErr != "" || $costClErr != "" || $minLErr != "" || $currentLErr != "") { 
		// display general error message to inform user to check input
		$validation_error = "* Required field(s) needs attention<br><br>";
	}
	
	// If no errors are present, execute the intended task
	if($supplementErr == "" && $descErr == "" && $costExErr == "" && $costInErr == "" && $markupErr == "" &&  $costClErr == "" && $minLErr == "" && $currentLErr == "") { 
		if ($task == 'search') {
			$supplement = test_input($_POST["supplement"]);
			$verify = verify_supplement_exists_upon_insert($supplement);
			//verify to check if the supplement already exists on the system
			if (empty($verify)) {
				$supplementErr = "Supplement entered is not on the system";
			}
			header('Location:supplement_result.php?search='.$_POST['supplement']);
		}
	
		// determining the assigned $task variable
		if ($task === 'update') {
			//recalculate the $costIn when $costEx is being updated
			$costIn = round(($costEx * 1.15), 2); //ROUND USED
			$costCl = $costIn + $markup;
			
			//execute the update query
			$queryU = 'UPDATE tblsupplements
				       SET sup_description = :description, cost_excl = :cost_excl, cost_incl = :cost_incl, profit_markup = :markup, cost_client = :cost_client, supplier_id = :supplier, min_levels = :min_level, current_level = :current_level, nappi = :nappi
                       WHERE supplement_id = :supplement';
			$statementU = $db->prepare($queryU);
			$statementU->bindValue(':description', $desc);
			$statementU->bindValue(':cost_excl', $costEx);
			$statementU->bindValue(':cost_incl', $costIn);
			$statementU->bindValue(':markup', $markup);
			$statementU->bindValue(':cost_client', $costCl);
			$statementU->bindValue(':supplier', $supp);
			$statementU->bindValue(':min_level', $minL);
			$statementU->bindValue(':current_level', $currentL);
			$statementU->bindValue(':nappi', $nappi);
			$statementU->bindValue(':supplement', $supplement);
			$statementU->execute();
			$statementU->closeCursor(); 
		
			header('Location:supplement_result.php?updated='.$_POST['supplement']);
		}
	
		if ($task === 'insert') {
			//excecute the insert query
			$query = 'INSERT INTO tblsupplements
						(supplement_id, sup_description, cost_excl, cost_incl, profit_markup, cost_client, supplier_id, min_levels, current_level, nappi)
					  VALUES
						(:supplement, :description, :cost_excl, :cost_incl, :markup, :cost_client, :supplier, :min_level, :current_level, :nappi)';
			$statementA = $db->prepare($query);
			$statementA->bindValue(':supplement', $supplement);
			$statementA->bindValue(':description', $desc);
			$statementA->bindValue(':cost_excl', $costEx);
			$statementA->bindValue(':cost_incl', $costIn);
			$statementA->bindValue(':markup', $markup);
			$statementA->bindValue(':cost_client', $costCl);
			$statementA->bindValue(':supplier', $supp);
			$statementA->bindValue(':min_level', $minL);
			$statementA->bindValue(':current_level', $currentL);
			$statementA->bindValue(':nappi', $nappi);
			$statementA->execute();
			$statementA->closeCursor(); 
		
			header('Location:supplement_result.php?new='.$_POST['supplement']);
		}
		

		if ($task === 'search') {
			$verify = verify_supplement_exists_upon_insert($supplement);
			//verify to check if the supplement already exists on the system
			if (empty($verify)) {
				$supplementErr = "Supplement entered is not on the system";
			}
			header('Location:supplement_result.php?search='.$_POST['supplement']);
		}
	
	}
  }//end of $_SERVER
?>