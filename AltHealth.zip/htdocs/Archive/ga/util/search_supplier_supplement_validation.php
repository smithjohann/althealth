<?php
 function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
require ('../model/connection.php');

function verify_supplier_exists_upon_insert($supplier) {
	global $db;
	$queryA = 'SELECT supplier_id FROM tblsuppliers
			   WHERE supplier_id = :supplier';
			$statementX = $db->prepare($queryA);
			$statementX->bindValue(':supplier', $supplier);
			$statementX->execute();
			$result = $statementX->fetch();
			$statementX->closeCursor();
			return $result;
}

function verify_supplement_exists_upon_insert($supplement) {
	global $db;
	$queryAll = 'SELECT supplement_id FROM tblsupplements
						 WHERE supplement_id = :supplement';
			$statementB = $db->prepare($queryAll);
			$statementB->bindValue(':supplement', $supplement);
			$statementB->execute();
			$result = $statementB->fetch();
			$statementB->closeCursor();
			return $result;
}

$supplementErr = $supplierErr = "";
$supplement = $supplier = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST["supplement"])) {
		$supplementErr = "Supplement ID Required";
	} else {
		$supplement = htmlspecialchars(test_input($_POST["supplement"]));
		$verify = verify_supplement_exists_upon_insert($supplement);
			//verify to check if the supplement already exists on the system
			if (empty($verify)) {
				$supplementErr = "Supplement is not on the system";
			}
		} 
	

	if (empty($_POST["supplier"])) {
		$supplierErr = "Supplier ID Required";
	} else {
		$supplier = htmlspecialchars(test_input($_POST["supplier"]));
		$result = verify_supplier_exists_upon_insert($supplier);
		if (empty($result)) {
				$supplierErr = "This supplier is not on the system.";
			}
		} 
    
	
	if ($supplementErr == "") {
			header('Location:supplement_result.php?search='.$_POST['supplement']);
		}
		
	if ($supplierErr == "") {
			header('Location:supplier_result.php?search='.$_POST['supplier']);
		}	
	
}//end of $_POST
?>