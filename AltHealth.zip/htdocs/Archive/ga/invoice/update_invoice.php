<?php
// Student 57050333
// update_invoice.php - Allowng the total paid amount to be updated, which will update the invoice which will be sent to the client

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Variable indicating the task value - to be used in determining the validation to be performed in invoice_validation.php
$task = 'update';

// Retrieving the invoice_number to be updated
$invoice_update = htmlspecialchars(filter_input(INPUT_GET, 'invoice'));
$inv = $invoice_update;

// Calling the fetch_invoice() function
$invoice = fetch_invoice($invoice_update);

// Assigning variable to the index as fetched from the table in the fetch_client() function
$total = $invoice['TOTAL_COST'];
$paid = $invoice['TOTAL_PAID'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Invoice</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
<!-- Initialise the php include function for the validation php script -->   
<?php include('../util/invoice_validation.php');?>
   
  <h1><u>Displaying information of Invoice INV0<?php echo $invoice_update;?></u></h1>

  <div class="container">
  
  <!-- Message to show when an error has been detected in user's input -->
  <span class="error"><b><?php //echo $validation_error;?></b></span>
  
  <!-- Form for adding a client -->
  <form method="post" id="update_invoice" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="row">
    <div class="col-25">
      <label for="total">Total Cost of Invoice</label>
    </div>
    <div class="col-75">
      <input type="text" disabled id="total" name="total" value="<?php echo $total;?>">
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="paid">Total Paid</label>
    </div>
    <div class="col-75">
      <input type="number" step="0.01" placeholder="Enter the amount the client has paid (in R)" id="paid" name="paid" value="<?php echo $paid;?>">
      <span class="error"><b>* <?php echo $paidErr;?></b></span>
	</div>
  </div>
  
    <input type="hidden" id="inv_num" name="inv_num" value="<?php echo $invoice_update; ?>"></input>
	<input type="hidden" id="total" name="total" value="<?php echo $total;?>">
						   
    <div class="row">
	<br>
		<input type="submit" value="Update" style="float: left;">
	</div>
</div>
</main>
<footer>
<a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>