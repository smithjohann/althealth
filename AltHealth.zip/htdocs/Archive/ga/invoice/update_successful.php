<?php
// Student 57050333
// update_successful.php - Displaying the updated invoice and verifying that an email has been sent to the client

// Initialize session
session_start();

// Check if the GA is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../../login.php");
    exit;
}

// Including the functions file, which also includes the connection to the db (connection.php)
include '../util/functions.php';

// Determining if the invoice has been updated and displaying the new info accordingly
if (htmlspecialchars($_GET['invoice']) != '') {
	$inv = htmlspecialchars($_GET['invoice']);
	$details = fetch_invoice($inv);
	$invoice_num = $details['INV_NUM'];
	$client = $details['CLIENT_ID'];
	$date = $details['INV_DATE'];
	$total_cost = $details['TOTAL_COST'];
	$total_paid = $details['TOTAL_PAID'];
	$amount_due = $details['AMOUNT_DUE'];
	
	// $result for the heading to be displayed
	$result = "INV0$inv has been updated";
}

// Determining the feedback whether the email was successfully sent or not
if (htmlspecialchars($_GET['email']) == 'unsuccessful') {
	$email_feedback = "A confirmation email could not be sent to the patient due to an error that has occured.<br><br>Please check if the patient has a valid email address, or contact the system administrator.";
} else {
	$email_feedback = "A confirmation email has been sent to the patient.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Information</title>
	<link rel="shortcut icon" type="image/x-icon" href="../view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="../view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>

<!-- The header of the HTML page (displaying logo and nav bar) -->
<a href="../index.php" class="logo" ><img src="../view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include '../view/navbar.html';?>

<main>
	<br>
	<!--Displaying appropriete heading using $result-->
    <h1><?php echo $result;?></h1>
    <div class="container">
        <table>
            <tr>
                <th>Invoice Number</th>
                <th>Patient ID</th>
				<th>Invoice Date</th>
				<th>Total Cost</th>
                <th>Total Paid</th>
                <th>Amount Due</th>
            </tr>

            <tr>
                <td>INV0<?php echo $invoice_num; ?></td>
                <td><?php echo $client; ?></td>
                <td><?php echo $date; ?></td>
				<td><?php echo $total_cost; ?></td>
				<td><?php echo $total_paid; ?></td>
				<td><?php echo $amount_due; ?></td>
            </tr>
        </table>
		<br>
		<span class="error-blue"><b><?php echo $email_feedback;?></b></span>
</main>

</body>
<br/>
</div>
<footer>
 <a class="logo" ><img src="../view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>