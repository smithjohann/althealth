<?php
// Student 57050333
// dtd.php - The Day to Day Reports of AltHealth

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../login.php");
    exit;
}

// Requiring connection to the database
require 'model/connection.php';

// Assigning today's date to the variable $dateInput
$dateInput = date('Y-m-d');

//Queries to compile the day to day report dashboard
$queryA = 'SELECT c.client_id, c.c_name, c.c_surname, b.app_time_start, b.app_time_end
              FROM tblclientdata c JOIN tblbookingsinfo b
			  ON b.CLIENT_ID = c.CLIENT_ID
			  WHERE app_date = :app_date';
    $statement = $db->prepare($queryA);
    $statement->bindValue(':app_date', $dateInput);
    $statement->execute();
    $appointments = $statement->fetchAll();
    $statement->closeCursor(); 

$query7 = "SELECT client_id, c_name, c_surname, c_email FROM tblclientdata WHERE client_id LIKE CONCAT('%', (SELECT DATE_FORMAT(SYSDATE(), '%m%d') LIMIT 1), '%')";
    $statement = $db->prepare($query7);
    $statement->execute();
    $birthdays = $statement->fetchAll();
    $statement->closeCursor(); 
	
$query5 = 'SELECT supplement_id, min_levels, current_level, supplier_id FROM tblsupplements WHERE min_levels > current_level';
    $statement = $db->prepare($query5);
    $statement->execute();
    $supplements = $statement->fetchAll();
    $statement->closeCursor();
?>
<!DOCTYPE html>
<html>
<!--Student 57050333-->
<head>
    <title>Good Day GA!</title>
	<link rel="shortcut icon" type="image/x-icon" href="view/logo3.gif" />
    <link rel="stylesheet" type="text/css" href="view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>
<a href="index.php" class="logo" ><img src="view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include 'view/navbar_index.html';?>

<main>
    
	<div class="row">
		<div class="col-50-l">
		<section>
		<h2>Appointments for Today</h2>
        <table>
            <tr>
				<th>Client Name</th>
                <th>Surname</th>
                <th>Time of Appointment</th>
            </tr>

            <?php foreach ($appointments as $appointment) : ?>
            <tr>
                <td><?php echo $appointment['c_name']; ?></td>
                <td><?php echo $appointment['c_surname']; ?></td>
				<td><?php echo $appointment['app_time_start']; ?> - <?php echo $appointment['app_time_end']; ?></td>
            </tr>
            <?php endforeach; ?>
			</table>
			</section>
			</br>
			<section>
			<h2>Birthday(s) Today</h2>
			<table>
            <tr>
                <th>Client Name</th>
            </tr>

            <?php foreach ($birthdays as $birthday) : ?>
            <tr>
                <td><?php echo $birthday['c_name'].' '.$birthday['c_surname']; ?></td>
            </tr>
            <?php endforeach; ?>
			</table>
			<br>
			<form action="util/email_birthday.php" method="post">
            <input style="float: left;" type="submit" value="Email Birthday Message to All">
			</form>
			</section>
		</div>
		
		<div class="col-50-r">
		<h2>Supplements Requiring Attention</h2>
		<table>
            <tr>
				<th>Supplement</th>
                <th>Current Level</th>
                <th>Minimal Level</th>
				<th>Supplier</th>
            </tr>

            <?php foreach ($supplements as $supplement) : ?>
            <tr>
                <td><?php echo $supplement['supplement_id']; ?></td>
                <td style="horizontal-align: centre;" ><?php echo $supplement['current_level']; ?></td>
				<td><?php echo $supplement['min_levels']; ?></td>
				<td><?php echo $supplement['supplier_id']; ?></td>
				<td><form action="supplements/supplier_result.php" method="post">
                    <input type="hidden" name="supplier_id" value="<?php echo $supplement['supplier_id']; ?>">
                    <input type="submit" value="Supplier Info">
                </form></td>
				<td><form action="supplements/update_supplement.php" method="get">
                    <input type="hidden" name="supplement_update" value="<?php echo $supplement['supplement_id']; ?>">
                    <input type="submit" value="Update Supplement">
                </form></td>
            </tr>
            <?php endforeach; ?>
        </table>
		</div>
	</div>

</main>
<footer>
 <a class="logo" ><img src="view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</body>
</html>