<?php
// Student 57050333
// reset-password.php - Logged in user to allow him/her to reset his/her password

// Initialize session
session_start();
 
// Check if the HCP is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["username"] !== 'ga'){
    header("location: ../login.php");
    exit;
}

 
// Include config file
require_once "model/config.php";
 
// Define variables and initialize with empty values
$new_password = $confirm_password = "";
$new_password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate new password
    if(empty(trim($_POST["new_password"]))){
        $new_password_err = "Please enter the new password.";     
    } elseif(strlen(trim($_POST["new_password"])) < 6){
        $new_password_err = "Password must have at least 6 characters.";
    } else{
        $new_password = trim($_POST["new_password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm the password.";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($new_password_err) && ($new_password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
        
    // Check input errors before updating the database
    if(empty($new_password_err) && empty($confirm_password_err)){
        // Prepare an update statement
        $sql = "UPDATE tblusers SET password = ? WHERE username = 'ga'";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_password);
            
            // Set parameters
            $param_password = password_hash($new_password, PASSWORD_DEFAULT);
            $param_username === 'ga';
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Password updated successfully. Destroy the session, and redirect to login page
                session_destroy();
                header("location: ../login.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
	<link rel="shortcut icon" type="image/x-icon" href="view/logo3.gif" />
	<link rel="stylesheet" type="text/css" href="view/main.css" /> <!-- Styles for the page -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <!-- used for the navbar styling -->
</head>
<body>
<a href="index.php" class="logo" ><img src="view/logo1.jpg" style="padding: 12px 12px 12px 5px;"></a>
<?php include 'view/navbar_index.html';?>
        <h2>Reset Password</h2>
        <p>Please fill out this form to reset your password.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
		<div class="container">
		<div class="row">
			<div class="col-25">
			<label for="new_password">New Password</label>
			</div>
			<div class="col-75">
			<input type="password" id="new_password" name="new_password" value="<?php echo $new_password; ?>"></input>
			<span class="error"><b>* <?php echo $new_password_err;?></b></span>
			</div>
		</div>
		
		<div class="row">
			<div class="col-25">
			<label for="confirm_password">Confirm Password</label>
			</div>
			<div class="col-75">
			<input type="password" id="confirm_password" name="confirm_password" value="<?php echo $new_password; ?>"></input>
			<span class="error"><b>* <?php echo $confirm_password_err;?></b></span>
			</div>
		</div>

        <div class="row">
			<br>
			<input type="submit" value="Submit" style="float: left;">
		</div>
		
		</form>
		</div>    
</body>
<footer>
 <a class="logo" ><img src="view/logo2.jpg" style="padding: 12px 12px 12px 5px; float: right;"></a>
</footer>
</html>