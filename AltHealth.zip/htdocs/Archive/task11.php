<html>
    <!--Johann AppStage Assessment-->
<head>
    <title>Vet Clinic</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
    
    
<body>
	<?php include 'menu.inc';?>
    <main>
	 <h2><u>XYZ Veterinarian Clinic</u></h2>
	 <br>
	<?php

	//PHP Section for the home page
	
	/////////////////////// Task 11(a) - Explanation of the community-based problem and proposed solution ///////////////////////
	echo '<b>Problem:</b><br>';
	echo "A community scheme of a sectional title development (i.e. a body corporate) situated on Marine Drive consists of many sectional title holders (owners). With the recent change in administrators, the board of trustees finds it difficult to keep record of owners, namely their contact details, and the unit(s) they own. The board has also experienced issues when identifying a unit’s owner as majority of the residents at the complex is tenants. The board must be able to search and contact an owner as soon as possible should an issue occur with the unit and/or its tenants. <br><br>";
	
	echo '<b>Solution:</b><br>';
	echo "The board has decided that an online database application would assist in closing the communication gap between the board and owners. This application would store the details of owners (namely contact details) and the units at the complex (the unit description and the owner). The application would enable the board to search for an owner and display the owner’s details in order to contact him/her, or to search for a unit and identifying who the unit belongs to.  <br><br>";
	
	/////////////////////// Task 11(b) - The Solution of the community-based problem ///////////////////////
	
	/*
	 * Please refer to task11.txt for the full PHP code I have used for this application (Task 11)
	*/
	echo '<br>';
	
	echo '<b><u>Please select the one of the following: </u></b><br><br>';
	
	?>
	<a href="task11_owners">Owner Management</a>
	<br><br>
	<a href="task11_units">Pet Management</a>
    </main>
    <br>
</body>

<footer>
<p><b>Johann Smith &copy; <?php echo date("Y"); ?></b></p>
</footer>
<iframe src="task11.txt" height="400" scrolling="yes" width="1200">
    Your browser does not support iframes.
</iframe>
</html>